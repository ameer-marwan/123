import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { FarmEntity, FieldEntity, WeatherState, SoilObservationRecord, IrrigationEvent, CropPlan } from '../domain/types';
import { BENCHMARK_FARMS } from '../domain/mockFarms';
import { Language, UnitSystem, Currency, DICTIONARY, Translations } from '../lib/i18n';
import { calculatePolygonAreaHectares } from '../domain/calculations';

export type ActiveTab =
  | 'overview'
  | 'map'
  | 'globe'
  | 'weather'
  | 'soil'
  | 'crops'
  | 'simulation'
  | 'water'
  | 'climate'
  | 'analytics'
  | 'reports'
  | 'about'
  | 'settings';

interface FarmContextType {
  farms: FarmEntity[];
  currentFarm: FarmEntity;
  currentField: FieldEntity;
  currentFarmId: string;
  currentFieldId: string;
  setCurrentFarmId: (id: string) => void;
  setCurrentFieldId: (id: string) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  unitSystem: UnitSystem;
  setUnitSystem: (units: UnitSystem) => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  t: Translations;
  weather: WeatherState;
  refreshWeather: () => Promise<void>;
  updateFieldBoundary: (fieldId: string, coords: Array<[number, number]>) => void;
  addSoilObservation: (fieldId: string, observation: Omit<SoilObservationRecord, 'id'>) => void;
  addIrrigationEvent: (fieldId: string, event: Omit<IrrigationEvent, 'id'>) => void;
  saveCropPlan: (fieldId: string, plan: CropPlan) => void;
  markAlertReviewed: (fieldId: string, alertId: string, actionNote?: string) => void;
  resetDemoData: () => void;
  showNotification: (msg: string, type?: 'success' | 'info' | 'warning') => void;
  notification: { message: string; type: 'success' | 'info' | 'warning' } | null;
}

const FarmContext = createContext<FarmContextType | null>(null);

const STORAGE_KEY_FARMS = 'fieldshift_farms_v1';
const STORAGE_KEY_LANG = 'fieldshift_lang';
const STORAGE_KEY_THEME = 'fieldshift_theme';
const STORAGE_KEY_UNITS = 'fieldshift_units';
const STORAGE_KEY_CURR = 'fieldshift_currency';

export const FarmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load persisted farms or use benchmark
  const [farms, setFarms] = useState<FarmEntity[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FARMS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Could not load farms from localStorage:', e);
    }
    return BENCHMARK_FARMS;
  });

  const [currentFarmId, setCurrentFarmIdState] = useState<string>(() => farms[0]?.id || 'alkharj_oasis');
  const [currentFieldId, setCurrentFieldIdState] = useState<string>(() => farms[0]?.fields[0]?.id || 'alkharj_field_1');
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem(STORAGE_KEY_LANG) as Language) || 'en';
  });

  const [theme, setThemeState] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem(STORAGE_KEY_THEME) as 'dark' | 'light') || 'dark';
  });

  const [unitSystem, setUnitSystemState] = useState<UnitSystem>(() => {
    return (localStorage.getItem(STORAGE_KEY_UNITS) as UnitSystem) || 'metric';
  });

  const [currency, setCurrencyState] = useState<Currency>(() => {
    return (localStorage.getItem(STORAGE_KEY_CURR) as Currency) || 'SAR';
  });

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  const showNotification = useCallback((message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification((curr) => (curr?.message === message ? null : curr));
    }, 4500);
  }, []);

  // Sync HTML attributes for RTL & Dark/Light mode
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem(STORAGE_KEY_LANG, language);
  }, [language]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEY_THEME, theme);
  }, [theme]);

  // Persist farms
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_FARMS, JSON.stringify(farms));
    } catch (e) {
      console.error('Failed to save farms to localStorage:', e);
    }
  }, [farms]);

  const currentFarm = useMemo(() => {
    return farms.find((f) => f.id === currentFarmId) || farms[0] || BENCHMARK_FARMS[0];
  }, [farms, currentFarmId]);

  const currentField = useMemo(() => {
    const fld = currentFarm.fields.find((f) => f.id === currentFieldId);
    return fld || currentFarm.fields[0] || BENCHMARK_FARMS[0].fields[0];
  }, [currentFarm, currentFieldId]);

  const setCurrentFarmId = useCallback((id: string) => {
    setCurrentFarmIdState(id);
    const target = farms.find((f) => f.id === id);
    if (target && target.fields.length > 0) {
      setCurrentFieldIdState(target.fields[0].id);
    }
  }, [farms]);

  const setCurrentFieldId = useCallback((id: string) => {
    setCurrentFieldIdState(id);
  }, []);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
  }, []);

  const setTheme = useCallback((th: 'dark' | 'light') => {
    setThemeState(th);
  }, []);

  const setUnitSystem = useCallback((u: UnitSystem) => {
    setUnitSystemState(u);
    localStorage.setItem(STORAGE_KEY_UNITS, u);
  }, []);

  const setCurrency = useCallback((c: Currency) => {
    setCurrencyState(c);
    localStorage.setItem(STORAGE_KEY_CURR, c);
  }, []);

  // Weather state & live fetch
  const [weather, setWeather] = useState<WeatherState>({
    current: null,
    daily: [],
    isLoading: false,
    error: null,
    lastUpdated: null,
    source: 'Initializing...',
    isStale: false,
  });

  const refreshWeather = useCallback(async () => {
    const [lat, lng] = currentFarm.centerCoordinates;
    setWeather((prev) => ({ ...prev, isLoading: true, error: null }));
    try {
      const res = await fetch(`/api/weather?latitude=${lat}&longitude=${lng}`);
      if (!res.ok) {
        throw new Error(`Weather service returned ${res.status}`);
      }
      const data = await res.json();

      const current = data.current
        ? {
            temperatureC: data.current.temperature_2m,
            relativeHumidity: data.current.relative_humidity_2m,
            precipitationMm: data.current.precipitation,
            windSpeedKmh: data.current.wind_speed_10m,
            windDirectionDeg: data.current.wind_direction_10m,
            surfacePressureHpa: data.current.surface_pressure,
            cloudCoverPercent: data.current.cloud_cover,
            weatherCode: data.current.weather_code,
            time: data.current.time,
          }
        : null;

      const daily = (data.daily?.time || []).map((dateStr: string, index: number) => ({
        date: dateStr,
        weatherCode: data.daily.weather_code?.[index] ?? 0,
        tempMaxC: data.daily.temperature_2m_max?.[index] ?? 28,
        tempMinC: data.daily.temperature_2m_min?.[index] ?? 16,
        precipSumMm: data.daily.precipitation_sum?.[index] ?? 0,
        precipProbMax: data.daily.precipitation_probability_max?.[index] ?? 0,
        windSpeedMaxKmh: data.daily.wind_speed_10m_max?.[index] ?? 15,
        et0Mm: data.daily.et0_fao_evapotranspiration?.[index] ?? 4.5,
      }));

      setWeather({
        current,
        daily,
        isLoading: false,
        error: null,
        lastUpdated: new Date().toLocaleTimeString(),
        source: data._meta?.source || 'Open-Meteo Live API',
        isStale: !!data._meta?.isStale,
      });
    } catch (err: any) {
      console.warn('Weather fetch error, using fallback:', err.message);
      // Realistic fallback for demonstration resilience without presenting it as live
      setWeather((prev) => ({
        ...prev,
        isLoading: false,
        error: 'Unable to reach live weather API. Showing cached agronomic baseline.',
        source: 'Regional Reanalysis Model (Cached)',
        isStale: true,
        current: prev.current || {
          temperatureC: 28.5,
          relativeHumidity: 32,
          precipitationMm: 0,
          windSpeedKmh: 14.2,
          windDirectionDeg: 120,
          surfacePressureHpa: 1014,
          cloudCoverPercent: 10,
          weatherCode: 1,
          time: new Date().toISOString(),
        },
      }));
    }
  }, [currentFarm]);

  // Fetch weather when current farm changes
  useEffect(() => {
    refreshWeather();
  }, [refreshWeather]);

  // Update Field Boundary
  const updateFieldBoundary = useCallback((fieldId: string, coords: Array<[number, number]>) => {
    const areaHa = calculatePolygonAreaHectares(coords);
    setFarms((prev) =>
      prev.map((farm) => {
        const updatedFields = farm.fields.map((fld) => {
          if (fld.id === fieldId) {
            return {
              ...fld,
              areaHa: areaHa > 0 ? areaHa : fld.areaHa,
              boundary: {
                type: 'Polygon' as const,
                coordinates: coords,
              },
            };
          }
          return fld;
        });
        return { ...farm, fields: updatedFields };
      })
    );
    showNotification(`Field boundary updated (${areaHa} ha).`, 'success');
  }, [showNotification]);

  // Add Soil Observation
  const addSoilObservation = useCallback(
    (fieldId: string, observation: Omit<SoilObservationRecord, 'id'>) => {
      const newRecord: SoilObservationRecord = {
        ...observation,
        id: `soil_${Date.now()}`,
      };

      setFarms((prev) =>
        prev.map((farm) => {
          const updatedFields = farm.fields.map((fld) => {
            if (fld.id === fieldId) {
              return {
                ...fld,
                currentSoil: {
                  ph: newRecord.ph,
                  organicMatterPercent: newRecord.organicMatterPercent,
                  electricalConductivityDsM: newRecord.electricalConductivityDsM,
                  nitrogenPpm: newRecord.nitrogenPpm,
                  phosphorusPpm: newRecord.phosphorusPpm,
                  potassiumPpm: newRecord.potassiumPpm,
                  bulkDensityGPerCm3: newRecord.bulkDensityGPerCm3,
                },
                soilHistory: [newRecord, ...fld.soilHistory],
              };
            }
            return fld;
          });
          return { ...farm, fields: updatedFields };
        })
      );
      showNotification('Soil diagnostic observation recorded.', 'success');
    },
    [showNotification]
  );

  // Add Irrigation Event
  const addIrrigationEvent = useCallback(
    (fieldId: string, event: Omit<IrrigationEvent, 'id'>) => {
      const newEvent: IrrigationEvent = {
        ...event,
        id: `irr_${Date.now()}`,
      };
      setFarms((prev) =>
        prev.map((farm) => {
          const updatedFields = farm.fields.map((fld) => {
            if (fld.id === fieldId) {
              return {
                ...fld,
                irrigationEvents: [newEvent, ...fld.irrigationEvents],
              };
            }
            return fld;
          });
          return { ...farm, fields: updatedFields };
        })
      );
      showNotification(`Irrigation logged: ${event.volumeM3.toLocaleString()} m³ (${event.depthMm} mm).`, 'success');
    },
    [showNotification]
  );

  // Save Crop Plan
  const saveCropPlan = useCallback((fieldId: string, plan: CropPlan) => {
    setFarms((prev) =>
      prev.map((farm) => {
        const updatedFields = farm.fields.map((fld) => {
          if (fld.id === fieldId) {
            const existingIndex = fld.cropPlans.findIndex((p) => p.id === plan.id);
            const newPlans = [...fld.cropPlans];
            if (existingIndex >= 0) {
              newPlans[existingIndex] = plan;
            } else {
              newPlans.push(plan);
            }
            return {
              ...fld,
              cropPlans: newPlans,
              activePlanId: plan.id,
            };
          }
          return fld;
        });
        return { ...farm, fields: updatedFields };
      })
    );
    showNotification(`Crop rotation plan "${plan.name}" saved.`, 'success');
  }, [showNotification]);

  // Mark Alert Reviewed
  const markAlertReviewed = useCallback((fieldId: string, alertId: string, actionNote?: string) => {
    setFarms((prev) =>
      prev.map((farm) => {
        const updatedFields = farm.fields.map((fld) => {
          if (fld.id === fieldId) {
            return {
              ...fld,
              alerts: fld.alerts.map((alt) =>
                alt.id === alertId
                  ? {
                      ...alt,
                      isReviewed: true,
                      mitigationAction: actionNote || alt.mitigationAction,
                    }
                  : alt
              ),
            };
          }
          return fld;
        });
        return { ...farm, fields: updatedFields };
      })
    );
    showNotification('Hazard alert marked as reviewed.', 'info');
  }, [showNotification]);

  // Reset Demo Data
  const resetDemoData = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY_FARMS);
    setFarms(BENCHMARK_FARMS);
    setCurrentFarmIdState(BENCHMARK_FARMS[0].id);
    setCurrentFieldIdState(BENCHMARK_FARMS[0].fields[0].id);
    showNotification('Demo data reset to baseline state.', 'info');
  }, [showNotification]);

  const t = DICTIONARY[language];

  return (
    <FarmContext.Provider
      value={{
        farms,
        currentFarm,
        currentField,
        currentFarmId,
        currentFieldId,
        setCurrentFarmId,
        setCurrentFieldId,
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        theme,
        setTheme,
        unitSystem,
        setUnitSystem,
        currency,
        setCurrency,
        t,
        weather,
        refreshWeather,
        updateFieldBoundary,
        addSoilObservation,
        addIrrigationEvent,
        saveCropPlan,
        markAlertReviewed,
        resetDemoData,
        showNotification,
        notification,
      }}
    >
      {children}
    </FarmContext.Provider>
  );
};

export const useFarm = () => {
  const context = useContext(FarmContext);
  if (!context) {
    throw new Error('useFarm must be used within a FarmProvider');
  }
  return context;
};
