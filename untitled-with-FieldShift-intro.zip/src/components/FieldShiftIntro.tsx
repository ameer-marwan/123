import { useEffect, useState } from 'react';

type IntroProps = { onComplete: () => void };

export function FieldShiftIntro({ onComplete }: IntroProps) {
  const [stage, setStage] = useState<'welcome' | 'mark' | 'leaving'>('welcome');
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReducedMotion(query.matches);
    update();
    query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  const continueIntro = () => {
    if (stage === 'welcome') {
      setStage('mark');
      return;
    }
    if (stage === 'mark') {
      setStage('leaving');
      window.setTimeout(onComplete, reducedMotion ? 0 : 560);
    }
  };

  return (
    <section
      className={`fieldshift-intro fieldshift-intro--${stage}`}
      aria-label="FieldShift welcome screen"
      onClick={continueIntro}
    >
      <div className="fieldshift-intro__grain" />
      <div className="fieldshift-intro__sun" />
      <div className="fieldshift-intro__content">
        <p className="fieldshift-intro__eyebrow">FIELD INTELLIGENCE</p>
        <div className="fieldshift-intro__logo" aria-hidden="true">
          <svg viewBox="0 0 160 160" role="img">
            <path d="M80 12c37 0 67 30 67 67 0 37-30 67-67 67S13 116 13 79C13 42 43 12 80 12Z" fill="#10281d" stroke="#c5f36b" strokeWidth="5"/>
            <path d="M31 93c18-19 31-22 48-20 17 2 29 10 50-14v53c-13 14-29 19-48 16-20-4-31-19-50-35Z" fill="#81bca2"/>
            <path d="M31 93c17 6 31 19 50 35" fill="none" stroke="#f1d36b" strokeWidth="4" strokeLinecap="round"/>
            <path d="M81 116c-5-31 2-55 27-75" fill="none" stroke="#c5f36b" strokeWidth="6" strokeLinecap="round"/>
            <path d="M107 43c-3 20-17 30-34 32 3-18 17-30 34-32Z" fill="#c5f36b"/>
            <circle cx="50" cy="50" r="11" fill="#f1d36b"/>
          </svg>
        </div>
        <h1>FieldShift</h1>
        <p className="fieldshift-intro__tagline">See every field clearly.</p>
        <button className="fieldshift-intro__button" onClick={(event) => { event.stopPropagation(); continueIntro(); }}>
          {stage === 'welcome' ? 'Tap to reveal' : 'Enter FieldShift'}
        </button>
        <p className="fieldshift-intro__hint">{stage === 'welcome' ? 'A calmer way to plan your season' : 'Your farm intelligence workspace is ready'}</p>
      </div>
    </section>
  );
}
