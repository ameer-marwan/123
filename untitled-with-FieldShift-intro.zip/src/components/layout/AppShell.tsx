import React, { useState } from 'react';
import { useFarm, ActiveTab } from '../../context/FarmContext';
import { formatArea } from '../../lib/i18n';
import {
  LayoutDashboard,
  Map,
  Globe,
  CloudSun,
  FlaskConical,
  Sprout,
  Cpu,
  Droplets,
  ShieldAlert,
  BarChart3,
  FileText,
  Award,
  Settings,
  Menu,
  X,
  Languages,
  Moon,
  Sun,
  MapPin,
  ChevronDown,
} from 'lucide-react';

interface AppShellProps {
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const {
    farms,
    currentFarm,
    currentField,
    currentFarmId,
    currentFieldId,
    setCurrentFarmId,
    setCurrentFieldId,
    activeTab,
    setActiveTab,
    theme,
    setTheme,
    language,
    setLanguage,
    unitSystem,
    t,
    notification,
  } = useFarm();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ElementType }> = [
    { id: 'overview', label: t.navOverview, icon: LayoutDashboard },
    { id: 'map', label: t.navMap, icon: Map },
    { id: 'globe', label: t.navGlobe, icon: Globe },
    { id: 'weather', label: t.navWeather, icon: CloudSun },
    { id: 'soil', label: t.navSoil, icon: FlaskConical },
    { id: 'crops', label: t.navCrops, icon: Sprout },
    { id: 'simulation', label: t.navSimulation, icon: Cpu },
    { id: 'water', label: t.navWater, icon: Droplets },
    { id: 'climate', label: t.navClimate, icon: ShieldAlert },
    { id: 'analytics', label: t.navAnalytics, icon: BarChart3 },
    { id: 'reports', label: t.navReports, icon: FileText },
    { id: 'about', label: t.navAbout, icon: Award },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#08130F] text-[#F3F7F1] flex flex-col md:flex-row antialiased">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-4 right-4 z-[9999] bg-[#111F19] text-[#F3F7F1] border border-[#C5F36B] px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-[#C5F36B]" />
          <span>{notification.message}</span>
        </div>
      )}

      {/* Mobile Top App Bar */}
      <div className="md:hidden bg-[#111F19] border-b border-[#263A2D] p-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#C5F36B] flex items-center justify-center text-[#08130F] font-black text-sm">
            FS
          </div>
          <span className="font-bold text-sm tracking-tight text-[#F3F7F1]">FieldShift</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
            className="px-2.5 py-1 text-xs font-bold text-[#C5F36B] bg-[#17271E] rounded-lg border border-[#263A2D]"
          >
            {language === 'en' ? 'AR' : 'EN'}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#9BB0A0] hover:text-[#F3F7F1] bg-[#17271E] rounded-lg border border-[#263A2D]"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Desktop / Tablet Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#111F19] border-r border-[#263A2D] flex flex-col justify-between transition-transform duration-200 md:translate-x-0 md:static ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 space-y-4">
          {/* Brand Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#C5F36B] flex items-center justify-center text-[#08130F] font-extrabold text-sm shadow-md">
                FS
              </div>
              <div>
                <span className="font-extrabold text-base tracking-tight text-[#F3F7F1] block leading-none">
                  FieldShift
                </span>
                <span className="text-[10px] text-[#9BB0A0] tracking-wider uppercase font-semibold">
                  Agri-Intelligence
                </span>
              </div>
            </div>

            <button
              onClick={() => setMobileMenuOpen(false)}
              className="md:hidden text-[#9BB0A0] hover:text-[#F3F7F1]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Farm & Field Selectors */}
          <div className="space-y-2 pt-2 border-t border-[#263A2D]">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-[#9BB0A0] block mb-1">
                Active Farm Holding
              </label>
              <select
                value={currentFarmId}
                onChange={(e) => setCurrentFarmId(e.target.value)}
                className="w-full bg-[#17271E] text-xs font-semibold text-[#F3F7F1] rounded-lg px-2.5 py-1.5 border border-[#263A2D] focus:outline-none focus:border-[#C5F36B]"
              >
                {farms.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.country})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-[#9BB0A0] block mb-1">
                Selected Field Parcel
              </label>
              <select
                value={currentFieldId}
                onChange={(e) => setCurrentFieldId(e.target.value)}
                className="w-full bg-[#17271E] text-xs font-semibold text-[#F3F7F1] rounded-lg px-2.5 py-1.5 border border-[#263A2D] focus:outline-none focus:border-[#C5F36B]"
              >
                {currentFarm.fields.map((fld) => (
                  <option key={fld.id} value={fld.id}>
                    {fld.name} ({formatArea(fld.areaHa, unitSystem)})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1 pt-2 border-t border-[#263A2D] overflow-y-auto max-h-[calc(100vh-320px)]">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#C5F36B] text-[#08130F] shadow-sm font-bold'
                      : 'text-[#9BB0A0] hover:text-[#F3F7F1] hover:bg-[#17271E]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#08130F]' : 'text-[#9BB0A0]'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer: Quick Controls */}
        <div className="p-4 border-t border-[#263A2D] bg-[#0d1813] flex items-center justify-between text-xs text-[#9BB0A0]">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
              className="px-2 py-1 bg-[#17271E] hover:text-[#F3F7F1] rounded-md border border-[#263A2D] font-mono text-[11px]"
              title="Toggle Language"
            >
              {language.toUpperCase()}
            </button>
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-1.5 bg-[#17271E] hover:text-[#F3F7F1] rounded-md border border-[#263A2D]"
              title="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>

          <span className="text-[10px] font-mono text-[#4FAE76]">v2.4 Production</span>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Contextual Header (Desktop/iPad) */}
        <header className="hidden md:flex bg-[#111F19]/80 backdrop-blur-md border-b border-[#263A2D] px-6 py-3.5 items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 text-[#9BB0A0]">
              <MapPin className="w-3.5 h-3.5 text-[#C5F36B]" />
              <span className="font-semibold text-[#F3F7F1]">{currentFarm.name}</span>
            </div>
            <span className="text-[#263A2D]">/</span>
            <span className="text-[#C5F36B] font-medium">{currentField.name}</span>
            <span className="text-[#263A2D]">/</span>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#17271E] text-[#9BB0A0] border border-[#263A2D]">
              {formatArea(currentField.areaHa, unitSystem)}
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <button
              onClick={() => setActiveTab('about')}
              className="px-3 py-1.5 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] rounded-lg border border-[#263A2D] flex items-center gap-1.5 font-semibold transition-colors"
            >
              <Award className="w-3.5 h-3.5" />
              <span>About DAIS</span>
            </button>
            <button
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
              className="px-2.5 py-1.5 bg-[#17271E] text-[#9BB0A0] hover:text-[#C5F36B] rounded-lg border border-[#263A2D] font-medium flex items-center gap-1.5 transition-colors"
            >
              <Languages className="w-3.5 h-3.5 text-[#C5F36B]" />
              <span>{language === 'en' ? 'العربية (AR)' : 'English (EN)'}</span>
            </button>
          </div>
        </header>

        {/* Page View Body */}
        <div className="p-4 sm:p-6 lg:p-8 flex-1">{children}</div>
      </main>
    </div>
  );
};
