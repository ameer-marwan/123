import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { useFarm } from '../../context/FarmContext';
import { Globe, MapPin, ZoomIn, ZoomOut, RotateCcw, ArrowRight, Cloud, Sun, Eye } from 'lucide-react';

export const ThreeGlobe: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { farms, currentFarm, setCurrentFarmId, setActiveTab } = useFarm();
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lng: number } | null>({
    lat: currentFarm.centerCoordinates[0],
    lng: currentFarm.centerCoordinates[1],
  });
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [showClouds, setShowClouds] = useState<boolean>(true);
  const [viewStyle, setViewStyle] = useState<'day' | 'night' | 'topo'>('day');

  // Synchronize selected coordinates when current farm changes
  useEffect(() => {
    setSelectedCoords({
      lat: currentFarm.centerCoordinates[0],
      lng: currentFarm.centerCoordinates[1],
    });
  }, [currentFarm]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 2.65;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Starfield Background (varied magnitudes and subtle astral tinting)
    const starsCount = 1000;
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starsCount * 3);
    const starColors = new Float32Array(starsCount * 3);
    for (let i = 0; i < starsCount * 3; i += 3) {
      starPositions[i] = (Math.random() - 0.5) * 120;
      starPositions[i + 1] = (Math.random() - 0.5) * 120;
      starPositions[i + 2] = (Math.random() - 0.5) * 120;
      const tint = 0.85 + Math.random() * 0.15;
      starColors[i] = tint;
      starColors[i + 1] = tint * (0.9 + Math.random() * 0.1);
      starColors[i + 2] = 1.0;
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starMaterial = new THREE.PointsMaterial({
      size: 0.075,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
    });
    const starField = new THREE.Points(starGeometry, starMaterial);
    scene.add(starField);

    // Realistic procedural Earth fallback canvas (detailed continents, deserts & coastal shelves)
    const createBaseEarthCanvas = () => {
      const c = document.createElement('canvas');
      c.width = 2048;
      c.height = 1024;
      const ctx = c.getContext('2d');
      if (ctx) {
        // Deep royal ocean with latitude gradient
        const oceanGrad = ctx.createLinearGradient(0, 0, 0, c.height);
        oceanGrad.addColorStop(0, '#102538');
        oceanGrad.addColorStop(0.2, '#0c223a');
        oceanGrad.addColorStop(0.5, '#0a1d33');
        oceanGrad.addColorStop(0.8, '#0c223a');
        oceanGrad.addColorStop(1, '#102538');
        ctx.fillStyle = oceanGrad;
        ctx.fillRect(0, 0, c.width, c.height);

        // Continental shelf shallow water turquoise halos
        ctx.fillStyle = 'rgba(28, 90, 120, 0.35)';
        // Eurasia/Africa shelf
        ctx.beginPath();
        ctx.ellipse(1200, 440, 310, 220, 0.05, 0, Math.PI * 2);
        ctx.fill();
        // Americas shelf
        ctx.beginPath();
        ctx.ellipse(540, 380, 190, 160, -0.1, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(680, 680, 140, 200, 0.15, 0, Math.PI * 2);
        ctx.fill();

        // Main Landmasses: Europe, Asia, Africa
        ctx.fillStyle = '#2d5a3d'; // Rich vegetative green
        ctx.beginPath();
        ctx.ellipse(1220, 430, 290, 200, 0.05, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(1080, 610, 170, 230, -0.08, 0, Math.PI * 2);
        ctx.fill();

        // Sahara & Arabian desert golden-tan sands
        ctx.fillStyle = '#9b8054';
        ctx.beginPath();
        ctx.ellipse(1160, 480, 100, 65, 0.15, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(1010, 500, 150, 85, 0, 0, Math.PI * 2);
        ctx.fill();
        // Central Asia / Gobi
        ctx.beginPath();
        ctx.ellipse(1400, 410, 120, 60, -0.05, 0, Math.PI * 2);
        ctx.fill();

        // Americas (North & South)
        ctx.fillStyle = '#265436';
        ctx.beginPath();
        ctx.ellipse(530, 380, 175, 150, -0.15, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#8f7750'; // Western plains/arid
        ctx.beginPath();
        ctx.ellipse(470, 390, 75, 90, -0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#1e4d2b'; // Amazon basin
        ctx.beginPath();
        ctx.ellipse(670, 680, 125, 190, 0.18, 0, Math.PI * 2);
        ctx.fill();

        // Australia & Oceania
        ctx.fillStyle = '#947247';
        ctx.beginPath();
        ctx.ellipse(1640, 710, 115, 80, -0.08, 0, Math.PI * 2);
        ctx.fill();

        // Polar ice caps (Antarctica and Arctic)
        ctx.fillStyle = '#e5f3f7';
        ctx.fillRect(0, 0, c.width, 60);
        ctx.fillRect(0, c.height - 70, c.width, 70);
      }
      return c;
    };

    const initialCanvasTexture = new THREE.CanvasTexture(createBaseEarthCanvas());
    initialCanvasTexture.colorSpace = THREE.SRGBColorSpace;

    // Earth Sphere Geometry (Smooth 96x96 subdivision)
    const earthRadius = 1;
    const earthGeometry = new THREE.SphereGeometry(earthRadius, 96, 96);

    const earthMaterial = new THREE.MeshStandardMaterial({
      map: initialCanvasTexture,
      roughness: 0.38,
      metalness: 0.04,
    });
    const earthMesh = new THREE.Mesh(earthGeometry, earthMaterial);
    scene.add(earthMesh);

    // Asynchronously load real photographic NASA textures
    const textureLoader = new THREE.TextureLoader();

    const renderScene = () => {
      renderer.render(scene, camera);
    };

    const loadTextureWithUpdate = (url: string, onLoaded: (tex: THREE.Texture) => void) => {
      textureLoader.load(
        url,
        (tex) => {
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
          tex.generateMipmaps = true;
          tex.minFilter = THREE.LinearMipmapLinearFilter;
          onLoaded(tex);
          earthMaterial.needsUpdate = true;
          renderScene();
        },
        undefined,
        (err) => {
          console.warn('Texture load fallback:', url, err);
        }
      );
    };

    // Load NASA Blue Marble photorealistic textures
    if (viewStyle === 'day') {
      loadTextureWithUpdate('/textures/earth_blue_marble.jpg', (tex) => {
        earthMaterial.map = tex;
        earthMaterial.roughness = 0.35;
      });
      loadTextureWithUpdate('/textures/earth_topology.png', (tex) => {
        earthMaterial.bumpMap = tex;
        earthMaterial.bumpScale = 0.032;
      });
    } else if (viewStyle === 'night') {
      loadTextureWithUpdate('/textures/earth_night.jpg', (tex) => {
        earthMaterial.map = tex;
        earthMaterial.emissive = new THREE.Color(0xffeedd);
        earthMaterial.emissiveMap = tex;
        earthMaterial.emissiveIntensity = 1.35;
      });
    } else if (viewStyle === 'topo') {
      loadTextureWithUpdate('/textures/earth_topology.png', (tex) => {
        earthMaterial.map = tex;
        earthMaterial.bumpMap = tex;
        earthMaterial.bumpScale = 0.055;
      });
    }

    // Realistic Rayleigh Atmospheric Scattering Rim Shader (True Earth Azure Halo)
    const atmosphereVertexShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `;

    const atmosphereFragmentShader = `
      varying vec3 vNormal;
      varying vec3 vPosition;
      void main() {
        vec3 viewDir = normalize(-vPosition);
        float rim = 1.0 - max(0.0, dot(vNormal, viewDir));
        float alpha = pow(rim, 3.0) * 0.95;
        // Earth's signature pale cyan-blue atmospheric scattering
        vec3 color = mix(vec3(0.22, 0.62, 1.0), vec3(0.70, 0.90, 1.0), rim);
        gl_FragColor = vec4(color, alpha);
      }
    `;

    const atmosphereGeometry = new THREE.SphereGeometry(earthRadius * 1.025, 64, 64);
    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: atmosphereVertexShader,
      fragmentShader: atmosphereFragmentShader,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    scene.add(atmosphereMesh);

    // Inner Limb Atmosphere Glint
    const innerAtmoGeo = new THREE.SphereGeometry(earthRadius * 1.002, 64, 64);
    const innerAtmoMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float rim = 1.0 - max(0.0, dot(vNormal, vec3(0.0, 0.0, 1.0)));
          float glow = pow(rim, 3.8) * 0.45;
          gl_FragColor = vec4(0.35, 0.72, 1.0, glow);
        }
      `,
      side: THREE.FrontSide,
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
    });
    const innerAtmoMesh = new THREE.Mesh(innerAtmoGeo, innerAtmoMat);
    scene.add(innerAtmoMesh);

    // Cloud Layer with realistic atmospheric elevation and additive blending
    let cloudMesh: THREE.Mesh | null = null;
    let cloudMaterial: THREE.MeshStandardMaterial | null = null;
    let cloudGeometry: THREE.SphereGeometry | null = null;

    if (showClouds && viewStyle !== 'night') {
      cloudGeometry = new THREE.SphereGeometry(earthRadius * 1.010, 64, 64);
      cloudMaterial = new THREE.MeshStandardMaterial({
        transparent: true,
        opacity: 0.72,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        roughness: 0.9,
      });
      cloudMesh = new THREE.Mesh(cloudGeometry, cloudMaterial);
      earthMesh.add(cloudMesh);

      textureLoader.load('/textures/earth_clouds.png', (cloudTex) => {
        cloudTex.colorSpace = THREE.SRGBColorSpace;
        cloudTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
        if (cloudMaterial) {
          cloudMaterial.map = cloudTex;
          cloudMaterial.needsUpdate = true;
          renderScene();
        }
      });
    }

    // Farm Markers on Globe
    const markerGroup = new THREE.Group();
    earthMesh.add(markerGroup);

    const latLngToVector3 = (lat: number, lng: number, radius: number) => {
      const phi = (90 - lat) * (Math.PI / 180);
      const theta = (lng + 180) * (Math.PI / 180);
      const x = -(radius * Math.sin(phi) * Math.cos(theta));
      const z = radius * Math.sin(phi) * Math.sin(theta);
      const y = radius * Math.cos(phi);
      return new THREE.Vector3(x, y, z);
    };

    farms.forEach((farm) => {
      const [lat, lng] = farm.centerCoordinates;
      const pos = latLngToVector3(lat, lng, earthRadius * 1.015);

      // Pin Mesh
      const pinGeom = new THREE.SphereGeometry(0.024, 16, 16);
      const isSelected = farm.id === currentFarm.id;
      const pinMat = new THREE.MeshBasicMaterial({
        color: isSelected ? 0xc5f36b : 0x4fae76,
      });
      const pinMesh = new THREE.Mesh(pinGeom, pinMat);
      pinMesh.position.copy(pos);
      pinMesh.userData = { farmId: farm.id, lat, lng, name: farm.name };
      markerGroup.add(pinMesh);

      // Beacon Ring
      const ringGeom = new THREE.RingGeometry(0.03, 0.045, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: isSelected ? 0xc5f36b : 0x4fae76,
        transparent: true,
        opacity: 0.8,
        side: THREE.DoubleSide,
      });
      const ringMesh = new THREE.Mesh(ringGeom, ringMat);
      ringMesh.position.copy(pos);
      ringMesh.lookAt(new THREE.Vector3(0, 0, 0));
      markerGroup.add(ringMesh);
    });

    // Lighting: Solar Radiance + Deep Space Fill
    const ambientLight = new THREE.AmbientLight(0x22364a, 0.65);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff6ea, 2.6);
    sunLight.position.set(6, 2.5, 4.5);
    scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0x1a3348, 0.4);
    fillLight.position.set(-6, -1.5, -4);
    scene.add(fillLight);

    // Initial orientation: point camera towards active farm
    const initialLat = currentFarm.centerCoordinates[0];
    const initialLng = currentFarm.centerCoordinates[1];
    earthMesh.rotation.y = -((initialLng + 90) * Math.PI) / 180;
    earthMesh.rotation.x = (initialLat * Math.PI) / 180 * 0.4;

    // Interaction State
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      isDragging = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      previousMousePosition = { x: clientX, y: clientY };
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      if (isDragging) {
        const deltaX = clientX - previousMousePosition.x;
        const deltaY = clientY - previousMousePosition.y;

        earthMesh.rotation.y += deltaX * 0.005;
        earthMesh.rotation.x += deltaY * 0.005;
        earthMesh.rotation.x = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, earthMesh.rotation.x));

        previousMousePosition = { x: clientX, y: clientY };
      }
    };

    const onPointerUp = (e: MouseEvent | TouchEvent) => {
      if (isDragging) {
        isDragging = false;
        const rect = renderer.domElement.getBoundingClientRect();
        const clientX = 'changedTouches' in e ? e.changedTouches[0].clientX : e.clientX;
        const clientY = 'changedTouches' in e ? e.changedTouches[0].clientY : e.clientY;

        mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;

        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(markerGroup.children);
        if (intersects.length > 0) {
          const hit = intersects[0].object;
          if (hit.userData && hit.userData.farmId) {
            setCurrentFarmId(hit.userData.farmId);
            setSelectedCoords({ lat: hit.userData.lat, lng: hit.userData.lng });
          }
        }
      }
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', onPointerDown);
    domElement.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    domElement.addEventListener('touchstart', onPointerDown, { passive: true });
    domElement.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchend', onPointerUp);

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      camera.position.z += e.deltaY * 0.0015;
      camera.position.z = Math.max(1.7, Math.min(4.8, camera.position.z));
    };
    domElement.addEventListener('wheel', onWheel, { passive: false });

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      if (autoRotate && !isDragging) {
        earthMesh.rotation.y += 0.0008;
      }
      if (cloudMesh) {
        cloudMesh.rotation.y += 0.0003;
      }
      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.render(scene, camera);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      domElement.removeEventListener('mousedown', onPointerDown);
      domElement.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      domElement.removeEventListener('touchstart', onPointerDown);
      domElement.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);
      domElement.removeEventListener('wheel', onWheel);
      window.removeEventListener('resize', handleResize);

      if (container.contains(domElement)) {
        container.removeChild(domElement);
      }
      renderer.dispose();
      earthGeometry.dispose();
      earthMaterial.dispose();
      atmosphereGeometry.dispose();
      atmosphereMaterial.dispose();
      innerAtmoGeo.dispose();
      innerAtmoMat.dispose();
      cloudGeometry?.dispose();
      cloudMaterial?.dispose();
      initialCanvasTexture.dispose();
    };

  }, [farms, currentFarm, autoRotate, showClouds, viewStyle, setCurrentFarmId]);

  return (
    <div className="relative w-full h-[620px] md:h-[700px] bg-[#08130F] rounded-2xl border border-[#263A2D] overflow-hidden shadow-2xl flex flex-col">
      {/* Globe Controls & Header */}
      <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-auto">
        <div className="bg-[#111F19]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#263A2D] flex items-center gap-2">
          <Globe className="w-4 h-4 text-[#C5F36B]" />
          <span className="text-xs font-bold text-[#F3F7F1]">Photorealistic 3D Earth (NASA Blue Marble)</span>
        </div>

        {/* Layer style selector */}
        <div className="flex items-center gap-1 bg-[#111F19]/90 backdrop-blur-md p-1 rounded-xl border border-[#263A2D]">
          <button
            onClick={() => setViewStyle('day')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
              viewStyle === 'day'
                ? 'bg-[#C5F36B] text-[#08130F] font-bold'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            Day (True Color)
          </button>
          <button
            onClick={() => setViewStyle('night')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
              viewStyle === 'night'
                ? 'bg-[#C5F36B] text-[#08130F] font-bold'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            Night Lights
          </button>
          <button
            onClick={() => setViewStyle('topo')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
              viewStyle === 'topo'
                ? 'bg-[#C5F36B] text-[#08130F] font-bold'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            Topography
          </button>
        </div>

        {/* Clouds toggle */}
        <button
          onClick={() => setShowClouds(!showClouds)}
          className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-colors flex items-center gap-1.5 ${
            showClouds
              ? 'bg-[#17271E] text-[#C5F36B] border-[#C5F36B]/50 font-semibold'
              : 'bg-[#111F19]/90 text-[#9BB0A0] border-[#263A2D]'
          }`}
        >
          <Cloud className="w-3.5 h-3.5" />
          <span>Clouds {showClouds ? 'On' : 'Off'}</span>
        </button>

        {/* Auto rotation toggle */}
        <button
          onClick={() => setAutoRotate(!autoRotate)}
          className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
            autoRotate
              ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B] font-bold'
              : 'bg-[#111F19]/90 text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
          }`}
        >
          {autoRotate ? 'Auto-Rotate On' : 'Paused'}
        </button>
      </div>

      {/* Farm Markers Quick Switcher */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2 max-w-xs pointer-events-auto">
        <div className="bg-[#111F19]/90 backdrop-blur-md p-2 rounded-xl border border-[#263A2D]">
          <span className="text-[11px] font-bold text-[#9BB0A0] uppercase tracking-wider block mb-1">
            Planetary Farm Markers
          </span>
          <div className="space-y-1">
            {farms.map((f) => {
              const isSelected = f.id === currentFarm.id;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setCurrentFarmId(f.id);
                    setSelectedCoords({ lat: f.centerCoordinates[0], lng: f.centerCoordinates[1] });
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    isSelected
                      ? 'bg-[#C5F36B]/20 text-[#C5F36B] border border-[#C5F36B]/40 font-semibold'
                      : 'text-[#F3F7F1] hover:bg-[#17271E] border border-transparent'
                  }`}
                >
                  <span className="truncate">{f.name}</span>
                  <span className="text-[10px] text-[#9BB0A0] ml-2 shrink-0">{f.country}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Three.js Canvas Container */}
      <div ref={containerRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />

      {/* Selected Coordinates & Jump to 2D Map Footer */}
      <div className="absolute bottom-4 left-4 right-4 z-10 bg-[#111F19]/90 backdrop-blur-md p-3.5 rounded-xl border border-[#263A2D] flex flex-col sm:flex-row items-center justify-between gap-3 pointer-events-auto">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#C5F36B]/15 border border-[#C5F36B]/30 flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4 text-[#C5F36B]" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-[#F3F7F1]">{currentFarm.name}</h4>
            <p className="text-xs text-[#9BB0A0]">
              Coordinates: {selectedCoords?.lat.toFixed(4)}°N, {selectedCoords?.lng.toFixed(4)}°E • Climate: {currentFarm.climateZone}
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('map')}
          className="w-full sm:w-auto px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-semibold text-xs rounded-lg flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-md"
        >
          <span>Open Field in 2D Farm Map</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
