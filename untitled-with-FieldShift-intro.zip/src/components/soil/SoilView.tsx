import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import { calculateSoilHealthScore } from '../../domain/calculations';
import {
  FlaskConical,
  Sprout,
  Plus,
  Calendar,
  AlertCircle,
  CheckCircle2,
  FileSpreadsheet,
  Info,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

export const SoilView: React.FC = () => {
  const { currentFarm, currentField, addSoilObservation } = useFarm();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [formPh, setFormPh] = useState<string>('7.4');
  const [formSom, setFormSom] = useState<string>('1.8');
  const [formEc, setFormEc] = useState<string>('2.2');
  const [formN, setFormN] = useState<string>('18');
  const [formP, setFormP] = useState<string>('20');
  const [formK, setFormK] = useState<string>('180');
  const [formBd, setFormBd] = useState<string>('1.35');
  const [formDepth, setFormDepth] = useState<string>('30');
  const [formLab, setFormLab] = useState<string>('Regional Agricultural Extension Soil Lab');
  const [formSource, setFormSource] = useState<'Measured Lab Test' | 'In-Situ Sensor' | 'User Observation'>(
    'Measured Lab Test'
  );
  const [formNotes, setFormNotes] = useState<string>('');

  const currentSoil = currentField.currentSoil;
  const soilHealth = calculateSoilHealthScore(currentSoil);

  const handleSubmitObservation = (e: React.FormEvent) => {
    e.preventDefault();
    const ph = parseFloat(formPh);
    const som = parseFloat(formSom);
    const ec = parseFloat(formEc);
    const n = parseFloat(formN);
    const p = parseFloat(formP);
    const k = parseFloat(formK);
    const bd = parseFloat(formBd);
    const depth = parseFloat(formDepth);

    addSoilObservation(currentField.id, {
      fieldId: currentField.id,
      date: new Date().toISOString().split('T')[0],
      sourceType: formSource,
      laboratory: formLab,
      sampleDepthCm: isNaN(depth) ? 30 : depth,
      ph: isNaN(ph) ? 7.0 : ph,
      organicMatterPercent: isNaN(som) ? 1.5 : som,
      electricalConductivityDsM: isNaN(ec) ? 1.0 : ec,
      nitrogenPpm: isNaN(n) ? 15 : n,
      phosphorusPpm: isNaN(p) ? 15 : p,
      potassiumPpm: isNaN(k) ? 150 : k,
      bulkDensityGPerCm3: isNaN(bd) ? 1.35 : bd,
      notes: formNotes || 'Field observation logged via Soil Diagnostics workspace.',
    });

    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Soil Workspace Hero Header with Real Forest Soil Wallpaper */}
      <div className="relative rounded-3xl overflow-hidden border border-[#263A2D] shadow-2xl min-h-[220px] flex flex-col justify-end p-6 md:p-8">
        <img
          src="/images/forest_soil.jpg"
          alt="Lush Forest Soil Ecosystem & Humus Canopy"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/75 to-[#08130F]/30" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-[11px] font-extrabold bg-[#C5F36B] text-[#08130F] uppercase tracking-wider">
                Pedological & Soil Diagnostics
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#111F19]/90 text-[#9BB0A0] border border-[#263A2D] backdrop-blur-md">
                Coverage: {soilHealth.dataCoveragePercent}%
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#111F19]/90 text-[#4FAE76] border border-[#263A2D] backdrop-blur-md">
                {soilHealth.confidenceRating} Confidence
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-[#F3F7F1]">
              Pedological Health & Soil Diagnostics — {currentField.name}
            </h2>
            <p className="text-xs text-[#d1e0d5] mt-1 max-w-xl">
              Classification: <span className="text-[#F3F7F1] font-semibold">{currentField.soilType}</span> • 
              Organic carbon fractions, CEC, and microbiome vitality on {currentFarm.name}.
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-lg shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Record Soil Test</span>
          </button>
        </div>
      </div>

      {/* Composite Health Index Card & Primary Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Overall Score */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#9BB0A0]">
              Composite Soil Health Index
            </span>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#C5F36B]">
                {soilHealth.compositeScore}
              </span>
              <span className="text-sm text-[#9BB0A0]">/ 100</span>
            </div>
            <p className="text-xs text-[#9BB0A0] mt-1">
              Multi-factor assessment based on measured chemical, organic, and physical soil parameters.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-[#263A2D] space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-[#9BB0A0]">pH Reaction Score</span>
              <span className="text-[#F3F7F1] font-semibold">{soilHealth.phScore}/100</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-[#9BB0A0]">Organic Matter Score</span>
              <span className="text-[#F3F7F1] font-semibold">{soilHealth.somScore}/100</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-[#9BB0A0]">Salinity (EC) Score</span>
              <span className="text-[#F3F7F1] font-semibold">{soilHealth.salinityScore}/100</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-[#9BB0A0]">Nutrient (NPK) Score</span>
              <span className="text-[#F3F7F1] font-semibold">{soilHealth.nutrientScore}/100</span>
            </div>
          </div>
        </div>

        {/* 3 Parameter Breakdown Cards */}
        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Reaction (pH) */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
                <span className="text-xs font-semibold">Soil Acidity / Alkalinity</span>
                <FlaskConical className="w-4 h-4 text-[#facc15]" />
              </div>
              <div className="text-3xl font-extrabold text-[#F3F7F1]">
                pH {currentSoil.ph?.toFixed(1) ?? 'N/A'}
              </div>
              <p className="text-xs text-[#9BB0A0] mt-1">
                Target optimal crop range: 6.2 - 7.5
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-[#263A2D] text-[11px] text-[#4FAE76]">
              {currentSoil.ph && currentSoil.ph > 7.5 ? 'Mildly alkaline calcareous soil' : 'Favorable neutral reaction'}
            </div>
          </div>

          {/* SOM % */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
                <span className="text-xs font-semibold">Soil Organic Matter (SOM)</span>
                <Sprout className="w-4 h-4 text-[#4FAE76]" />
              </div>
              <div className="text-3xl font-extrabold text-[#F3F7F1]">
                {currentSoil.organicMatterPercent?.toFixed(1) ?? 'N/A'}%
              </div>
              <p className="text-xs text-[#9BB0A0] mt-1">
                Target regenerative benchmark: &gt; 2.5%
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-[#263A2D] text-[11px] text-[#9BB0A0]">
              Estimated carbon stock: ~{((currentSoil.organicMatterPercent || 1) * 14).toFixed(0)} t C/ha
            </div>
          </div>

          {/* Salinity / EC */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
                <span className="text-xs font-semibold">Salinity (ECe)</span>
                <TrendingUp className="w-4 h-4 text-[#38bdf8]" />
              </div>
              <div className="text-3xl font-extrabold text-[#F3F7F1]">
                {currentSoil.electricalConductivityDsM?.toFixed(1) ?? 'N/A'} <span className="text-xs font-normal text-[#9BB0A0]">dS/m</span>
              </div>
              <p className="text-xs text-[#9BB0A0] mt-1">
                Threshold for sensitive crops: &lt; 2.0 dS/m
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-[#263A2D] text-[11px] text-[#facc15]">
              {currentSoil.electricalConductivityDsM && currentSoil.electricalConductivityDsM > 3
                ? 'Requires salt-tolerant crops & leaching fraction'
                : 'Low osmotic stress risk'}
            </div>
          </div>
        </div>
      </div>

      {/* Soil Guidance & Limiting Factors */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
        <h3 className="text-sm font-bold text-[#F3F7F1] mb-3 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#C5F36B]" />
          <span>Diagnostic Limiting Factors & Agronomic Recommendations</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <span className="text-xs font-semibold text-[#9BB0A0] block">Identified Limiting Factors:</span>
            {soilHealth.limitingFactors.length > 0 ? (
              soilHealth.limitingFactors.map((factor, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-[#F3F7F1] bg-[#17271E] p-2.5 rounded-lg border border-[#263A2D]">
                  <AlertCircle className="w-4 h-4 text-[#facc15] shrink-0 mt-0.5" />
                  <span>{factor}</span>
                </div>
              ))
            ) : (
              <p className="text-xs text-[#9BB0A0]">No critical limiting soil factors detected.</p>
            )}
          </div>

          <div className="space-y-2">
            <span className="text-xs font-semibold text-[#9BB0A0] block">Actionable Guidance:</span>
            {soilHealth.recommendations.map((rec, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-[#F3F7F1] bg-[#17271E] p-2.5 rounded-lg border border-[#263A2D]">
                <CheckCircle2 className="w-4 h-4 text-[#4FAE76] shrink-0 mt-0.5" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Historical Observations Table */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] overflow-hidden">
        <div className="p-4 border-b border-[#263A2D] flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#C5F36B]" />
            <span>Soil Test History & Provenance Log</span>
          </h3>
          <span className="text-xs text-[#9BB0A0]">
            {currentField.soilHistory.length} Recorded Tests
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#17271E] text-[#9BB0A0] border-b border-[#263A2D]">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Date</th>
                <th className="py-2.5 px-4 font-semibold">Source / Lab</th>
                <th className="py-2.5 px-4 font-semibold">Depth</th>
                <th className="py-2.5 px-4 font-semibold">pH</th>
                <th className="py-2.5 px-4 font-semibold">SOM %</th>
                <th className="py-2.5 px-4 font-semibold">EC (dS/m)</th>
                <th className="py-2.5 px-4 font-semibold">N-P-K (ppm)</th>
                <th className="py-2.5 px-4 font-semibold">Bulk Density</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#263A2D]">
              {currentField.soilHistory.map((rec) => (
                <tr key={rec.id} className="hover:bg-[#17271E]/50 transition-colors">
                  <td className="py-2.5 px-4 font-medium text-[#F3F7F1]">{rec.date}</td>
                  <td className="py-2.5 px-4">
                    <span className="font-semibold text-[#F3F7F1] block">{rec.laboratory || 'In-Situ'}</span>
                    <span className="text-[10px] text-[#9BB0A0]">{rec.sourceType}</span>
                  </td>
                  <td className="py-2.5 px-4 text-[#9BB0A0]">{rec.sampleDepthCm} cm</td>
                  <td className="py-2.5 px-4 font-bold text-[#F3F7F1]">{rec.ph.toFixed(1)}</td>
                  <td className="py-2.5 px-4 font-bold text-[#4FAE76]">{rec.organicMatterPercent.toFixed(1)}%</td>
                  <td className="py-2.5 px-4 text-[#F3F7F1]">{rec.electricalConductivityDsM.toFixed(1)}</td>
                  <td className="py-2.5 px-4 text-[#9BB0A0]">
                    {rec.nitrogenPpm}-{rec.phosphorusPpm}-{rec.potassiumPpm}
                  </td>
                  <td className="py-2.5 px-4 text-[#9BB0A0]">{rec.bulkDensityGPerCm3.toFixed(2)} g/cm³</td>
                </tr>
              ))}
              {currentField.soilHistory.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-6 text-center text-[#9BB0A0]">
                    No historical records logged yet for this field.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Observation Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[1000] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111F19] border border-[#263A2D] rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#263A2D] pb-3">
              <h3 className="text-base font-bold text-[#F3F7F1] flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-[#C5F36B]" />
                <span>Record Certified Soil Test</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#9BB0A0] hover:text-[#F3F7F1] text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitObservation} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Source / Test Type</label>
                  <select
                    value={formSource}
                    onChange={(e: any) => setFormSource(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  >
                    <option value="Measured Lab Test">Measured Lab Test</option>
                    <option value="In-Situ Sensor">In-Situ Sensor</option>
                    <option value="User Observation">User Observation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Laboratory Name</label>
                  <input
                    type="text"
                    value={formLab}
                    onChange={(e) => setFormLab(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Soil pH</label>
                  <input
                    type="number"
                    step="0.1"
                    min="3"
                    max="11"
                    value={formPh}
                    onChange={(e) => setFormPh(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">SOM (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    max="15"
                    value={formSom}
                    onChange={(e) => setFormSom(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">EC (dS/m)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="30"
                    value={formEc}
                    onChange={(e) => setFormEc(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Nitrogen (ppm)</label>
                  <input
                    type="number"
                    value={formN}
                    onChange={(e) => setFormN(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Phosphorus (ppm)</label>
                  <input
                    type="number"
                    value={formP}
                    onChange={(e) => setFormP(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Potassium (ppm)</label>
                  <input
                    type="number"
                    value={formK}
                    onChange={(e) => setFormK(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Bulk Density (g/cm³)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formBd}
                    onChange={(e) => setFormBd(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Sample Depth (cm)</label>
                  <input
                    type="number"
                    value={formDepth}
                    onChange={(e) => setFormDepth(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#9BB0A0] mb-1">Agronomic Notes & Observations</label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Sample collected after deep tillage pass, calcium carbonate nodules present."
                  className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#263A2D]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#17271E] text-[#9BB0A0] hover:text-[#F3F7F1] rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C5F36B] text-[#08130F] font-bold rounded-lg shadow-md hover:bg-[#b2e552]"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
