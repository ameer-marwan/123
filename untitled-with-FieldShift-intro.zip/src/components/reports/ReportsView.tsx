import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import { formatArea, formatTemperature, formatCurrency } from '../../lib/i18n';
import { getCropById } from '../../domain/cropCatalog';
import { calculateSoilHealthScore, scoreCropRotation } from '../../domain/calculations';
import {
  Printer,
  FileCheck,
  CheckSquare,
  Square,
  Shield,
  Layers,
  Calendar,
  Sparkles,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { currentFarm, currentField, weather, unitSystem, currency } = useFarm();

  const [includeWeather, setIncludeWeather] = useState(true);
  const [includeSoil, setIncludeSoil] = useState(true);
  const [includeRotation, setIncludeRotation] = useState(true);
  const [includeRecommendations, setIncludeRecommendations] = useState(true);

  const activeCrop = getCropById(currentField.activeCropId);
  const soilHealth = calculateSoilHealthScore(currentField.currentSoil);

  const activePlan = currentField.cropPlans.find((p) => p.id === currentField.activePlanId) || currentField.cropPlans[0];
  const planCrops = (activePlan?.seasons || []).map((s) => getCropById(s.cropId)).filter(Boolean) as any[];

  const rotationEvaluation = scoreCropRotation(
    planCrops.length > 0 ? planCrops : activeCrop ? [activeCrop] : [],
    {
      waterConservation: 70,
      soilImprovement: 80,
      yieldPotential: 60,
      profitability: 70,
      riskReduction: 65,
      lowInput: 60,
    },
    currentField.currentSoil,
    320
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              FieldShift Reporting Engine
            </span>
            <span className="text-xs text-[#9BB0A0]">
              Certified Agronomic Dossier
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Comprehensive Field Audit Report — {currentField.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Generate print-ready agricultural intelligence reports including soil diagnostics, rotation sequences, and risk factors.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-md"
        >
          <Printer className="w-4 h-4" />
          <span>Print / Save PDF</span>
        </button>
      </div>

      {/* Selectable Report Sections Toggle (Print Hidden) */}
      <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D] flex flex-wrap items-center gap-4 text-xs print:hidden">
        <span className="text-[#9BB0A0] font-semibold">Include in Report:</span>

        <button
          onClick={() => setIncludeWeather(!includeWeather)}
          className="flex items-center gap-1.5 text-[#F3F7F1] hover:text-[#C5F36B]"
        >
          {includeWeather ? <CheckSquare className="w-4 h-4 text-[#C5F36B]" /> : <Square className="w-4 h-4 text-[#9BB0A0]" />}
          <span>Agrometeorology</span>
        </button>

        <button
          onClick={() => setIncludeSoil(!includeSoil)}
          className="flex items-center gap-1.5 text-[#F3F7F1] hover:text-[#C5F36B]"
        >
          {includeSoil ? <CheckSquare className="w-4 h-4 text-[#C5F36B]" /> : <Square className="w-4 h-4 text-[#9BB0A0]" />}
          <span>Soil Diagnostics</span>
        </button>

        <button
          onClick={() => setIncludeRotation(!includeRotation)}
          className="flex items-center gap-1.5 text-[#F3F7F1] hover:text-[#C5F36B]"
        >
          {includeRotation ? <CheckSquare className="w-4 h-4 text-[#C5F36B]" /> : <Square className="w-4 h-4 text-[#9BB0A0]" />}
          <span>Rotation & Yield</span>
        </button>

        <button
          onClick={() => setIncludeRecommendations(!includeRecommendations)}
          className="flex items-center gap-1.5 text-[#F3F7F1] hover:text-[#C5F36B]"
        >
          {includeRecommendations ? <CheckSquare className="w-4 h-4 text-[#C5F36B]" /> : <Square className="w-4 h-4 text-[#9BB0A0]" />}
          <span>Recommendations</span>
        </button>
      </div>

      {/* Printable Report Document Sheet */}
      <div className="bg-[#0f1c16] text-[#F3F7F1] p-8 md:p-10 rounded-2xl border border-[#263A2D] shadow-2xl print:border-none print:shadow-none print:p-0 print:bg-white print:text-black">
        {/* Document Header */}
        <div className="border-b border-[#263A2D] pb-6 mb-6 print:border-black">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-3 h-3 rounded-full bg-[#C5F36B]" />
                <span className="font-extrabold text-base tracking-widest text-[#C5F36B] uppercase">
                  FieldShift Intelligence
                </span>
              </div>
              <h1 className="text-2xl font-black text-[#F3F7F1] print:text-black">
                Official Agronomic Field Evaluation Report
              </h1>
            </div>
            <div className="text-right text-xs text-[#9BB0A0] print:text-gray-600">
              <p>Generated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
              <p>Report Ref: FS-DOC-{Date.now().toString().slice(-6)}</p>
            </div>
          </div>

          {/* Farm & Field Meta Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 text-xs bg-[#17271E] p-4 rounded-xl border border-[#263A2D] print:bg-gray-100 print:border-gray-300">
            <div>
              <span className="text-[#9BB0A0] print:text-gray-600 block text-[10px] uppercase font-bold">Farm Holding</span>
              <span className="font-bold text-[#F3F7F1] print:text-black">{currentFarm.name}</span>
              <span className="block text-[11px] text-[#9BB0A0] print:text-gray-500">{currentFarm.region}, {currentFarm.country}</span>
            </div>
            <div>
              <span className="text-[#9BB0A0] print:text-gray-600 block text-[10px] uppercase font-bold">Field Parcel</span>
              <span className="font-bold text-[#F3F7F1] print:text-black">{currentField.name}</span>
              <span className="block text-[11px] text-[#9BB0A0] print:text-gray-500">Area: {formatArea(currentField.areaHa, unitSystem)}</span>
            </div>
            <div>
              <span className="text-[#9BB0A0] print:text-gray-600 block text-[10px] uppercase font-bold">Coordinates</span>
              <span className="font-mono text-[#F3F7F1] print:text-black">
                {currentFarm.centerCoordinates[0].toFixed(4)}°N, {currentFarm.centerCoordinates[1].toFixed(4)}°E
              </span>
              <span className="block text-[11px] text-[#9BB0A0] print:text-gray-500">Elevation: {currentFarm.elevationMeters}m</span>
            </div>
            <div>
              <span className="text-[#9BB0A0] print:text-gray-600 block text-[10px] uppercase font-bold">Current Crop</span>
              <span className="font-bold text-[#C5F36B] print:text-green-700">{activeCrop?.name || currentField.activeCropId}</span>
              <span className="block text-[11px] text-[#9BB0A0] print:text-gray-500">System: {currentField.irrigationSystem}</span>
            </div>
          </div>
        </div>

        {/* Section 1: Agrometeorology */}
        {includeWeather && (
          <div className="mb-6 pb-6 border-b border-[#263A2D] print:border-gray-300">
            <h3 className="text-sm font-bold text-[#C5F36B] print:text-green-800 uppercase tracking-wider mb-3">
              1. Agrometeorological Conditions & ET0
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Air Temperature</span>
                <span className="text-base font-bold text-[#F3F7F1] print:text-black">
                  {formatTemperature(weather.current?.temperatureC || 28, unitSystem)}
                </span>
                <span className="text-[10px] text-[#4FAE76]">Open-Meteo Live API</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Relative Humidity</span>
                <span className="text-base font-bold text-[#F3F7F1] print:text-black">
                  {weather.current?.relativeHumidity || 32}%
                </span>
                <span className="text-[10px] text-[#9BB0A0]">Atmospheric Vapor</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Reference ET (ET0)</span>
                <span className="text-base font-bold text-[#F3F7F1] print:text-black">
                  {weather.daily[0]?.et0Mm?.toFixed(1) || '4.8'} mm/day
                </span>
                <span className="text-[10px] text-[#9BB0A0]">Penman-Monteith</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">7-Day Precipitation</span>
                <span className="text-base font-bold text-[#F3F7F1] print:text-black">
                  {weather.daily.reduce((sum, d) => sum + d.precipSumMm, 0)} mm
                </span>
                <span className="text-[10px] text-sky-400">Summed Forecast</span>
              </div>
            </div>
          </div>
        )}

        {/* Section 2: Soil Health Diagnostics */}
        {includeSoil && (
          <div className="mb-6 pb-6 border-b border-[#263A2D] print:border-gray-300">
            <h3 className="text-sm font-bold text-[#C5F36B] print:text-green-800 uppercase tracking-wider mb-3">
              2. Pedological & Soil Diagnostic Status
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mb-3">
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Soil pH</span>
                <span className="text-base font-bold text-[#F3F7F1] print:text-black">
                  pH {currentField.currentSoil.ph?.toFixed(1) || 'N/A'}
                </span>
                <span className="text-[10px] text-[#9BB0A0]">Lab Measured</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Organic Matter (SOM)</span>
                <span className="text-base font-bold text-[#4FAE76] print:text-green-700">
                  {currentField.currentSoil.organicMatterPercent?.toFixed(1) || 'N/A'}%
                </span>
                <span className="text-[10px] text-[#9BB0A0]">Top 30cm Profile</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Salinity (ECe)</span>
                <span className="text-base font-bold text-amber-400 print:text-amber-700">
                  {currentField.currentSoil.electricalConductivityDsM?.toFixed(1) || 'N/A'} dS/m
                </span>
                <span className="text-[10px] text-[#9BB0A0]">Saturated Paste</span>
              </div>
              <div className="p-3 rounded-lg bg-[#111F19] border border-[#263A2D] print:bg-white print:border-gray-200">
                <span className="text-[#9BB0A0] print:text-gray-500 block text-[10px]">Composite Health Index</span>
                <span className="text-base font-bold text-[#C5F36B] print:text-green-700">
                  {soilHealth.compositeScore}/100
                </span>
                <span className="text-[10px] text-[#9BB0A0]">{soilHealth.confidenceRating} Confidence</span>
              </div>
            </div>
          </div>
        )}

        {/* Section 3: Rotation Sequence & Financials */}
        {includeRotation && (
          <div className="mb-6 pb-6 border-b border-[#263A2D] print:border-gray-300">
            <h3 className="text-sm font-bold text-[#C5F36B] print:text-green-800 uppercase tracking-wider mb-3">
              3. Planned Crop Rotation & Operating Projections
            </h3>
            <p className="text-xs text-[#9BB0A0] print:text-gray-600 mb-3">
              Active Strategy: <span className="text-[#F3F7F1] print:text-black font-semibold">{activePlan?.name || 'Standard Sequence'}</span> • 
              Rotation Resilience Score: <span className="text-[#C5F36B] print:text-green-700 font-bold">{rotationEvaluation.overallScore}/100</span> • 
              Projected Annual Margin: <span className="text-[#C5F36B] print:text-green-700 font-bold">{formatCurrency(rotationEvaluation.netOperatingMarginPerHa, currency)}/ha</span>
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#17271E] text-[#9BB0A0] print:bg-gray-100 print:text-black">
                  <tr>
                    <th className="p-2">Season</th>
                    <th className="p-2">Crop</th>
                    <th className="p-2">Category</th>
                    <th className="p-2">Target Yield</th>
                    <th className="p-2">Planned Water</th>
                    <th className="p-2">Synthetic N</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#263A2D] print:divide-gray-200">
                  {(activePlan?.seasons || []).map((s, idx) => {
                    const c = getCropById(s.cropId);
                    return (
                      <tr key={idx}>
                        <td className="p-2 font-medium">{s.seasonLabel}</td>
                        <td className="p-2 font-bold text-[#F3F7F1] print:text-black">{c?.name || s.cropId}</td>
                        <td className="p-2 text-[#9BB0A0] print:text-gray-600">{c?.category}</td>
                        <td className="p-2">{s.targetYieldTonPerHa} t/ha</td>
                        <td className="p-2 text-sky-400 print:text-blue-700">{s.plannedIrrigationMm} mm</td>
                        <td className="p-2 text-amber-400 print:text-amber-700">{s.syntheticNitrogenKgPerHa} kg/ha</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Section 4: Recommendations & Disclaimers */}
        {includeRecommendations && (
          <div>
            <h3 className="text-sm font-bold text-[#C5F36B] print:text-green-800 uppercase tracking-wider mb-2">
              4. Key Agronomic Directives & Scientific Disclaimers
            </h3>
            <ul className="list-disc pl-5 space-y-1 text-xs text-[#9BB0A0] print:text-gray-700">
              <li>
                <strong>Irrigation Leaching Requirement:</strong> Maintain minimum 12% leaching fraction during summer irrigation cycles to flush capillary salt accumulation below root zone.
              </li>
              <li>
                <strong>Residue Preservation:</strong> Retain 100% of grain straw residue to build soil organic carbon fractions and minimize direct solar evaporation.
              </li>
              <li>
                <strong>Scientific Boundary Notice:</strong> Model-generated yields and water balances are decision-support projections grounded in FAO-56 Penman-Monteith principles and are subject to localized microclimates and pest pressures.
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
