import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import { useFarm } from '../../context/FarmContext';
import { formatArea } from '../../lib/i18n';
import { calculatePolygonAreaHectares } from '../../domain/calculations';
import {
  Layers,
  MapPin,
  Search,
  PenTool,
  Check,
  RotateCcw,
  Sparkles,
  Maximize2,
  Info,
} from 'lucide-react';

export const LeafletFarmMap: React.FC = () => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const drawPolylineRef = useRef<L.Polyline | null>(null);

  const {
    currentFarm,
    currentField,
    setCurrentFieldId,
    unitSystem,
    updateFieldBoundary,
    showNotification,
  } = useFarm();

  const [mapType, setMapType] = useState<'satellite' | 'street'>('satellite');
  const [overlayMode, setOverlayMode] = useState<'none' | 'ndvi' | 'moisture'>('none');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  // Boundary Drawing State
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawnPoints, setDrawnPoints] = useState<Array<[number, number]>>([]);

  const centerCoords = currentFarm.centerCoordinates;

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Fix default marker icon assets path in Leaflet
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    });

    const map = L.map(mapContainerRef.current, {
      center: centerCoords,
      zoom: 14,
      zoomControl: true,
      attributionControl: true,
    });

    mapInstanceRef.current = map;
    layerGroupRef.current = L.layerGroup().addTo(map);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Sync Base Tile Layer (Satellite vs Street)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing tile layers
    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    if (mapType === 'satellite') {
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
        maxZoom: 19,
      }).addTo(map);
    } else {
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);
    }
  }, [mapType]);

  // Handle Map Click when Drawing
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const onMapClick = (e: L.LeafletMouseEvent) => {
      if (!isDrawing) return;
      const newPt: [number, number] = [e.latlng.lat, e.latlng.lng];
      setDrawnPoints((prev) => [...prev, newPt]);
    };

    map.on('click', onMapClick);
    return () => {
      map.off('click', onMapClick);
    };
  }, [isDrawing]);

  // Update Drawing Polyline on map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (drawPolylineRef.current) {
      map.removeLayer(drawPolylineRef.current);
      drawPolylineRef.current = null;
    }

    if (isDrawing && drawnPoints.length > 0) {
      drawPolylineRef.current = L.polyline(drawnPoints, {
        color: '#C5F36B',
        weight: 3,
        dashArray: '5, 8',
      }).addTo(map);
    }
  }, [isDrawing, drawnPoints]);

  // Render Field Boundaries & Markers
  const renderFields = useCallback(() => {
    const map = mapInstanceRef.current;
    const group = layerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();

    currentFarm.fields.forEach((field) => {
      const isSelected = field.id === currentField.id;
      const coords = field.boundary.coordinates;

      if (coords && coords.length >= 3) {
        // Field Polygon
        const polygon = L.polygon(coords, {
          color: isSelected ? '#C5F36B' : '#4FAE76',
          weight: isSelected ? 3 : 2,
          fillColor:
            overlayMode === 'ndvi'
              ? isSelected ? '#22c55e' : '#15803d'
              : overlayMode === 'moisture'
              ? '#0284c7'
              : isSelected ? '#C5F36B' : '#4FAE76',
          fillOpacity: isSelected ? 0.38 : 0.22,
        });

        polygon.on('click', () => {
          if (!isDrawing) {
            setCurrentFieldId(field.id);
          }
        });

        polygon.bindTooltip(
          `<div style="font-family: sans-serif; font-size: 11px; padding: 2px 4px;">
            <strong>${field.name}</strong><br/>
            Area: ${formatArea(field.areaHa, unitSystem)}<br/>
            Crop: ${field.activeCropId.toUpperCase()}<br/>
            Soil: ${field.soilType}
          </div>`,
          { permanent: false, direction: 'center' }
        );

        group.addLayer(polygon);

        // Center marker for selected field
        if (isSelected) {
          const firstCoord = coords[0];
          const marker = L.circleMarker(firstCoord, {
            radius: 6,
            color: '#FFFFFF',
            fillColor: '#C5F36B',
            fillOpacity: 1,
            weight: 2,
          });
          group.addLayer(marker);
        }
      }
    });
  }, [currentFarm, currentField, overlayMode, unitSystem, isDrawing, setCurrentFieldId]);

  useEffect(() => {
    renderFields();
  }, [renderFields]);

  // Fit map to selected field when currentField changes
  const fitToSelectedField = useCallback(() => {
    const map = mapInstanceRef.current;
    if (!map || !currentField.boundary.coordinates.length) return;
    const bounds = L.latLngBounds(currentField.boundary.coordinates);
    map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
  }, [currentField]);

  useEffect(() => {
    fitToSelectedField();
  }, [fitToSelectedField]);

  // Geocoding or Coordinate Search
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearching(true);

    try {
      // Check if coordinates format: "24.1558, 47.3120"
      const coordMatch = searchQuery.match(/^(-?\d+(\.\d+)?),\s*(-?\d+(\.\d+)?)$/);
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1]);
        const lng = parseFloat(coordMatch[3]);
        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([lat, lng], 15);
          showNotification(`Navigated to coordinates: ${lat}, ${lng}`, 'info');
        }
        setIsSearching(false);
        return;
      }

      // Nominatim search
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
      const results = await res.json();
      if (results && results.length > 0) {
        const first = results[0];
        const lat = parseFloat(first.lat);
        const lon = parseFloat(first.lon);
        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([lat, lon], 14);
          showNotification(`Found: ${first.display_name}`, 'success');
        }
      } else {
        showNotification('Location not found. Please try another place or lat,lng.', 'warning');
      }
    } catch (err: any) {
      showNotification('Geocoding search failed. Please check internet connection.', 'warning');
    } finally {
      setIsSearching(false);
    }
  };

  // Complete Boundary Drawing
  const handleFinishDrawing = () => {
    if (drawnPoints.length < 3) {
      showNotification('A field boundary requires at least 3 points.', 'warning');
      return;
    }

    updateFieldBoundary(currentField.id, drawnPoints);
    setIsDrawing(false);
    setDrawnPoints([]);
  };

  const handleCancelDrawing = () => {
    setIsDrawing(false);
    setDrawnPoints([]);
    showNotification('Boundary drawing cancelled.', 'info');
  };

  return (
    <div className="relative w-full h-[620px] md:h-[720px] bg-[#08130F] rounded-2xl border border-[#263A2D] overflow-hidden shadow-2xl flex flex-col">
      {/* Top Search & Toolbar */}
      <div className="absolute top-4 left-4 right-4 z-[500] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 pointer-events-auto">
        <form onSubmit={handleSearch} className="flex-1 max-w-md relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search farm location or latitude, longitude..."
            className="w-full pl-9 pr-24 py-2 bg-[#111F19]/95 backdrop-blur-md text-xs text-[#F3F7F1] placeholder-[#9BB0A0] border border-[#263A2D] rounded-xl focus:outline-none focus:border-[#C5F36B] transition-colors"
          />
          <Search className="w-4 h-4 text-[#9BB0A0] absolute left-3 top-2.5" />
          <button
            type="submit"
            disabled={isSearching}
            className="absolute right-1.5 top-1 px-3 py-1 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] text-[11px] font-semibold rounded-lg border border-[#263A2D] transition-colors"
          >
            {isSearching ? 'Locating...' : 'Locate'}
          </button>
        </form>

        <div className="flex items-center gap-1.5 bg-[#111F19]/95 backdrop-blur-md p-1 rounded-xl border border-[#263A2D]">
          {/* Layer switch */}
          <button
            onClick={() => setMapType(mapType === 'satellite' ? 'street' : 'satellite')}
            className="px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 text-[#F3F7F1] hover:bg-[#17271E] transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-[#C5F36B]" />
            <span>{mapType === 'satellite' ? 'Satellite' : 'Street'}</span>
          </button>

          {/* Overlays */}
          <button
            onClick={() => setOverlayMode(overlayMode === 'ndvi' ? 'none' : 'ndvi')}
            className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              overlayMode === 'ndvi'
                ? 'bg-[#22c55e]/20 text-[#22c55e] border border-[#22c55e]/40'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            NDVI
          </button>
          <button
            onClick={() => setOverlayMode(overlayMode === 'moisture' ? 'none' : 'moisture')}
            className={`px-2 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              overlayMode === 'moisture'
                ? 'bg-[#0284c7]/20 text-[#0284c7] border border-[#0284c7]/40'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            Moisture
          </button>

          {/* Recenter */}
          <button
            onClick={fitToSelectedField}
            title="Fit to Selected Field"
            className="p-1.5 text-[#9BB0A0] hover:text-[#C5F36B] hover:bg-[#17271E] rounded-lg transition-colors"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Boundary Drawing Banner */}
      {isDrawing && (
        <div className="absolute top-18 left-4 right-4 z-[500] bg-[#111F19]/95 backdrop-blur-md border border-[#C5F36B] p-3 rounded-xl flex items-center justify-between gap-3 shadow-xl">
          <div className="flex items-center gap-2">
            <PenTool className="w-4 h-4 text-[#C5F36B] animate-pulse" />
            <div>
              <p className="text-xs font-semibold text-[#F3F7F1]">
                Drawing Field Boundary ({drawnPoints.length} points placed)
              </p>
              <p className="text-[11px] text-[#9BB0A0]">
                Click on the map to place vertices of the agricultural parcel.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleFinishDrawing}
              disabled={drawnPoints.length < 3}
              className="px-3 py-1.5 bg-[#C5F36B] text-[#08130F] font-bold text-xs rounded-lg flex items-center gap-1.5 disabled:opacity-40"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Polygon</span>
            </button>
            <button
              onClick={handleCancelDrawing}
              className="px-3 py-1.5 bg-[#17271E] text-[#9BB0A0] hover:text-[#F3F7F1] text-xs rounded-lg border border-[#263A2D]"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Leaflet DOM container */}
      <div ref={mapContainerRef} className="w-full flex-1 z-0" />

      {/* Field Details & Actions Bottom Panel */}
      <div className="absolute bottom-4 left-4 right-4 z-[500] bg-[#111F19]/95 backdrop-blur-md p-3.5 rounded-xl border border-[#263A2D] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pointer-events-auto">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#C5F36B]/15 border border-[#C5F36B]/30 flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4 text-[#C5F36B]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-[#F3F7F1]">{currentField.name}</h4>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#17271E] text-[#C5F36B] border border-[#263A2D] font-mono">
                {formatArea(currentField.areaHa, unitSystem)}
              </span>
            </div>
            <p className="text-xs text-[#9BB0A0]">
              Soil: <span className="text-[#F3F7F1]">{currentField.soilType}</span> • System:{' '}
              <span className="text-[#F3F7F1]">{currentField.irrigationSystem}</span> • Crop:{' '}
              <span className="text-[#C5F36B] font-medium">{currentField.activeCropId.toUpperCase()}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isDrawing ? (
            <button
              onClick={() => {
                setIsDrawing(true);
                setDrawnPoints([]);
                showNotification('Click on map to draw field boundary vertices.', 'info');
              }}
              className="px-3 py-2 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] font-semibold text-xs rounded-lg border border-[#263A2D] flex items-center gap-2 transition-colors"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>Redraw Field Boundary</span>
            </button>
          ) : null}

          {/* Field Selector Dropdown */}
          <select
            value={currentField.id}
            onChange={(e) => setCurrentFieldId(e.target.value)}
            className="px-3 py-2 bg-[#17271E] text-[#F3F7F1] text-xs font-medium rounded-lg border border-[#263A2D] focus:outline-none focus:border-[#C5F36B]"
          >
            {currentFarm.fields.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name} ({formatArea(f.areaHa, unitSystem)})
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
