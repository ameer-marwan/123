import React from 'react';
import { useFarm } from '../../context/FarmContext';
import {
  Settings,
  Languages,
  Moon,
  Sun,
  Scale,
  Coins,
  RotateCcw,
  Shield,
  HelpCircle,
  Building,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    currentFarm,
    theme,
    setTheme,
    language,
    setLanguage,
    unitSystem,
    setUnitSystem,
    currency,
    setCurrency,
    resetDemoData,
    showNotification,
  } = useFarm();

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
            Platform Configuration
          </span>
        </div>
        <h2 className="text-xl font-bold text-[#F3F7F1]">
          FieldShift System & Farm Preferences
        </h2>
        <p className="text-xs text-[#9BB0A0]">
          Customize language, right-to-left layout, measurement units, and theme.
        </p>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Language & Direction */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#F3F7F1]">
            <Languages className="w-4 h-4 text-[#C5F36B]" />
            <span>Language & Directionality</span>
          </div>
          <p className="text-xs text-[#9BB0A0]">
            FieldShift supports English (LTR) and Arabic (RTL) with culturally native terminology.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => {
                setLanguage('en');
                showNotification('Switched to English.', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                language === 'en'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <span>English (LTR)</span>
            </button>

            <button
              onClick={() => {
                setLanguage('ar');
                showNotification('تم التبديل إلى اللغة العربية.', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                language === 'ar'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <span>العربية (RTL)</span>
            </button>
          </div>
        </div>

        {/* Visual Theme */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#F3F7F1]">
            <Moon className="w-4 h-4 text-[#C5F36B]" />
            <span>Visual Theme</span>
          </div>
          <p className="text-xs text-[#9BB0A0]">
            Choose between dark forest night mode (primary) and daylight field contrast mode.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => {
                setTheme('dark');
                showNotification('Dark forest theme activated.', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                theme === 'dark'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <Moon className="w-4 h-4" />
              <span>Dark Forest (Default)</span>
            </button>

            <button
              onClick={() => {
                setTheme('light');
                showNotification('Light theme activated.', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                theme === 'light'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <Sun className="w-4 h-4" />
              <span>Daylight Field</span>
            </button>
          </div>
        </div>

        {/* Measurement Units */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#F3F7F1]">
            <Scale className="w-4 h-4 text-[#C5F36B]" />
            <span>Agronomic Unit System</span>
          </div>
          <p className="text-xs text-[#9BB0A0]">
            Toggle between international metric (hectares, mm, °C, m³) and US customary units.
          </p>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => {
                setUnitSystem('metric');
                showNotification('Switched to Metric units (ha, mm, °C).', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                unitSystem === 'metric'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <span>Metric (ha, mm, °C, m³)</span>
            </button>

            <button
              onClick={() => {
                setUnitSystem('imperial');
                showNotification('Switched to Imperial units (ac, in, °F, gal).', 'info');
              }}
              className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                unitSystem === 'imperial'
                  ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                  : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
              }`}
            >
              <span>Imperial (ac, in, °F, gal)</span>
            </button>
          </div>
        </div>

        {/* Currency Display */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#F3F7F1]">
            <Coins className="w-4 h-4 text-[#C5F36B]" />
            <span>Operational Currency</span>
          </div>
          <p className="text-xs text-[#9BB0A0]">
            Financial valuations, seed costs, and operating margins format in selected currency.
          </p>

          <div className="grid grid-cols-3 gap-2 pt-2">
            {(['SAR', 'USD', 'EUR'] as const).map((curr) => (
              <button
                key={curr}
                onClick={() => {
                  setCurrency(curr);
                  showNotification(`Currency set to ${curr}.`, 'info');
                }}
                className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center transition-colors ${
                  currency === curr
                    ? 'bg-[#C5F36B] text-[#08130F] border-[#C5F36B]'
                    : 'bg-[#17271E] text-[#9BB0A0] border-[#263A2D] hover:text-[#F3F7F1]'
                }`}
              >
                <span>{curr}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Demo Reset Card */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>Reset Demo Farm State</span>
          </h3>
          <p className="text-xs text-[#9BB0A0] mt-1">
            Re-initializes all farm boundaries, crop rotations, soil tests, and irrigation events to factory benchmark state.
          </p>
        </div>

        <button
          onClick={resetDemoData}
          className="px-4 py-2 bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30 text-xs font-bold rounded-xl transition-colors shrink-0"
        >
          Reset Demo Data
        </button>
      </div>
    </div>
  );
};
