import React from 'react';
import { useFarm } from '../../context/FarmContext';
import {
  formatArea,
  formatTemperature,
  formatDepth,
  formatCurrency,
} from '../../lib/i18n';
import {
  calculateWaterBalance,
  calculateSoilHealthScore,
  scoreCropRotation,
} from '../../domain/calculations';
import { getCropById } from '../../domain/cropCatalog';
import {
  Thermometer,
  CloudRain,
  Droplet,
  FlaskConical,
  Sprout,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowUpRight,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

export const OverviewView: React.FC = () => {
  const {
    currentFarm,
    currentField,
    weather,
    refreshWeather,
    unitSystem,
    currency,
    t,
    setActiveTab,
  } = useFarm();

  const activeCrop = getCropById(currentField.activeCropId);
  const soilScore = calculateSoilHealthScore(currentField.currentSoil);

  // Water Balance estimate
  const currentTemp = weather.current?.temperatureC ?? 28;
  const currentPrecip = weather.current?.precipitationMm ?? 0;
  const waterBalance = calculateWaterBalance({
    precipitationMm: currentPrecip,
    irrigationMm: currentField.irrigationEvents[0]?.depthMm ?? 35,
    et0Mm: weather.daily[0]?.et0Mm ?? 5.0,
    cropCoefficientKc: 0.95,
  });

  // Active Rotation Plan
  const activePlan = currentField.cropPlans.find((p) => p.id === currentField.activePlanId) || currentField.cropPlans[0];
  const plannedCrops = (activePlan?.seasons || [])
    .map((s) => getCropById(s.cropId))
    .filter(Boolean) as any[];

  const rotationEvaluation = scoreCropRotation(
    plannedCrops.length > 0 ? plannedCrops : activeCrop ? [activeCrop] : [],
    {
      waterConservation: 70,
      soilImprovement: 80,
      yieldPotential: 60,
      profitability: 70,
      riskReduction: 65,
      lowInput: 60,
    },
    currentField.currentSoil,
    300
  );

  return (
    <div className="space-y-6">
      {/* Top Banner: Farm Context & Provenance Badges with Agricultural Wallpaper */}
      <div className="relative rounded-3xl overflow-hidden border border-[#263A2D] shadow-2xl min-h-[220px] flex flex-col justify-end p-6 md:p-8">
        <img
          src="/images/agricultural_field.jpg"
          alt="DAIS Agricultural Landscape"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/80 to-[#08130F]/30" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-[11px] font-extrabold bg-[#C5F36B] text-[#08130F] uppercase tracking-wider">
                {currentFarm.country}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#111F19]/90 text-[#d1e0d5] border border-[#263A2D] backdrop-blur-md">
                Climate: {currentFarm.climateZone}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#111F19]/90 text-[#4FAE76] border border-[#263A2D] backdrop-blur-md">
                Telemetry: {weather.source}
              </span>
            </div>

            <h1 className="text-xl sm:text-3xl font-black text-[#F3F7F1]">
              {currentFarm.name} — <span className="text-[#C5F36B]">{currentField.name}</span>
            </h1>
            <p className="text-xs text-[#d1e0d5] mt-1.5 max-w-xl">
              Parcel Area: <span className="text-[#F3F7F1] font-bold">{formatArea(currentField.areaHa, unitSystem)}</span> • 
              Irrigation: <span className="text-[#F3F7F1] font-semibold">{currentField.irrigationSystem}</span> • 
              Soil: <span className="text-[#F3F7F1] font-semibold">{currentField.soilType}</span>
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => refreshWeather()}
              disabled={weather.isLoading}
              className="px-3.5 py-2 bg-[#17271E]/90 hover:bg-[#263A2D] text-[#C5F36B] rounded-xl border border-[#263A2D] text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50 backdrop-blur-md shadow-md"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${weather.isLoading ? 'animate-spin' : ''}`} />
              <span>Sync Live Weather</span>
            </button>
            <button
              onClick={() => setActiveTab('map')}
              className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b5e759] text-[#08130F] font-bold text-xs rounded-xl flex items-center gap-1.5 transition-transform active:scale-95 shadow-md"
            >
              <span>Open Farm Map</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Key Agronomic Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* 1. Temperature */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Temperature</span>
            <Thermometer className="w-4 h-4 text-[#C5F36B]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#F3F7F1]">
              {formatTemperature(currentTemp, unitSystem)}
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              High {formatTemperature(weather.daily[0]?.tempMaxC ?? currentTemp + 4, unitSystem)}
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#4FAE76] font-mono">Live Open-Meteo</span>
        </div>

        {/* 2. Precipitation */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Precipitation</span>
            <CloudRain className="w-4 h-4 text-[#38bdf8]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#F3F7F1]">
              {formatDepth(currentPrecip, unitSystem)}
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              Rain prob: {weather.daily[0]?.precipProbMax ?? 0}%
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#4FAE76] font-mono">7-Day Forecast</span>
        </div>

        {/* 3. Soil pH */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Soil Reaction</span>
            <FlaskConical className="w-4 h-4 text-[#facc15]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#F3F7F1]">
              pH {currentField.currentSoil.ph?.toFixed(1) ?? 'N/A'}
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              {currentField.currentSoil.ph && currentField.currentSoil.ph > 7.5 ? 'Mildly Alkaline' : 'Near Neutral'}
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#9BB0A0] font-mono">Lab Observation</span>
        </div>

        {/* 4. Soil Organic Matter */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Organic Matter</span>
            <Sprout className="w-4 h-4 text-[#4fae76]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#F3F7F1]">
              {currentField.currentSoil.organicMatterPercent?.toFixed(1) ?? 'N/A'}%
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              Health Index: {soilScore.compositeScore}/100
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#4fae76] font-mono">{soilScore.confidenceRating} Confidence</span>
        </div>

        {/* 5. Water Balance */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Water Balance</span>
            <Droplet className="w-4 h-4 text-[#0ea5e9]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#F3F7F1]">
              {waterBalance.waterBalanceStatus}
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              ETc {formatDepth(waterBalance.cropEtMm, unitSystem)}
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#9BB0A0] font-mono">FAO-56 Dual Kc Model</span>
        </div>

        {/* 6. Operating Margin */}
        <div className="bg-[#111F19] p-3.5 rounded-xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#9BB0A0] mb-2">
            <span className="text-[11px] font-medium">Est. Margin / ha</span>
            <TrendingUp className="w-4 h-4 text-[#C5F36B]" />
          </div>
          <div>
            <div className="text-lg font-bold text-[#C5F36B]">
              {formatCurrency(rotationEvaluation.netOperatingMarginPerHa, currency)}
            </div>
            <div className="text-[10px] text-[#9BB0A0] mt-0.5">
              Rotation: {rotationEvaluation.overallScore}/100
            </div>
          </div>
          <span className="mt-2 text-[9px] text-[#9BB0A0] font-mono">Central Scenario</span>
        </div>
      </div>

      {/* Two Column Layout: Farm Intelligence Alerts & Seasonal Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Farm Intelligence & Agronomic Recommendations */}
        <div className="lg:col-span-2 bg-[#111F19] rounded-2xl border border-[#263A2D] p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#C5F36B]" />
              <h2 className="text-base font-bold text-[#F3F7F1]">{t.intelligenceFeedTitle}</h2>
            </div>
            <button
              onClick={() => setActiveTab('about')}
              className="text-xs text-[#C5F36B] hover:underline font-semibold flex items-center gap-1"
            >
              <span>About DAIS Platform</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {/* Alert 1: Salinity / Soil */}
            <div className="p-4 rounded-xl bg-[#17271E] border border-[#263A2D] hover:border-[#4FAE76]/60 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#facc15]/15 border border-[#facc15]/30 flex items-center justify-center shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4 text-[#facc15]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[#F3F7F1]">
                      Electrical Conductivity & Leaching Requirement
                    </h3>
                    <p className="text-xs text-[#9BB0A0] mt-1">
                      Soil EC is measured at <strong>{currentField.currentSoil.electricalConductivityDsM} dS/m</strong>.
                      To protect shallow-root vegetative emergence, maintain a 12-15% irrigation leaching fraction.
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#111F19] text-[#9BB0A0] border border-[#263A2D]">
                        Confidence: High (Lab sample)
                      </span>
                      <button
                        onClick={() => setActiveTab('soil')}
                        className="text-[11px] text-[#C5F36B] hover:underline font-semibold"
                      >
                        Inspect Soil Diagnostics &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Alert 2: Rotation & Nitrogen Fixation */}
            <div className="p-4 rounded-xl bg-[#17271E] border border-[#263A2D] hover:border-[#4FAE76]/60 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#4FAE76]/15 border border-[#4FAE76]/30 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4 text-[#4FAE76]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[#F3F7F1]">
                      Rotational Nitrogen Credit Opportunity
                    </h3>
                    <p className="text-xs text-[#9BB0A0] mt-1">
                      Active sequence includes legumes (chickpea / alfalfa) generating an estimated{' '}
                      <strong>65-140 kg N/ha</strong> biological fixation credit, reducing synthetic urea requirements by 30%.
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#111F19] text-[#9BB0A0] border border-[#263A2D]">
                        Model: Nitrogen Balance Engine
                      </span>
                      <button
                        onClick={() => setActiveTab('crops')}
                        className="text-[11px] text-[#C5F36B] hover:underline font-semibold"
                      >
                        Adjust Rotation Sequence &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Alert 3: Climate Hazard Monitoring */}
            <div className="p-4 rounded-xl bg-[#17271E] border border-[#263A2D] hover:border-[#4FAE76]/60 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#38bdf8]/15 border border-[#38bdf8]/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Droplet className="w-4 h-4 text-[#38bdf8]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[#F3F7F1]">
                      Irrigation Scheduling Optimization
                    </h3>
                    <p className="text-xs text-[#9BB0A0] mt-1">
                      Current crop evapotranspiration (ETc) is {waterBalance.cropEtMm} mm/day. Current soil moisture buffer is stable.
                      Next pivot cycle recommended in 4 days.
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <button
                        onClick={() => setActiveTab('water')}
                        className="text-[11px] text-[#C5F36B] hover:underline font-semibold"
                      >
                        View Water Balance Model &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Quick Field Navigation & Recent Activity */}
        <div className="space-y-6">
          {/* Active Field Details */}
          <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#F3F7F1]">Field Specification</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#17271E] text-[#C5F36B] font-mono">
                {currentField.boundary.coordinates.length} Vertices
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-[#263A2D]/60">
                <span className="text-[#9BB0A0]">Active Crop</span>
                <span className="text-[#F3F7F1] font-semibold">{activeCrop?.name || currentField.activeCropId}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#263A2D]/60">
                <span className="text-[#9BB0A0]">Scientific Name</span>
                <span className="text-[#9BB0A0] italic">{activeCrop?.scientificName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#263A2D]/60">
                <span className="text-[#9BB0A0]">Area (Computed)</span>
                <span className="text-[#F3F7F1] font-semibold">{formatArea(currentField.areaHa, unitSystem)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#263A2D]/60">
                <span className="text-[#9BB0A0]">Irrigation Method</span>
                <span className="text-[#F3F7F1] font-semibold">{currentField.irrigationSystem}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#263A2D]/60">
                <span className="text-[#9BB0A0]">Slope Gradient</span>
                <span className="text-[#F3F7F1] font-semibold">{currentField.slopePercent}%</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#9BB0A0]">Soil Type</span>
                <span className="text-[#F3F7F1] font-semibold">{currentField.soilType}</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-[#263A2D] flex items-center justify-between">
              <button
                onClick={() => setActiveTab('globe')}
                className="text-xs text-[#9BB0A0] hover:text-[#C5F36B] font-medium flex items-center gap-1.5 transition-colors"
              >
                <span>3D Planetary View</span>
              </button>
              <button
                onClick={() => setActiveTab('reports')}
                className="text-xs text-[#C5F36B] hover:underline font-semibold"
              >
                Generate Report &rarr;
              </button>
            </div>
          </div>

          {/* Activity Log */}
          <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] p-5">
            <h3 className="text-sm font-bold text-[#F3F7F1] mb-3">Recent Field History</h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2.5">
                <div className="w-2 h-2 rounded-full bg-[#C5F36B] mt-1.5 shrink-0" />
                <div>
                  <p className="text-[#F3F7F1] font-medium">Weather synchronization complete</p>
                  <p className="text-[10px] text-[#9BB0A0]">{weather.lastUpdated || 'Just now'} • Open-Meteo</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-2 h-2 rounded-full bg-[#4FAE76] mt-1.5 shrink-0" />
                <div>
                  <p className="text-[#F3F7F1] font-medium">Irrigation event logged</p>
                  <p className="text-[10px] text-[#9BB0A0]">40 mm applied across 42.5 ha</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-2 h-2 rounded-full bg-[#38bdf8] mt-1.5 shrink-0" />
                <div>
                  <p className="text-[#F3F7F1] font-medium">Laboratory soil sample verified</p>
                  <p className="text-[10px] text-[#9BB0A0]">pH 7.9, SOM 0.9%, EC 3.4 dS/m</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
