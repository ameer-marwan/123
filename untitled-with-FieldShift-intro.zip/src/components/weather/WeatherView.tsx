import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import { formatTemperature, formatDepth } from '../../lib/i18n';
import {
  Cloud,
  CloudRain,
  Sun,
  Wind,
  Droplet,
  Compass,
  Gauge,
  Thermometer,
  Calendar,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
} from 'lucide-react';

export const WeatherView: React.FC = () => {
  const { currentFarm, weather, refreshWeather, unitSystem } = useFarm();
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);

  const current = weather.current;
  const days = weather.daily || [];
  const activeDay = days[selectedDayIndex] || days[0];

  // Helper to interpret WMO weather codes
  const getWeatherDesc = (code: number) => {
    if (code === 0) return { label: 'Clear Sky', icon: Sun, color: 'text-yellow-400' };
    if (code >= 1 && code <= 3) return { label: 'Partly Cloudy', icon: Cloud, color: 'text-[#9BB0A0]' };
    if (code >= 51 && code <= 67) return { label: 'Rain / Drizzle', icon: CloudRain, color: 'text-sky-400' };
    if (code >= 71 && code <= 77) return { label: 'Snow / Frost Risk', icon: AlertTriangle, color: 'text-cyan-300' };
    if (code >= 80 && code <= 82) return { label: 'Rain Showers', icon: CloudRain, color: 'text-blue-400' };
    if (code >= 95) return { label: 'Thunderstorm', icon: AlertTriangle, color: 'text-amber-400' };
    return { label: 'Fair Conditions', icon: Sun, color: 'text-yellow-400' };
  };

  const weatherMeta = current ? getWeatherDesc(current.weatherCode) : getWeatherDesc(0);
  const CurrentIcon = weatherMeta.icon;

  return (
    <div className="space-y-6">
      {/* Weather Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              {weather.source}
            </span>
            {weather.isStale && (
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/15 text-amber-400 border border-amber-500/30">
                Stale (Cached)
              </span>
            )}
            <span className="text-xs text-[#9BB0A0]">
              Synchronized at {weather.lastUpdated || 'Initial load'}
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Agrometeorological Intelligence — {currentFarm.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Coordinates: {currentFarm.centerCoordinates[0].toFixed(4)}°N,{' '}
            {currentFarm.centerCoordinates[1].toFixed(4)}°E • Elevation: {currentFarm.elevationMeters}m
          </p>
        </div>

        <button
          onClick={() => refreshWeather()}
          disabled={weather.isLoading}
          className="px-4 py-2 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] rounded-xl border border-[#263A2D] text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${weather.isLoading ? 'animate-spin' : ''}`} />
          <span>{weather.isLoading ? 'Querying Satellite...' : 'Refresh Forecast'}</span>
        </button>
      </div>

      {/* Current Conditions Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#111F19] p-6 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#9BB0A0]">
                Current In-Field Conditions
              </span>
              <CurrentIcon className={`w-8 h-8 ${weatherMeta.color}`} />
            </div>

            <div className="flex items-baseline gap-3">
              <div className="text-4xl font-extrabold text-[#F3F7F1]">
                {current ? formatTemperature(current.temperatureC, unitSystem) : '28°C'}
              </div>
              <div className="text-sm font-medium text-[#C5F36B]">{weatherMeta.label}</div>
            </div>

            <p className="text-xs text-[#9BB0A0] mt-2">
              Relative Humidity: <span className="text-[#F3F7F1]">{current?.relativeHumidity ?? 35}%</span> •
              Cloud Cover: <span className="text-[#F3F7F1]">{current?.cloudCoverPercent ?? 10}%</span>
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 mt-6 pt-4 border-t border-[#263A2D]">
            <div className="flex items-center gap-2 text-xs">
              <Wind className="w-4 h-4 text-[#C5F36B]" />
              <div>
                <span className="text-[#9BB0A0] block text-[10px]">Wind Velocity</span>
                <span className="text-[#F3F7F1] font-semibold">
                  {current?.windSpeedKmh ?? 14} km/h
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Compass className="w-4 h-4 text-[#38bdf8]" />
              <div>
                <span className="text-[#9BB0A0] block text-[10px]">Wind Direction</span>
                <span className="text-[#F3F7F1] font-semibold">{current?.windDirectionDeg ?? 110}°</span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Gauge className="w-4 h-4 text-[#facc15]" />
              <div>
                <span className="text-[#9BB0A0] block text-[10px]">Surface Pressure</span>
                <span className="text-[#F3F7F1] font-semibold">{current?.surfacePressureHpa ?? 1014} hPa</span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Droplet className="w-4 h-4 text-[#4FAE76]" />
              <div>
                <span className="text-[#9BB0A0] block text-[10px]">Precipitation Rate</span>
                <span className="text-[#F3F7F1] font-semibold">{current?.precipitationMm ?? 0} mm/h</span>
              </div>
            </div>
          </div>
        </div>

        {/* 7-Day Agronomic Forecast Visual Cards */}
        <div className="lg:col-span-2 bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-[#F3F7F1]">7-Day Agrometeorological Forecast</h3>
            <span className="text-[11px] text-[#9BB0A0]">Click a day to inspect agro-metrics</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {days.slice(0, 7).map((d, idx) => {
              const meta = getWeatherDesc(d.weatherCode);
              const DayIcon = meta.icon;
              const isSelected = idx === selectedDayIndex;
              const dateObj = new Date(d.date);
              const dayLabel = idx === 0 ? 'Today' : dateObj.toLocaleDateString('en-US', { weekday: 'short' });

              return (
                <button
                  key={d.date}
                  onClick={() => setSelectedDayIndex(idx)}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-between transition-all text-center ${
                    isSelected
                      ? 'bg-[#C5F36B]/15 border-[#C5F36B] shadow-md'
                      : 'bg-[#17271E] border-[#263A2D] hover:border-[#4FAE76]/60'
                  }`}
                >
                  <span className={`text-[11px] font-bold ${isSelected ? 'text-[#C5F36B]' : 'text-[#9BB0A0]'}`}>
                    {dayLabel}
                  </span>
                  <DayIcon className={`w-5 h-5 my-2 ${meta.color}`} />
                  <div className="text-xs font-bold text-[#F3F7F1]">
                    {formatTemperature(d.tempMaxC, unitSystem)}
                  </div>
                  <div className="text-[10px] text-[#9BB0A0]">
                    {formatTemperature(d.tempMinC, unitSystem)}
                  </div>
                  <div className="mt-2 text-[10px] text-sky-400 font-medium">
                    {d.precipSumMm > 0 ? `${d.precipSumMm}mm` : `${d.precipProbMax}%`}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Day Expanded Agronomic Insight */}
          {activeDay && (
            <div className="mt-4 pt-3 border-t border-[#263A2D] flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <span className="text-[#9BB0A0]">Selected Date:</span>
                <span className="text-[#F3F7F1] font-semibold">{activeDay.date}</span>
              </div>
              <div className="flex items-center gap-4">
                <div>
                  <span className="text-[#9BB0A0]">Reference ET (ET0): </span>
                  <span className="text-[#C5F36B] font-bold">{activeDay.et0Mm.toFixed(1)} mm/day</span>
                </div>
                <div>
                  <span className="text-[#9BB0A0]">Max Wind Gusts: </span>
                  <span className="text-[#F3F7F1] font-medium">{activeDay.windSpeedMaxKmh} km/h</span>
                </div>
                <div>
                  <span className="text-[#9BB0A0]">Rain Prob: </span>
                  <span className="text-sky-400 font-medium">{activeDay.precipProbMax}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SVG Temperature & Evapotranspiration Trend Visualizer */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-[#F3F7F1]">
              7-Day Temperature Range & Reference Evapotranspiration (ET0)
            </h3>
            <p className="text-xs text-[#9BB0A0]">
              ET0 indicates atmospheric water demand under FAO-56 Penman-Monteith standardized model.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-[#C5F36B]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#C5F36B]" /> Max Temp (°C)
            </span>
            <span className="flex items-center gap-1.5 text-sky-400">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400" /> Min Temp (°C)
            </span>
            <span className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> ET0 (mm)
            </span>
          </div>
        </div>

        {/* Clean Responsive SVG Chart */}
        <div className="w-full h-48 overflow-x-auto">
          <svg className="w-full h-full min-w-[500px]" viewBox="0 0 600 180">
            {/* Grid lines */}
            <line x1="40" y1="20" x2="580" y2="20" stroke="#1f3327" strokeDasharray="3,3" />
            <line x1="40" y1="65" x2="580" y2="65" stroke="#1f3327" strokeDasharray="3,3" />
            <line x1="40" y1="110" x2="580" y2="110" stroke="#1f3327" strokeDasharray="3,3" />
            <line x1="40" y1="155" x2="580" y2="155" stroke="#263A2D" />

            {/* Render 7 day points */}
            {days.slice(0, 7).map((d, i) => {
              const x = 70 + i * 80;
              // Map temp (10°C to 45°C) to y (150 to 30)
              const yMax = 155 - ((d.tempMaxC - 10) / 35) * 125;
              const yMin = 155 - ((d.tempMinC - 10) / 35) * 125;
              const yEt = 155 - (d.et0Mm / 10) * 80;

              return (
                <g key={d.date}>
                  {/* Vertical day band */}
                  <line x1={x} y1="20" x2={x} y2="155" stroke="#17271E" strokeWidth="1" />
                  {/* ET0 Bar */}
                  <rect x={x - 12} y={yEt} width="10" height={155 - yEt} fill="#facc15" opacity="0.6" rx="2" />
                  {/* Temp Max Point */}
                  <circle cx={x} cy={yMax} r="4" fill="#C5F36B" />
                  <text x={x} y={yMax - 6} fill="#C5F36B" fontSize="10" textAnchor="middle" fontWeight="bold">
                    {Math.round(d.tempMaxC)}°
                  </text>
                  {/* Temp Min Point */}
                  <circle cx={x} cy={yMin} r="4" fill="#38bdf8" />
                  <text x={x} y={yMin + 14} fill="#38bdf8" fontSize="10" textAnchor="middle">
                    {Math.round(d.tempMinC)}°
                  </text>
                  {/* Day Label */}
                  <text x={x} y="172" fill="#9BB0A0" fontSize="10" textAnchor="middle">
                    {d.date.slice(5)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
