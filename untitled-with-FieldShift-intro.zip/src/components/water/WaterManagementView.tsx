import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import { formatDepth } from '../../lib/i18n';
import { mmHectareToCubicMeters } from '../../domain/calculations';
import {
  Droplets,
  Plus,
  Calendar,
  Layers,
  ArrowRight,
  TrendingDown,
  Info,
  CheckCircle,
} from 'lucide-react';

export const WaterManagementView: React.FC = () => {
  const { currentField, unitSystem, addIrrigationEvent, showNotification } = useFarm();
  const [showLogModal, setShowLogModal] = useState(false);

  // Form inputs
  const [formDepthMm, setFormDepthMm] = useState<string>('35');
  const [formMethod, setFormMethod] = useState<'Precision Drip' | 'Center Pivot' | 'Micro-Sprinkler' | 'Furrow / Surface'>(
    'Center Pivot'
  );
  const [formHours, setFormHours] = useState<string>('14');
  const [formSource, setFormSource] = useState<'Deep Aquifer' | 'Canal Irrigation' | 'Treated Recycled' | 'Rainwater Catchment'>(
    'Deep Aquifer'
  );
  const [formNotes, setFormNotes] = useState<string>('');

  const depthNum = parseFloat(formDepthMm) || 0;
  // Rule: 1 mm depth across 1 hectare = 10 m3
  const calculatedVolumeM3 = Math.round(depthNum * currentField.areaHa * 10);

  const handleSubmitIrrigation = (e: React.FormEvent) => {
    e.preventDefault();
    if (depthNum <= 0) {
      showNotification('Please enter a valid irrigation depth.', 'warning');
      return;
    }

    addIrrigationEvent(currentField.id, {
      fieldId: currentField.id,
      date: new Date().toISOString().split('T')[0],
      volumeM3: calculatedVolumeM3,
      depthMm: depthNum,
      method: formMethod,
      durationHours: parseFloat(formHours) || 12,
      waterSource: formSource,
      notes: formNotes || 'Routine irrigation pass logged.',
    });

    setShowLogModal(false);
  };

  const totalSeasonWaterM3 = currentField.irrigationEvents.reduce((acc, e) => acc + e.volumeM3, 0);
  const totalSeasonDepthMm = currentField.irrigationEvents.reduce((acc, e) => acc + e.depthMm, 0);

  return (
    <div className="space-y-6">
      {/* Hero Header with Real Lake Wallpaper */}
      <div className="relative rounded-3xl overflow-hidden border border-[#263A2D] shadow-2xl min-h-[220px] flex flex-col justify-end p-6 md:p-8">
        <img
          src="/images/lake_water.jpg"
          alt="Freshwater Reservoir & Lake"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/75 to-[#08130F]/30" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-[11px] font-extrabold bg-[#C5F36B] text-[#08130F] uppercase tracking-wider">
                Aquifer & Reservoir Stewardship
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#111F19]/90 text-[#38bdf8] border border-[#263A2D] backdrop-blur-md">
                System: {currentField.irrigationSystem}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-[#F3F7F1]">
              Hydrological Accounting & Scheduling — {currentField.name} ({currentField.areaHa} ha)
            </h2>
            <p className="text-xs text-[#d1e0d5] mt-1 max-w-xl">
              Track volumetric water extractions, irrigation efficiency benchmarks, and crop deficit scheduling using direct reservoir and aquifer measurements.
            </p>
          </div>

          <button
            onClick={() => setShowLogModal(true)}
            className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-lg shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Log Irrigation Pass</span>
          </button>
        </div>
      </div>

      {/* Water Accounting Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <span className="text-[11px] text-[#9BB0A0] block">Cumulative Irrigation Depth</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">
            {totalSeasonDepthMm} mm
          </span>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">Across current growing cycle</span>
        </div>

        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <span className="text-[11px] text-[#9BB0A0] block">Cumulative Volume Delivered</span>
          <span className="text-2xl font-bold text-[#C5F36B] mt-1 block">
            {totalSeasonWaterM3.toLocaleString()} m³
          </span>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Exact field area basis: {currentField.areaHa} ha
          </span>
        </div>

        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <span className="text-[11px] text-[#9BB0A0] block">Delivery System Efficiency</span>
          <span className="text-2xl font-bold text-[#4FAE76] mt-1 block">
            {currentField.irrigationSystem === 'Drip' ? '92%' : currentField.irrigationSystem === 'Pivot' ? '82%' : '70%'}
          </span>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Application loss: ~{currentField.irrigationSystem === 'Drip' ? '8%' : '18%'} (evap / wind drift)
          </span>
        </div>

        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <span className="text-[11px] text-[#9BB0A0] block">Next Recommended Run</span>
          <span className="text-2xl font-bold text-[#F3F7F1] mt-1 block">
            In 4 Days
          </span>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">Target depth: 30 mm (12,750 m³)</span>
        </div>
      </div>

      {/* Volumetric Conversion Reference Card */}
      <div className="p-4 rounded-xl bg-[#111F19] border border-[#263A2D] text-xs flex items-start gap-3">
        <Info className="w-5 h-5 text-[#C5F36B] shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-[#F3F7F1]">Agronomic Volumetric Principle:</h4>
          <p className="text-[#9BB0A0] mt-0.5">
            A water application depth of <strong>1 mm across 1 hectare</strong> precisely corresponds to <strong>10 cubic meters (10 m³)</strong> of water. For this parcel ({currentField.areaHa} ha), applying 1 mm equates to exactly <strong>{(currentField.areaHa * 10).toFixed(1)} m³</strong>.
          </p>
        </div>
      </div>

      {/* Irrigation History Log */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] overflow-hidden">
        <div className="p-4 border-b border-[#263A2D] flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#C5F36B]" />
            <span>Field Irrigation Pass Log</span>
          </h3>
          <span className="text-xs text-[#9BB0A0]">
            {currentField.irrigationEvents.length} Events Logged
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#17271E] text-[#9BB0A0] border-b border-[#263A2D]">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Date</th>
                <th className="py-2.5 px-4 font-semibold">Application Depth</th>
                <th className="py-2.5 px-4 font-semibold">Total Volume (m³)</th>
                <th className="py-2.5 px-4 font-semibold">System / Method</th>
                <th className="py-2.5 px-4 font-semibold">Run Duration</th>
                <th className="py-2.5 px-4 font-semibold">Water Source</th>
                <th className="py-2.5 px-4 font-semibold">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#263A2D]">
              {currentField.irrigationEvents.map((evt) => (
                <tr key={evt.id} className="hover:bg-[#17271E]/50 transition-colors">
                  <td className="py-2.5 px-4 font-medium text-[#F3F7F1]">{evt.date}</td>
                  <td className="py-2.5 px-4 font-bold text-sky-400">{evt.depthMm} mm</td>
                  <td className="py-2.5 px-4 font-bold text-[#C5F36B]">{evt.volumeM3.toLocaleString()} m³</td>
                  <td className="py-2.5 px-4 text-[#F3F7F1]">{evt.method}</td>
                  <td className="py-2.5 px-4 text-[#9BB0A0]">{evt.durationHours} hrs</td>
                  <td className="py-2.5 px-4 text-[#9BB0A0]">{evt.waterSource}</td>
                  <td className="py-2.5 px-4 text-[#9BB0A0] max-w-xs truncate">{evt.notes || '-'}</td>
                </tr>
              ))}
              {currentField.irrigationEvents.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-[#9BB0A0]">
                    No irrigation passes logged yet for this field.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Irrigation Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-[1000] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111F19] border border-[#263A2D] rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#263A2D] pb-3">
              <h3 className="text-base font-bold text-[#F3F7F1] flex items-center gap-2">
                <Droplets className="w-5 h-5 text-[#C5F36B]" />
                <span>Log Field Irrigation Event</span>
              </h3>
              <button
                onClick={() => setShowLogModal(false)}
                className="text-[#9BB0A0] hover:text-[#F3F7F1] text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitIrrigation} className="space-y-4 text-xs">
              <div>
                <label className="block text-[#9BB0A0] mb-1">
                  Water Application Depth (mm)
                </label>
                <input
                  type="number"
                  step="1"
                  min="1"
                  max="150"
                  value={formDepthMm}
                  onChange={(e) => setFormDepthMm(e.target.value)}
                  className="w-full bg-[#17271E] text-[#F3F7F1] font-bold border border-[#263A2D] rounded-lg p-2.5 focus:outline-none focus:border-[#C5F36B]"
                />
                <div className="mt-1 text-[11px] text-[#C5F36B] font-semibold">
                  Equivalent Volume: {calculatedVolumeM3.toLocaleString()} m³ across {currentField.areaHa} ha
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Method</label>
                  <select
                    value={formMethod}
                    onChange={(e: any) => setFormMethod(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  >
                    <option value="Center Pivot">Center Pivot</option>
                    <option value="Precision Drip">Precision Drip</option>
                    <option value="Micro-Sprinkler">Micro-Sprinkler</option>
                    <option value="Furrow / Surface">Furrow / Surface</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#9BB0A0] mb-1">Duration (Hours)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formHours}
                    onChange={(e) => setFormHours(e.target.value)}
                    className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#9BB0A0] mb-1">Water Source</label>
                <select
                  value={formSource}
                  onChange={(e: any) => setFormSource(e.target.value)}
                  className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                >
                  <option value="Deep Aquifer">Deep Aquifer (Brackish / Treated)</option>
                  <option value="Canal Irrigation">Regional Irrigation Canal</option>
                  <option value="Treated Recycled">Treated Recycled Water</option>
                  <option value="Rainwater Catchment">Rainwater Catchment Reservoir</option>
                </select>
              </div>

              <div>
                <label className="block text-[#9BB0A0] mb-1">Field Notes</label>
                <textarea
                  rows={2}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Night cycle executed during low wind to minimize droplet drift."
                  className="w-full bg-[#17271E] text-[#F3F7F1] border border-[#263A2D] rounded-lg p-2 focus:outline-none focus:border-[#C5F36B]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#263A2D]">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 bg-[#17271E] text-[#9BB0A0] hover:text-[#F3F7F1] rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C5F36B] text-[#08130F] font-bold rounded-lg shadow-md hover:bg-[#b2e552]"
                >
                  Confirm & Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
