import React, { useState, useRef, useEffect } from 'react';
import { useFarm } from '../../context/FarmContext';
import {
  Bot,
  Send,
  Search,
  MapPin,
  Sparkles,
  ExternalLink,
  Globe,
  Loader2,
  RefreshCw,
  User,
  ShieldCheck,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  sources?: Array<{ title: string; uri: string; type?: 'web' | 'map' }>;
}

export const AssistantView: React.FC = () => {
  const { currentFarm, currentField, weather } = useFarm();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Hello! I am your **FieldShift Agricultural Intelligence Consultant** — specialized in agronomy, soil chemistry, precision irrigation, and geospatial climate risk.

Currently observing **${currentFarm.name}** (${currentField.name}):
- **Active Crop:** ${currentField.activeCropId.toUpperCase()}
- **Soil Status:** pH ${currentField.currentSoil.ph?.toFixed(1) || '7.4'}, SOM ${currentField.currentSoil.organicMatterPercent || '1.8'}%, Salinity ${currentField.currentSoil.electricalConductivityDsM || '1.2'} dS/m
- **Current Temperature:** ${weather.current?.temperatureC || 28}°C

How can I assist your farming operations today? You can ask about crop rotations, disease breaks, fertilizer calculations, or trigger live **Google Search Grounding** or **Google Maps Grounding**.`,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'chat' | 'search' | 'maps'>('chat');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userText = inputMessage.trim();
    setInputMessage('');

    const userMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      if (mode === 'search') {
        // Feature: Google Search Grounding with gemini-3.8-flash
        const res = await fetch('/api/gemini/search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: userText,
            region: currentFarm.region || currentFarm.country,
          }),
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || 'Search grounding failed');

        const assistantMsg: ChatMessage = {
          id: `bot_${Date.now()}`,
          role: 'assistant',
          content: data.answer || 'No search result returned.',
          timestamp: new Date().toLocaleTimeString(),
          sources: (data.sources || []).map((s: any) => ({ ...s, type: 'web' })),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else if (mode === 'maps') {
        // Feature: Google Maps Grounding with gemini-3.8-flash & field coordinates
        const res = await fetch('/api/gemini/maps', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: userText,
            latitude: currentFarm.centerCoordinates[0],
            longitude: currentFarm.centerCoordinates[1],
          }),
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || 'Maps grounding failed');

        const assistantMsg: ChatMessage = {
          id: `bot_${Date.now()}`,
          role: 'assistant',
          content: data.answer || 'No map results returned.',
          timestamp: new Date().toLocaleTimeString(),
          sources: (data.sources || []).map((s: any) => ({ ...s, type: 'map' })),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        // Feature: Multi-turn chat interface maintaining conversation history
        const apiMessages = [...messages, userMsg].map((m) => ({
          role: m.role,
          content: m.content,
        }));

        const res = await fetch('/api/gemini/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: apiMessages,
            farmContext: {
              farmName: currentFarm.name,
              location: `${currentFarm.region}, ${currentFarm.country}`,
              fieldName: currentField.name,
              areaHa: currentField.areaHa,
              crops: currentField.activeCropId,
              ph: currentField.currentSoil.ph,
              som: currentField.currentSoil.organicMatterPercent,
              ec: currentField.currentSoil.electricalConductivityDsM,
            },
          }),
        });
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || 'Chat request failed');

        const assistantMsg: ChatMessage = {
          id: `bot_${Date.now()}`,
          role: 'assistant',
          content: data.reply || 'No response returned.',
          timestamp: new Date().toLocaleTimeString(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      }
    } catch (err: any) {
      console.error('AI error:', err);
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        content: `I encountered an issue connecting to the AI services (${err.message}). Please verify your network connection or API credentials.`,
        timestamp: new Date().toLocaleTimeString(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderFormattedMessage = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      const isBullet = line.trim().startsWith('- ') || line.trim().startsWith('* ');
      const cleanLine = isBullet ? line.trim().slice(2) : line;

      const parts = cleanLine.split(/(\*\*.*?\*\*)/g);
      const parsedLine = parts.map((part, pIdx) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return (
            <strong key={pIdx} className="font-bold text-[#C5F36B]">
              {part.slice(2, -2)}
            </strong>
          );
        }
        return part;
      });

      if (isBullet) {
        return (
          <div key={idx} className="flex items-start gap-2 ml-2 my-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5F36B] mt-1.5 shrink-0" />
            <span className="text-[#F3F7F1]">{parsedLine}</span>
          </div>
        );
      }

      if (!line.trim()) {
        return <div key={idx} className="h-1.5" />;
      }

      return (
        <p key={idx} className="leading-relaxed">
          {parsedLine}
        </p>
      );
    });
  };

  return (
    <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] flex flex-col h-[720px] shadow-2xl overflow-hidden">
      {/* Assistant Header & Grounding Switcher */}
      <div className="p-4 border-b border-[#263A2D] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#0d1813]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#C5F36B]/15 border border-[#C5F36B]/30 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-[#C5F36B]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#F3F7F1]">
              FieldShift Agronomy & Geospatial AI Consultant
            </h2>
            <p className="text-[11px] text-[#9BB0A0]">
              Powered by <span className="text-[#C5F36B] font-mono">gemini-3.8-flash</span> with real-time Search & Maps Grounding
            </p>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center gap-1 bg-[#17271E] p-1 rounded-xl border border-[#263A2D]">
          <button
            onClick={() => setMode('chat')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              mode === 'chat'
                ? 'bg-[#C5F36B] text-[#08130F]'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Chat</span>
          </button>

          <button
            onClick={() => setMode('search')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              mode === 'search'
                ? 'bg-[#C5F36B] text-[#08130F]'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search Grounding</span>
          </button>

          <button
            onClick={() => setMode('maps')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              mode === 'maps'
                ? 'bg-[#C5F36B] text-[#08130F]'
                : 'text-[#9BB0A0] hover:text-[#F3F7F1]'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Maps Grounding</span>
          </button>
        </div>
      </div>

      {/* Mode Description Banner */}
      <div className="px-4 py-2 bg-[#17271E]/60 border-b border-[#263A2D] text-[11px] text-[#9BB0A0] flex items-center gap-2">
        {mode === 'chat' && (
          <span>
            💬 <strong>Multi-turn Agronomy Chat:</strong> Ask questions about soil salinity, crop coefficient Kc, nitrogen budgeting, or crop rotations.
          </span>
        )}
        {mode === 'search' && (
          <span>
            🌐 <strong>Google Search Grounding:</strong> Queries the live web for recent grain commodity market prices, regional pest alerts, and extension bulletins.
          </span>
        )}
        {mode === 'maps' && (
          <span>
            📍 <strong>Google Maps Grounding:</strong> Finds nearby agricultural supply depots, certified soil labs, and irrigation dealers near your field coordinates.
          </span>
        )}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser
                    ? 'bg-[#C5F36B] text-[#08130F]'
                    : 'bg-[#17271E] border border-[#263A2D] text-[#C5F36B]'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-2 ${
                  isUser
                    ? 'bg-[#C5F36B]/15 border border-[#C5F36B]/30 text-[#F3F7F1]'
                    : 'bg-[#17271E] border border-[#263A2D] text-[#F3F7F1]'
                }`}
              >
                {/* Message Body */}
                <div className="font-sans space-y-1">{renderFormattedMessage(msg.content)}</div>

                {/* Grounding Sources (Google Search / Google Maps URLs) */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="pt-2 mt-2 border-t border-[#263A2D]/80">
                    <span className="text-[10px] uppercase font-bold text-[#C5F36B] tracking-wider block mb-1.5 flex items-center gap-1">
                      {msg.sources[0]?.type === 'map' ? (
                        <>
                          <MapPin className="w-3 h-3 text-[#C5F36B]" />
                          <span>Grounded Google Maps Locations:</span>
                        </>
                      ) : (
                        <>
                          <Globe className="w-3 h-3 text-[#C5F36B]" />
                          <span>Grounded Web Citations:</span>
                        </>
                      )}
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.map((src, i) => (
                        <a
                          key={i}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-1 bg-[#111F19] hover:bg-[#263A2D] border border-[#263A2D] rounded-md text-[10px] text-[#9BB0A0] hover:text-[#C5F36B] flex items-center gap-1 transition-colors"
                        >
                          <span className="truncate max-w-[200px]">{src.title}</span>
                          <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                <div className="text-[9px] text-[#9BB0A0] text-right">{msg.timestamp}</div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-3 text-xs text-[#9BB0A0]">
            <div className="w-7 h-7 rounded-lg bg-[#17271E] border border-[#263A2D] flex items-center justify-center text-[#C5F36B]">
              <Loader2 className="w-4 h-4 animate-spin" />
            </div>
            <div className="p-3 rounded-2xl bg-[#17271E] border border-[#263A2D]">
              Analyzing agricultural parameters and telemetry...
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSendMessage} className="p-3 border-t border-[#263A2D] bg-[#0d1813] flex items-center gap-2">
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder={
            mode === 'search'
              ? 'Search live web for agricultural commodity prices or pest outbreaks...'
              : mode === 'maps'
              ? 'Find agricultural suppliers, soil labs, or tractor parts nearby...'
              : 'Ask about crop rotation suitability, nitrogen credits, irrigation timing...'
          }
          className="flex-1 bg-[#17271E] text-xs text-[#F3F7F1] placeholder-[#9BB0A0] px-4 py-2.5 rounded-xl border border-[#263A2D] focus:outline-none focus:border-[#C5F36B] transition-colors"
        />

        <button
          type="submit"
          disabled={!inputMessage.trim() || isLoading}
          className="p-2.5 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold rounded-xl transition-transform active:scale-95 disabled:opacity-40"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
