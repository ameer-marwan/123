import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import { getCropById } from '../../domain/cropCatalog';
import {
  ShieldAlert,
  Flame,
  Snowflake,
  SunMedium,
  CloudRain,
  AlertOctagon,
  CheckCircle,
  FileText,
  Check,
} from 'lucide-react';

export const ClimateRiskView: React.FC = () => {
  const { currentFarm, currentField, weather, markAlertReviewed } = useFarm();
  const crop = getCropById(currentField.activeCropId);

  const [reviewNote, setReviewNote] = useState<{ [alertId: string]: string }>({});

  const handleReview = (alertId: string) => {
    markAlertReviewed(currentField.id, alertId, reviewNote[alertId]);
  };

  const getHazardIcon = (type: string) => {
    if (type.includes('Heat')) return Flame;
    if (type.includes('Frost')) return Snowflake;
    if (type.includes('Drought')) return SunMedium;
    if (type.includes('Precipitation')) return CloudRain;
    return AlertOctagon;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              Climate Vulnerability & Hazard Tracking
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#17271E] text-[#9BB0A0] border border-[#263A2D]">
              Monitored Crop: {crop?.name || currentField.activeCropId}
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Agro-Climatic Hazards & Extreme Weather Shield — {currentField.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Proactive threshold monitoring for thermal stress, frost, soil salinity spikes, and prolonged dry spells.
          </p>
        </div>
      </div>

      {/* Hazard Status Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Heat Risk */}
        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9BB0A0]">Extreme Heat Risk</span>
            <Flame className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl font-bold text-[#F3F7F1]">
            {(weather.daily[0]?.tempMaxC || 28) > 38 ? 'High Risk' : 'Low to Moderate'}
          </div>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Max forecast: {weather.daily[0]?.tempMaxC || 28}°C (Threshold: 38°C)
          </span>
        </div>

        {/* Frost Risk */}
        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9BB0A0]">Frost & Chilling Stress</span>
            <Snowflake className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-[#4FAE76]">
            No Frost Detected
          </div>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Min forecast: {weather.daily[0]?.tempMinC || 15}°C (Critical: &lt;2°C)
          </span>
        </div>

        {/* Drought / Dry Spell */}
        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9BB0A0]">Dry Spell Duration</span>
            <SunMedium className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="text-xl font-bold text-[#F3F7F1]">
            12 Days Rainless
          </div>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Mitigated by {currentField.irrigationSystem} irrigation system
          </span>
        </div>

        {/* Salinity Stress */}
        <div className="bg-[#111F19] p-4 rounded-xl border border-[#263A2D]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#9BB0A0]">Osmotic Salinity</span>
            <AlertOctagon className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl font-bold text-amber-400">
            {currentField.currentSoil.electricalConductivityDsM || 1.0} dS/m
          </div>
          <span className="text-[10px] text-[#9BB0A0] block mt-1">
            Crop threshold: {crop?.salinityToleranceDsM || 4.0} dS/m
          </span>
        </div>
      </div>

      {/* Active Alerts Workflow List */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
        <h3 className="text-sm font-bold text-[#F3F7F1] mb-4 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#C5F36B]" />
          <span>Active Hazard Alerts & Mitigation Workflow</span>
        </h3>

        <div className="space-y-4">
          {currentField.alerts.map((alert) => {
            const IconComponent = getHazardIcon(alert.hazardType);
            return (
              <div
                key={alert.id}
                className={`p-4 rounded-xl border transition-all ${
                  alert.isReviewed
                    ? 'bg-[#17271E]/50 border-[#263A2D] opacity-75'
                    : 'bg-[#17271E] border-amber-500/50 shadow-md'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                        alert.severity === 'Critical'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                      }`}
                    >
                      <IconComponent className="w-5 h-5" />
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-sm font-bold text-[#F3F7F1]">{alert.title}</h4>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                            alert.severity === 'Critical'
                              ? 'bg-red-500/20 text-red-400'
                              : 'bg-amber-500/20 text-amber-400'
                          }`}
                        >
                          {alert.severity}
                        </span>
                        {alert.isReviewed && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#4FAE76]/20 text-[#4FAE76] flex items-center gap-1 font-semibold">
                            <Check className="w-3 h-3" /> Reviewed
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-[#9BB0A0] mt-1.5">{alert.description}</p>
                      <p className="text-xs text-[#C5F36B] font-medium mt-1">
                        Recommended Action: {alert.mitigationAction || 'Consult agronomist.'}
                      </p>
                    </div>
                  </div>

                  {!alert.isReviewed && (
                    <div className="flex flex-col sm:items-end gap-2 shrink-0">
                      <input
                        type="text"
                        placeholder="Add mitigation note..."
                        value={reviewNote[alert.id] || ''}
                        onChange={(e) =>
                          setReviewNote({ ...reviewNote, [alert.id]: e.target.value })
                        }
                        className="bg-[#111F19] text-xs text-[#F3F7F1] px-2.5 py-1 rounded-lg border border-[#263A2D] focus:outline-none focus:border-[#C5F36B] w-full sm:w-48"
                      />
                      <button
                        onClick={() => handleReview(alert.id)}
                        className="px-3 py-1.5 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-transform active:scale-95"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Acknowledge</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {currentField.alerts.length === 0 && (
            <div className="p-6 rounded-xl bg-[#17271E] border border-[#263A2D] text-center text-xs text-[#9BB0A0]">
              <CheckCircle className="w-8 h-8 text-[#4FAE76] mx-auto mb-2" />
              <span>No active climate alerts for {currentField.name}. Conditions are within safe agronomic parameters.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
