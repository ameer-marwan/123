import React from 'react';
import { useFarm } from '../../context/FarmContext';
import { formatCurrency, formatArea } from '../../lib/i18n';
import { getCropById } from '../../domain/cropCatalog';
import {
  BarChart3,
  Download,
  TrendingUp,
  Layers,
  Sprout,
  Droplet,
  FileSpreadsheet,
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { currentFarm, currentField, currency, unitSystem, showNotification } = useFarm();

  // Export CSV Handler
  const handleExportCsv = () => {
    const headers = ['Field Name', 'Area (ha)', 'Crop', 'Soil Type', 'Irrigation System', 'Soil pH', 'SOM %', 'EC (dS/m)'];
    const rows = currentFarm.fields.map((f) => [
      `"${f.name}"`,
      f.areaHa,
      `"${f.activeCropId}"`,
      `"${f.soilType}"`,
      `"${f.irrigationSystem}"`,
      f.currentSoil.ph ?? '',
      f.currentSoil.organicMatterPercent ?? '',
      f.currentSoil.electricalConductivityDsM ?? '',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${currentFarm.name.replace(/\s+/g, '_')}_AgroData.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showNotification('Field agricultural telemetry exported as CSV.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              Advanced Agronomic Analytics
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#17271E] text-[#9BB0A0] border border-[#263A2D]">
              {currentFarm.fields.length} Monitored Parcels
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Cross-Field Comparative Analytics — {currentFarm.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Analyze multi-field water intensity, soil health distribution, and rotational gross margins.
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          className="px-4 py-2 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] text-xs font-semibold rounded-xl border border-[#263A2D] flex items-center justify-center gap-2 transition-colors shadow-md"
        >
          <Download className="w-4 h-4" />
          <span>Export All Fields (CSV)</span>
        </button>
      </div>

      {/* Field Comparisons Table */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] overflow-hidden">
        <div className="p-4 border-b border-[#263A2D] flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-[#C5F36B]" />
            <span>Farm Field Matrix & Diagnostic Status</span>
          </h3>
          <span className="text-xs text-[#9BB0A0]">Updated in real-time</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#17271E] text-[#9BB0A0] border-b border-[#263A2D]">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Field Name</th>
                <th className="py-2.5 px-4 font-semibold">Area</th>
                <th className="py-2.5 px-4 font-semibold">Active Crop</th>
                <th className="py-2.5 px-4 font-semibold">Irrigation</th>
                <th className="py-2.5 px-4 font-semibold">Soil pH</th>
                <th className="py-2.5 px-4 font-semibold">SOM %</th>
                <th className="py-2.5 px-4 font-semibold">Salinity EC</th>
                <th className="py-2.5 px-4 font-semibold">Total Irrigation Logged</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#263A2D]">
              {currentFarm.fields.map((fld) => {
                const crop = getCropById(fld.activeCropId);
                const totalVol = fld.irrigationEvents.reduce((acc, e) => acc + e.volumeM3, 0);

                return (
                  <tr key={fld.id} className="hover:bg-[#17271E]/50 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-[#F3F7F1]">{fld.name}</td>
                    <td className="py-2.5 px-4 text-[#9BB0A0]">{formatArea(fld.areaHa, unitSystem)}</td>
                    <td className="py-2.5 px-4 font-semibold text-[#C5F36B]">{crop?.name || fld.activeCropId}</td>
                    <td className="py-2.5 px-4 text-[#F3F7F1]">{fld.irrigationSystem}</td>
                    <td className="py-2.5 px-4 font-medium text-[#F3F7F1]">{fld.currentSoil.ph?.toFixed(1) || 'N/A'}</td>
                    <td className="py-2.5 px-4 font-semibold text-[#4FAE76]">
                      {fld.currentSoil.organicMatterPercent?.toFixed(1) || 'N/A'}%
                    </td>
                    <td className="py-2.5 px-4 text-[#F3F7F1]">
                      {fld.currentSoil.electricalConductivityDsM?.toFixed(1) || 'N/A'} dS/m
                    </td>
                    <td className="py-2.5 px-4 font-mono text-sky-400">
                      {totalVol > 0 ? `${totalVol.toLocaleString()} m³` : 'No logs'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Responsive Visual Comparison Bars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Field Area Distribution */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
          <h3 className="text-sm font-bold text-[#F3F7F1] mb-3 flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#C5F36B]" />
            <span>Field Parcel Land Distribution</span>
          </h3>
          <div className="space-y-3">
            {currentFarm.fields.map((fld) => {
              const maxArea = Math.max(...currentFarm.fields.map((f) => f.areaHa), 100);
              const pct = Math.round((fld.areaHa / maxArea) * 100);

              return (
                <div key={fld.id} className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span className="text-[#F3F7F1] font-semibold">{fld.name}</span>
                    <span className="text-[#9BB0A0]">{formatArea(fld.areaHa, unitSystem)}</span>
                  </div>
                  <div className="w-full bg-[#17271E] h-3 rounded-full overflow-hidden">
                    <div className="bg-[#C5F36B] h-full rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Soil Organic Matter Benchmark */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
          <h3 className="text-sm font-bold text-[#F3F7F1] mb-3 flex items-center gap-2">
            <Sprout className="w-4 h-4 text-[#4FAE76]" />
            <span>Soil Organic Matter (SOM %) Across Parcels</span>
          </h3>
          <div className="space-y-3">
            {currentFarm.fields.map((fld) => {
              const som = fld.currentSoil.organicMatterPercent || 1.0;
              const pct = Math.min(100, Math.round((som / 5.0) * 100));

              return (
                <div key={fld.id} className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span className="text-[#F3F7F1] font-semibold">{fld.name}</span>
                    <span className="text-[#4FAE76] font-bold">{som.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-[#17271E] h-3 rounded-full overflow-hidden">
                    <div className="bg-[#4FAE76] h-full rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
