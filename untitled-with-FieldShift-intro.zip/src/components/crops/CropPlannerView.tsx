import React, { useState, useMemo } from 'react';
import { useFarm } from '../../context/FarmContext';
import { CROP_CATALOG, getCropById } from '../../domain/cropCatalog';
import { CropData, scoreCropRotation, PriorityWeights } from '../../domain/calculations';
import { formatCurrency, formatDepth } from '../../lib/i18n';
import { CropPlan, PlannedSeason } from '../../domain/types';
import {
  Sprout,
  Plus,
  Trash2,
  Sliders,
  Sparkles,
  Save,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Droplet,
  ShieldAlert,
  HelpCircle,
  Copy,
} from 'lucide-react';

export const CropPlannerView: React.FC = () => {
  const { currentField, currency, saveCropPlan, showNotification } = useFarm();

  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active Plan or create draft from field active plan
  const existingPlan = currentField.cropPlans.find((p) => p.id === currentField.activePlanId) || currentField.cropPlans[0];

  const [planName, setPlanName] = useState<string>(existingPlan?.name || '4-Year Regenerative Rotation');
  const [seasons, setSeasons] = useState<PlannedSeason[]>(() => {
    if (existingPlan && existingPlan.seasons.length > 0) {
      return existingPlan.seasons;
    }
    return [
      {
        year: 2026,
        seasonLabel: 'Year 1 - Fall/Winter',
        cropId: 'wheat',
        targetYieldTonPerHa: 4.8,
        plannedIrrigationMm: 400,
        syntheticNitrogenKgPerHa: 90,
        residueManagement: 'Retained 100%',
      },
      {
        year: 2027,
        seasonLabel: 'Year 2 - Spring/Summer',
        cropId: 'chickpea',
        targetYieldTonPerHa: 2.2,
        plannedIrrigationMm: 310,
        syntheticNitrogenKgPerHa: 20,
        residueManagement: 'Retained 100%',
      },
      {
        year: 2028,
        seasonLabel: 'Year 3 - Fall/Winter',
        cropId: 'barley',
        targetYieldTonPerHa: 4.2,
        plannedIrrigationMm: 350,
        syntheticNitrogenKgPerHa: 80,
        residueManagement: 'Retained 100%',
      },
      {
        year: 2029,
        seasonLabel: 'Year 4 - Perennial/Forage',
        cropId: 'alfalfa',
        targetYieldTonPerHa: 12.0,
        plannedIrrigationMm: 750,
        syntheticNitrogenKgPerHa: 0,
        residueManagement: 'Retained 100%',
      },
    ];
  });

  // User Priorities State
  const [priorities, setPriorities] = useState<PriorityWeights>({
    waterConservation: 75,
    soilImprovement: 85,
    yieldPotential: 50,
    profitability: 70,
    riskReduction: 65,
    lowInput: 60,
  });

  // Filtered Catalog
  const filteredCrops = useMemo(() => {
    return CROP_CATALOG.filter((c) => {
      const matchCat = categoryFilter === 'All' || c.category === categoryFilter;
      const matchQuery =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.scientificName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [categoryFilter, searchQuery]);

  // Current sequence crops
  const sequenceCrops = useMemo(() => {
    return seasons.map((s) => getCropById(s.cropId)).filter(Boolean) as CropData[];
  }, [seasons]);

  // Evaluation Score
  const evaluation = useMemo(() => {
    return scoreCropRotation(sequenceCrops, priorities, currentField.currentSoil, 320);
  }, [sequenceCrops, priorities, currentField.currentSoil]);

  // Add Season
  const handleAddSeason = (cropId: string = 'wheat') => {
    const nextYear = seasons.length > 0 ? seasons[seasons.length - 1].year + 1 : 2026;
    const crop = getCropById(cropId) || CROP_CATALOG[0];
    const newSeason: PlannedSeason = {
      year: nextYear,
      seasonLabel: `Year ${seasons.length + 1}`,
      cropId: crop.id,
      targetYieldTonPerHa: crop.expectedYieldTonPerHa,
      plannedIrrigationMm: crop.waterRequirementMm,
      syntheticNitrogenKgPerHa: crop.isLegume ? 15 : 90,
      residueManagement: 'Retained 100%',
    };
    setSeasons([...seasons, newSeason]);
  };

  const handleRemoveSeason = (index: number) => {
    if (seasons.length <= 1) {
      showNotification('A rotation requires at least 1 season.', 'warning');
      return;
    }
    const updated = seasons.filter((_, i) => i !== index);
    setSeasons(updated);
  };

  const handleUpdateSeasonCrop = (index: number, newCropId: string) => {
    const crop = getCropById(newCropId);
    if (!crop) return;
    setSeasons((prev) =>
      prev.map((s, i) =>
        i === index
          ? {
              ...s,
              cropId: newCropId,
              targetYieldTonPerHa: crop.expectedYieldTonPerHa,
              plannedIrrigationMm: crop.waterRequirementMm,
              syntheticNitrogenKgPerHa: crop.isLegume ? 15 : 90,
            }
          : s
      )
    );
  };

  const handleSavePlan = () => {
    const plan: CropPlan = {
      id: existingPlan?.id || `cp_${Date.now()}`,
      fieldId: currentField.id,
      name: planName,
      createdDate: new Date().toISOString().split('T')[0],
      isBaseline: true,
      seasons,
    };
    saveCropPlan(currentField.id, plan);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              Crop Rotation Engine
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#17271E] text-[#9BB0A0] border border-[#263A2D]">
              {seasons.length}-Season Sequence
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Multi-Year Agronomic Rotation Planner — {currentField.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Evaluate soil organic carbon impact, biological nitrogen fixation, and pest break resilience across seasons.
          </p>
        </div>

        <button
          onClick={handleSavePlan}
          className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-md"
        >
          <Save className="w-4 h-4" />
          <span>Save Rotation Plan</span>
        </button>
      </div>

      {/* Main Builder & Live Evaluation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Sequence Timeline & Builder */}
        <div className="lg:col-span-2 space-y-6">
          {/* Plan Name & Add Season Header */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <input
                type="text"
                value={planName}
                onChange={(e) => setPlanName(e.target.value)}
                placeholder="Rotation Plan Name..."
                className="w-full max-w-sm sm:max-w-md bg-[#17271E] text-sm font-bold text-[#F3F7F1] px-3 py-1.5 rounded-lg border border-[#263A2D] focus:outline-none focus:border-[#C5F36B]"
              />
              <button
                onClick={() => handleAddSeason('wheat')}
                className="px-3 py-1.5 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] text-xs font-semibold rounded-lg border border-[#263A2D] flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Planned Season</span>
              </button>
            </div>

            {/* Sequence Timeline Cards */}
            <div className="space-y-3">
              {seasons.map((season, idx) => {
                const crop = getCropById(season.cropId);
                return (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-[#17271E] border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#C5F36B]/15 border border-[#C5F36B]/30 flex items-center justify-center font-bold text-xs text-[#C5F36B] shrink-0">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#9BB0A0]">{season.seasonLabel}</span>
                          {crop?.isLegume && (
                            <span className="text-[10px] px-1.5 py-0.2 bg-[#4FAE76]/20 text-[#4FAE76] rounded border border-[#4FAE76]/30">
                              N-Fixing Legume
                            </span>
                          )}
                        </div>
                        {/* Crop Selector inside season */}
                        <select
                          value={season.cropId}
                          onChange={(e) => handleUpdateSeasonCrop(idx, e.target.value)}
                          className="mt-1 bg-[#111F19] text-[#F3F7F1] text-xs font-bold rounded-lg px-2.5 py-1 border border-[#263A2D] focus:outline-none focus:border-[#C5F36B]"
                        >
                          {CROP_CATALOG.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name} ({c.category})
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Season Metrics & Inputs */}
                    <div className="flex flex-wrap items-center gap-4 text-xs">
                      <div>
                        <span className="text-[#9BB0A0] block text-[10px]">Target Yield</span>
                        <span className="text-[#F3F7F1] font-semibold">{season.targetYieldTonPerHa} t/ha</span>
                      </div>
                      <div>
                        <span className="text-[#9BB0A0] block text-[10px]">Planned Water</span>
                        <span className="text-sky-400 font-semibold">{season.plannedIrrigationMm} mm</span>
                      </div>
                      <div>
                        <span className="text-[#9BB0A0] block text-[10px]">Synthetic N</span>
                        <span className="text-amber-400 font-semibold">{season.syntheticNitrogenKgPerHa} kg/ha</span>
                      </div>
                      <div>
                        <span className="text-[#9BB0A0] block text-[10px]">Residue</span>
                        <span className="text-[#4FAE76] font-semibold">{season.residueManagement}</span>
                      </div>

                      <button
                        onClick={() => handleRemoveSeason(idx)}
                        className="p-1.5 text-[#9BB0A0] hover:text-red-400 transition-colors ml-auto md:ml-0"
                        title="Remove Season"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* User Priority Sliders (Weighted Multi-Criteria Evaluation) */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
            <div className="flex items-center gap-2 mb-3">
              <Sliders className="w-4 h-4 text-[#C5F36B]" />
              <h3 className="text-sm font-bold text-[#F3F7F1]">Custom Strategy Weights & Priorities</h3>
            </div>
            <p className="text-xs text-[#9BB0A0] mb-4">
              Adjust your farm management goals. The rotation scoring engine dynamically normalizes weights and recalculates multi-criteria suitability.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Water Conservation</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.waterConservation}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.waterConservation}
                  onChange={(e) =>
                    setPriorities({ ...priorities, waterConservation: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Soil Improvement</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.soilImprovement}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.soilImprovement}
                  onChange={(e) =>
                    setPriorities({ ...priorities, soilImprovement: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Yield Potential</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.yieldPotential}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.yieldPotential}
                  onChange={(e) =>
                    setPriorities({ ...priorities, yieldPotential: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Profitability</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.profitability}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.profitability}
                  onChange={(e) =>
                    setPriorities({ ...priorities, profitability: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Risk Reduction</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.riskReduction}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.riskReduction}
                  onChange={(e) =>
                    setPriorities({ ...priorities, riskReduction: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#9BB0A0]">Low Input / Pest Break</span>
                  <span className="text-[#C5F36B] font-bold">{priorities.lowInput}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={priorities.lowInput}
                  onChange={(e) =>
                    setPriorities({ ...priorities, lowInput: parseInt(e.target.value) })
                  }
                  className="w-full accent-[#C5F36B]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Live Rotation Score & Explainability Breakdown */}
        <div className="space-y-6">
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9BB0A0]">
              Overall Rotation Resilience Score
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-5xl font-extrabold text-[#C5F36B]">
                {evaluation.overallScore}
              </span>
              <span className="text-base text-[#9BB0A0]">/ 100</span>
            </div>

            <div className="mt-4 pt-3 border-t border-[#263A2D] space-y-2.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Water Suitability</span>
                <span className="text-[#F3F7F1] font-semibold">{evaluation.waterSuitabilityScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Soil Health & SOM</span>
                <span className="text-[#F3F7F1] font-semibold">{evaluation.soilHealthScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Family Diversity</span>
                <span className="text-[#F3F7F1] font-semibold">{evaluation.diversityScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Pest & Disease Break</span>
                <span className="text-[#F3F7F1] font-semibold">{evaluation.pestBreakScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Operating Margin</span>
                <span className="text-[#C5F36B] font-bold">
                  {formatCurrency(evaluation.netOperatingMarginPerHa, currency)}/ha
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#9BB0A0]">Avg Water Demand</span>
                <span className="text-sky-400 font-semibold">{evaluation.annualAverageWaterMm} mm/yr</span>
              </div>
            </div>
          </div>

          {/* Explainability Breakdown (Why is this suggested?) */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
            <h3 className="text-sm font-bold text-[#F3F7F1] mb-2 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-[#C5F36B]" />
              <span>Explainable Agronomic Findings</span>
            </h3>
            <div className="space-y-2 text-xs">
              {evaluation.explanations.map((exp, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-[#17271E] border border-[#263A2D] text-[#F3F7F1]">
                  {exp}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Searchable Crop Catalog Explorer */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-[#F3F7F1]">Crop Catalog & Agronomic Library</h3>
            <p className="text-xs text-[#9BB0A0]">
              Browse 16 standard crops with salinity thresholds, rooting depths, and gross margin benchmarks.
            </p>
          </div>

          {/* Filter Categories */}
          <div className="flex flex-wrap items-center gap-1.5">
            {['All', 'Cereal', 'Legume', 'Oilseed', 'Forage', 'Vegetable'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  categoryFilter === cat
                    ? 'bg-[#C5F36B] text-[#08130F] font-bold'
                    : 'bg-[#17271E] text-[#9BB0A0] hover:text-[#F3F7F1] border border-[#263A2D]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Crops Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
          {filteredCrops.map((crop) => {
            const isSelectedInPlan = seasons.some((s) => s.cropId === crop.id);
            return (
              <div
                key={crop.id}
                className="p-3.5 rounded-xl bg-[#17271E] border border-[#263A2D] hover:border-[#4FAE76]/60 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-bold text-[#F3F7F1] truncate">{crop.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#111F19] text-[#9BB0A0] border border-[#263A2D]">
                      {crop.category}
                    </span>
                  </div>
                  <p className="text-[10px] text-[#9BB0A0] italic mb-2 truncate">{crop.scientificName}</p>

                  <div className="space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-[#9BB0A0]">Water Need:</span>
                      <span className="text-sky-400 font-semibold">{crop.waterRequirementMm} mm</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#9BB0A0]">Salinity Limit:</span>
                      <span className="text-amber-400 font-semibold">{crop.salinityToleranceDsM} dS/m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#9BB0A0]">Drought Tolerance:</span>
                      <span className="text-[#C5F36B] font-semibold">{crop.droughtTolerance}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#9BB0A0]">Exp. Yield:</span>
                      <span className="text-[#F3F7F1] font-semibold">{crop.expectedYieldTonPerHa} t/ha</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#263A2D] flex items-center justify-between">
                  <span className="text-[10px] text-[#4FAE76] font-semibold">
                    {crop.isLegume ? 'Fixes ~' + crop.nitrogenFixationKgPerHa + ' kg N' : 'Non-legume'}
                  </span>
                  <button
                    onClick={() => handleAddSeason(crop.id)}
                    className="px-2 py-1 bg-[#111F19] hover:bg-[#C5F36B] hover:text-[#08130F] text-[#C5F36B] text-[10px] font-bold rounded border border-[#263A2D] transition-colors"
                  >
                    + Add to Plan
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
