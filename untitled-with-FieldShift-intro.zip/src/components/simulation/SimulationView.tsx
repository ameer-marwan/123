import React, { useState } from 'react';
import { useFarm } from '../../context/FarmContext';
import {
  calculateWaterBalance,
  calculateNitrogenBalance,
} from '../../domain/calculations';
import { getCropById } from '../../domain/cropCatalog';
import { formatCurrency, formatDepth } from '../../lib/i18n';
import {
  Cpu,
  RotateCcw,
  TrendingUp,
  Droplet,
  FlaskConical,
  Scale,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';

export const SimulationView: React.FC = () => {
  const { currentField, currency, unitSystem } = useFarm();
  const crop = getCropById(currentField.activeCropId) || getCropById('wheat')!;

  // Configurable Scenario Inputs
  const [tillage, setTillage] = useState<'Conventional' | 'Conservation Minimum' | 'No-Till'>('Conservation Minimum');
  const [irrigationStrategy, setIrrigationStrategy] = useState<'Standard Full' | 'Deficit Irrigation (-20%)' | 'Surplus Leaching (+15%)'>('Deficit Irrigation (-20%)');
  const [syntheticN, setSyntheticN] = useState<number>(85);
  const [residueRetention, setResidueRetention] = useState<number>(80);
  const [irrigationEfficiency, setIrrigationEfficiency] = useState<number>(0.90);
  const [marketPriceFactor, setMarketPriceFactor] = useState<'low' | 'central' | 'high'>('central');

  // Baseline vs Simulated Calculations
  const basePrecipMm = 45;
  const rawIrrigationMm = 350;
  const appliedIrrigationMm =
    irrigationStrategy === 'Deficit Irrigation (-20%)'
      ? rawIrrigationMm * 0.8
      : irrigationStrategy === 'Surplus Leaching (+15%)'
      ? rawIrrigationMm * 1.15
      : rawIrrigationMm;

  const simWaterBalance = calculateWaterBalance({
    precipitationMm: basePrecipMm,
    irrigationMm: appliedIrrigationMm,
    et0Mm: crop.waterRequirementMm * 0.9,
    cropCoefficientKc: 1.05,
    irrigationEfficiency,
    soilTextureInfiltration: 'loam',
  });

  const simNitrogenBalance = calculateNitrogenBalance({
    appliedFertilizerKgPerHa: syntheticN,
    isLegume: crop.isLegume,
    cropType: crop.name,
    expectedYieldTonPerHa: crop.expectedYieldTonPerHa,
    nRemovalPerTonGrainKg: 22,
    residueRetainedPercent: residueRetention,
    soilOrganicMatterPercent: currentField.currentSoil.organicMatterPercent || 1.5,
  });

  // Financial Sensitivities (Low, Central, High)
  const priceMultiplier = marketPriceFactor === 'low' ? 0.82 : marketPriceFactor === 'high' ? 1.25 : 1.0;
  const yieldMultiplier = tillage === 'No-Till' ? 1.05 : tillage === 'Conventional' ? 0.96 : 1.0;

  const effectiveYield = crop.expectedYieldTonPerHa * yieldMultiplier;
  const effectivePrice = crop.marketPricePerTon * priceMultiplier;
  const grossRevenue = effectiveYield * effectivePrice;

  // Costs: Seed + Water + Fertilizer + Operations
  const waterCostPerMm = 0.85; // approx $/mm/ha
  const totalWaterCost = appliedIrrigationMm * waterCostPerMm;
  const fertilizerCost = syntheticN * 1.35; // approx $/kg N
  const opCost = tillage === 'No-Till' ? 220 : tillage === 'Conservation Minimum' ? 280 : 380;
  const totalCost = totalWaterCost + fertilizerCost + opCost + 150; // + seed
  const operatingMargin = Math.round(grossRevenue - totalCost);

  const handleReset = () => {
    setTillage('Conservation Minimum');
    setIrrigationStrategy('Deficit Irrigation (-20%)');
    setSyntheticN(85);
    setResidueRetention(80);
    setIrrigationEfficiency(0.90);
    setMarketPriceFactor('central');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#C5F36B]/15 text-[#C5F36B] border border-[#C5F36B]/30">
              Agricultural Simulation Engine
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#17271E] text-[#9BB0A0] border border-[#263A2D]">
              Target: {crop.name}
            </span>
          </div>
          <h2 className="text-xl font-bold text-[#F3F7F1]">
            Scenario Modeling & Agronomic Sensitivity — {currentField.name}
          </h2>
          <p className="text-xs text-[#9BB0A0]">
            Simulate water storage, nitrogen budgets, and operating margin responses to varying management practices.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="px-4 py-2 bg-[#17271E] hover:bg-[#263A2D] text-[#C5F36B] text-xs font-semibold rounded-xl border border-[#263A2D] flex items-center justify-center gap-2 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Baseline</span>
        </button>
      </div>

      {/* Grid: Configurable Inputs (Left) and Simulated Outputs (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Input Sliders & Selectors */}
        <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-4">
          <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#C5F36B]" />
            <span>Management Parameters</span>
          </h3>

          <div>
            <label className="block text-xs text-[#9BB0A0] mb-1">Tillage & Soil Disturbance</label>
            <select
              value={tillage}
              onChange={(e: any) => setTillage(e.target.value)}
              className="w-full bg-[#17271E] text-[#F3F7F1] text-xs border border-[#263A2D] rounded-lg p-2.5 focus:outline-none focus:border-[#C5F36B]"
            >
              <option value="Conventional">Conventional Deep Moldboard Tillage</option>
              <option value="Conservation Minimum">Conservation Minimum Tillage</option>
              <option value="No-Till">Direct Drill / Zero-Till</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-[#9BB0A0] mb-1">Irrigation Scheduling Strategy</label>
            <select
              value={irrigationStrategy}
              onChange={(e: any) => setIrrigationStrategy(e.target.value)}
              className="w-full bg-[#17271E] text-[#F3F7F1] text-xs border border-[#263A2D] rounded-lg p-2.5 focus:outline-none focus:border-[#C5F36B]"
            >
              <option value="Standard Full">Standard Full Crop ET Evapotranspiration</option>
              <option value="Deficit Irrigation (-20%)">Regulated Deficit Irrigation (-20% water)</option>
              <option value="Surplus Leaching (+15%)">Salinity Leaching Fraction (+15% water)</option>
            </select>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#9BB0A0]">Synthetic N Fertilizer Input</span>
              <span className="text-amber-400 font-bold">{syntheticN} kg N/ha</span>
            </div>
            <input
              type="range"
              min="0"
              max="220"
              step="5"
              value={syntheticN}
              onChange={(e) => setSyntheticN(parseInt(e.target.value))}
              className="w-full accent-[#C5F36B]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#9BB0A0]">Crop Residue Retention</span>
              <span className="text-[#4FAE76] font-bold">{residueRetention}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="10"
              value={residueRetention}
              onChange={(e) => setResidueRetention(parseInt(e.target.value))}
              className="w-full accent-[#C5F36B]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-[#9BB0A0]">Irrigation Delivery Efficiency</span>
              <span className="text-sky-400 font-bold">{Math.round(irrigationEfficiency * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.55"
              max="0.95"
              step="0.05"
              value={irrigationEfficiency}
              onChange={(e) => setIrrigationEfficiency(parseFloat(e.target.value))}
              className="w-full accent-[#C5F36B]"
            />
          </div>

          <div className="pt-2 border-t border-[#263A2D]">
            <label className="block text-xs text-[#9BB0A0] mb-2">Market Price Sensitivity Scenario</label>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'central', 'high'] as const).map((scen) => (
                <button
                  key={scen}
                  onClick={() => setMarketPriceFactor(scen)}
                  className={`py-1.5 text-xs font-semibold rounded-lg uppercase tracking-wider transition-colors ${
                    marketPriceFactor === scen
                      ? 'bg-[#C5F36B] text-[#08130F]'
                      : 'bg-[#17271E] text-[#9BB0A0] hover:text-[#F3F7F1] border border-[#263A2D]'
                  }`}
                >
                  {scen}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Simulated Models (Water, Nitrogen, Profitability) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Simulated Financial Margins */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#C5F36B]" />
                <span>Simulated Operating Margin & Revenue Projection</span>
              </h3>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#17271E] text-[#C5F36B] border border-[#263A2D] font-mono">
                {marketPriceFactor.toUpperCase()} Case
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#17271E] p-4 rounded-xl border border-[#263A2D]">
                <span className="text-[11px] text-[#9BB0A0] block">Gross Revenue / ha</span>
                <span className="text-2xl font-bold text-[#F3F7F1]">
                  {formatCurrency(Math.round(grossRevenue), currency)}
                </span>
                <span className="text-[10px] text-[#9BB0A0] block mt-1">
                  {effectiveYield.toFixed(1)} t/ha @ {formatCurrency(Math.round(effectivePrice), currency)}/t
                </span>
              </div>

              <div className="bg-[#17271E] p-4 rounded-xl border border-[#263A2D]">
                <span className="text-[11px] text-[#9BB0A0] block">Modeled Operating Cost</span>
                <span className="text-2xl font-bold text-amber-400">
                  {formatCurrency(Math.round(totalCost), currency)}
                </span>
                <span className="text-[10px] text-[#9BB0A0] block mt-1">
                  Water: ${Math.round(totalWaterCost)} • N: ${Math.round(fertilizerCost)} • Tillage: ${opCost}
                </span>
              </div>

              <div className="bg-[#17271E] p-4 rounded-xl border border-[#263A2D]">
                <span className="text-[11px] text-[#9BB0A0] block">Net Operating Margin</span>
                <span className={`text-2xl font-extrabold ${operatingMargin >= 0 ? 'text-[#C5F36B]' : 'text-red-400'}`}>
                  {formatCurrency(operatingMargin, currency)}
                </span>
                <span className="text-[10px] text-[#9BB0A0] block mt-1">
                  Margin return: {Math.round((operatingMargin / (grossRevenue || 1)) * 100)}%
                </span>
              </div>
            </div>
          </div>

          {/* Simulated Water Balance & Nitrogen Dual Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Water Balance Breakdown */}
            <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-[#F3F7F1] flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-sky-400" />
                  Water Balance Model
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#17271E] text-sky-400 border border-[#263A2D]">
                  {simWaterBalance.waterBalanceStatus}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Effective Inflow (Rain + Irrigation):</span>
                  <span className="text-[#F3F7F1] font-semibold">
                    {Math.round(simWaterBalance.effectivePrecipitationMm + simWaterBalance.effectiveIrrigationMm)} mm
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Crop Evapotranspiration (ETc):</span>
                  <span className="text-sky-400 font-semibold">{simWaterBalance.cropEtMm} mm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Surface Runoff (Modeled):</span>
                  <span className="text-[#9BB0A0] font-semibold">{simWaterBalance.runoffMm} mm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Net Storage Delta (ΔS):</span>
                  <span className="text-[#C5F36B] font-semibold">{simWaterBalance.changeInSoilStorageMm} mm</span>
                </div>
              </div>
            </div>

            {/* Nitrogen Balance Breakdown */}
            <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-[#F3F7F1] flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-amber-400" />
                  Nitrogen Budget Model
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#17271E] text-amber-400 border border-[#263A2D]">
                  {simNitrogenBalance.status}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Synthetic Fertilizer Input:</span>
                  <span className="text-amber-400 font-semibold">{simNitrogenBalance.fertilizerInputKgPerHa} kg N</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Biological Fixation (Legume):</span>
                  <span className="text-[#4FAE76] font-semibold">{simNitrogenBalance.biologicalFixationKgPerHa} kg N</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">SOM Mineralization Credit:</span>
                  <span className="text-[#C5F36B] font-semibold">{simNitrogenBalance.mineralizationCreditKgPerHa} kg N</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BB0A0]">Harvest Removal (Uptake):</span>
                  <span className="text-[#9BB0A0] font-semibold">-{simNitrogenBalance.cropUptakeKgPerHa} kg N</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#263A2D]">
                  <span className="text-[#F3F7F1] font-bold">Net Balance (ΔN):</span>
                  <span className={`font-bold ${simNitrogenBalance.netBalanceKgPerHa >= 0 ? 'text-[#C5F36B]' : 'text-red-400'}`}>
                    {simNitrogenBalance.netBalanceKgPerHa} kg N/ha
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Model Transparency & Method References */}
          <div className="p-4 rounded-xl bg-[#111F19] border border-[#263A2D] text-xs text-[#9BB0A0] flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#C5F36B] shrink-0 mt-0.5" />
            <p>
              <strong>Calculation Transparency & Scientific Boundary:</strong> Water balance is computed via the FAO-56 Penman-Monteith single crop coefficient methodology. Nitrogen estimates reflect USDA-NRCS standard grain removal coefficients with mineralization estimates calibrated for regional soil organic carbon fractions. Simulated revenue does not constitute guaranteed farm profitability.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
