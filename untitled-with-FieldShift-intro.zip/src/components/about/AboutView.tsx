import React from 'react';
import { useFarm } from '../../context/FarmContext';
import {
  ShieldCheck,
  Globe2,
  Droplets,
  Sprout,
  Cpu,
  Layers,
  Award,
  BookOpen,
  MapPin,
  CheckCircle2,
  TrendingUp,
  ArrowRight,
  Database,
  ExternalLink,
  Compass,
  Sparkles,
} from 'lucide-react';

export const AboutView: React.FC = () => {
  const { setActiveTab } = useFarm();

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Hero Banner with Agricultural Landscape Wallpaper */}
      <div className="relative rounded-3xl overflow-hidden border border-[#263A2D] shadow-2xl min-h-[320px] flex flex-col justify-end p-6 md:p-10">
        <img
          src="/images/agricultural_field.jpg"
          alt="DAIS Agricultural Landscape"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/80 to-[#08130F]/30" />

        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3.5 py-1 rounded-full text-xs font-black bg-[#C5F36B] text-[#08130F] uppercase tracking-wider shadow-lg">
              DAIS
            </span>
            <span className="text-xs sm:text-sm text-[#C5F36B] font-bold tracking-wide backdrop-blur-md px-3 py-0.5 rounded-full bg-[#111F19]/80 border border-[#263A2D]">
              Digital Agricultural Intelligence Systems
            </span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-[#F3F7F1] tracking-tight">
            Pioneering Precision Agronomic Decision-Support
          </h1>

          <p className="text-xs sm:text-sm text-[#d1e0d5] max-w-2xl leading-relaxed">
            DAIS develops open, scientifically rigorous geospatial intelligence platforms that empower growers, agronomists, and land stewards to optimize crop rotations, protect soil vitality, and safeguard freshwater aquifers against extreme climate volatility.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('overview')}
              className="px-4 py-2 bg-[#C5F36B] hover:bg-[#b2e552] text-[#08130F] font-bold text-xs rounded-xl flex items-center gap-2 transition-transform active:scale-95 shadow-md"
            >
              <span>Explore Farm Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setActiveTab('globe')}
              className="px-4 py-2 bg-[#17271E]/90 hover:bg-[#263A2D] text-[#C5F36B] font-semibold text-xs rounded-xl border border-[#263A2D] flex items-center gap-2 transition-colors backdrop-blur-md shadow-md"
            >
              <Globe2 className="w-3.5 h-3.5" />
              <span>Launch 3D Earth</span>
            </button>
          </div>
        </div>
      </div>

      {/* What is DAIS? Comprehensive Narrative */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] p-6 md:p-8 space-y-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#C5F36B]/15 border border-[#C5F36B]/30 flex items-center justify-center text-[#C5F36B] shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-[#F3F7F1]">What is DAIS?</h2>
            <span className="text-xs text-[#9BB0A0]">Digital Agricultural Intelligence Systems — International Agronomic Research Consortium</span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-[#9BB0A0] leading-relaxed">
          Founded as an international multidisciplinary agronomic research and technology consortium, <strong>DAIS (Digital Agricultural Intelligence Systems)</strong> combines planetary satellite geodesy, pedological soil chemistry, and hydrological physics into a cohesive decision-support ecosystem called <strong>FieldShift</strong>.
        </p>

        <p className="text-xs sm:text-sm text-[#9BB0A0] leading-relaxed">
          Modern agriculture faces unprecedented friction: shifting precipitation windows, rising thermal extremes, declining soil organic carbon, and depleting groundwater reservoirs. Farmers are frequently forced to piece together disjointed forecasts, laboratory soil sheets, and commodity indexes without a single unified system. DAIS unifies these mission-critical workflows into one coherent, transparent architecture.
        </p>

        {/* Global Stats Counter */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-[#263A2D]">
          <div className="bg-[#17271E] p-3 rounded-xl border border-[#263A2D] text-center">
            <span className="text-xl sm:text-2xl font-black text-[#C5F36B] block">14,200+</span>
            <span className="text-[10px] text-[#9BB0A0] uppercase tracking-wider font-semibold">Hectares Monitored</span>
          </div>
          <div className="bg-[#17271E] p-3 rounded-xl border border-[#263A2D] text-center">
            <span className="text-xl sm:text-2xl font-black text-[#38bdf8] block">3 Hubs</span>
            <span className="text-[10px] text-[#9BB0A0] uppercase tracking-wider font-semibold">Global Stations</span>
          </div>
          <div className="bg-[#17271E] p-3 rounded-xl border border-[#263A2D] text-center">
            <span className="text-xl sm:text-2xl font-black text-[#4FAE76] block">16 Crops</span>
            <span className="text-[10px] text-[#9BB0A0] uppercase tracking-wider font-semibold">Agronomic Database</span>
          </div>
          <div className="bg-[#17271E] p-3 rounded-xl border border-[#263A2D] text-center">
            <span className="text-xl sm:text-2xl font-black text-[#facc15] block">100%</span>
            <span className="text-[10px] text-[#9BB0A0] uppercase tracking-wider font-semibold">Data Provenance</span>
          </div>
        </div>
      </div>

      {/* Visual Wallpapers Showcase: Water (Lake) & Soil (Forest) */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-[#F3F7F1]">Visual Geospatial & Ecological Domains</h3>
            <p className="text-xs text-[#9BB0A0]">Photographic telemetry backdrops reflecting real ecosystems</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Water Section with Lake Photo Wallpaper */}
          <div className="group relative rounded-2xl overflow-hidden border border-[#263A2D] shadow-xl min-h-[260px] flex flex-col justify-end p-6">
            <img
              src="/images/lake_water.jpg"
              alt="Freshwater Lake & Reservoir Wallpaper"
              className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/80 to-[#08130F]/20" />

            <div className="relative z-10 space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#38bdf8] text-[#08130F] uppercase tracking-wider">
                  Hydrological Domain
                </span>
                <span className="text-[11px] text-[#38bdf8] font-semibold">
                  Lake & Aquifer Physics
                </span>
              </div>
              <h4 className="text-base sm:text-lg font-bold text-[#F3F7F1]">
                Water Accounting & Reservoir Stewardship
              </h4>
              <p className="text-xs text-[#d1e0d5] line-clamp-2">
                Real-time FAO-56 Penman-Monteith water balances, aquifer overdraft prevention, and 1 mm/ha = 10 m³ volumetric accounting.
              </p>
              <button
                onClick={() => setActiveTab('water')}
                className="pt-1 text-xs text-[#38bdf8] hover:text-[#7dd3fc] font-bold flex items-center gap-1.5 transition-colors"
              >
                <span>Launch Water Suite</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Soil Section with Forest Photo Wallpaper */}
          <div className="group relative rounded-2xl overflow-hidden border border-[#263A2D] shadow-xl min-h-[260px] flex flex-col justify-end p-6">
            <img
              src="/images/forest_soil.jpg"
              alt="Lush Forest Soil & Humus Wallpaper"
              className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#08130F] via-[#08130F]/80 to-[#08130F]/20" />

            <div className="relative z-10 space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#4FAE76] text-[#08130F] uppercase tracking-wider">
                  Pedological Domain
                </span>
                <span className="text-[11px] text-[#4FAE76] font-semibold">
                  Forest Humus & Soil Health
                </span>
              </div>
              <h4 className="text-base sm:text-lg font-bold text-[#F3F7F1]">
                Pedological Diagnostics & Microbiome Vitality
              </h4>
              <p className="text-xs text-[#d1e0d5] line-clamp-2">
                Multi-parameter diagnostic scoring across soil pH, organic matter fractions (SOM %), salinity (ECe), and NPK nutrient balance.
              </p>
              <button
                onClick={() => setActiveTab('soil')}
                className="pt-1 text-xs text-[#4FAE76] hover:text-[#86efac] font-bold flex items-center gap-1.5 transition-colors"
              >
                <span>Launch Soil Diagnostics</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* The 4 Core DAIS Scientific Pillars */}
      <div>
        <h3 className="text-base font-bold text-[#F3F7F1] mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#C5F36B]" />
          <span>The Four Foundational DAIS Pillars</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Pillar 1 */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-2 hover:border-[#38bdf8]/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
                <Globe2 className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-[#F3F7F1]">1. Geospatial Planetary Intelligence</h4>
            </div>
            <p className="text-xs text-[#9BB0A0] leading-relaxed">
              Seamlessly integrates global 3D planetary Earth models with high-resolution sub-meter satellite cadastral mapping. Parcels are measured using exact geodesic equirectangular projections, enabling sub-millimeter precision for parcels ranging from 0.01 ha to 10,000 ha.
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-2 hover:border-[#4FAE76]/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Sprout className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-[#F3F7F1]">2. Pedological & Soil Resilience</h4>
            </div>
            <p className="text-xs text-[#9BB0A0] leading-relaxed">
              Provides multi-parameter diagnostic scoring across soil pH, organic matter fractions (SOM %), electrical conductivity (ECe salinity), and bulk density. Transparent data coverage metrics ensure missing measurements are never fabricated.
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-2 hover:border-[#38bdf8]/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Droplets className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-[#F3F7F1]">3. Hydrological Physics & Aquifer Protection</h4>
            </div>
            <p className="text-xs text-[#9BB0A0] leading-relaxed">
              Implements standardized FAO-56 Penman-Monteith single-layer crop water balance calculations. Strictly enforces the physical volumetric law that 1 mm of depth across 1 hectare equals 10 m³ of water, preventing irrigation overdraft.
            </p>
          </div>

          {/* Pillar 4 */}
          <div className="bg-[#111F19] p-5 rounded-2xl border border-[#263A2D] space-y-2 hover:border-[#facc15]/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Cpu className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-[#F3F7F1]">4. Multi-Season Crop Rotation Optimization</h4>
            </div>
            <p className="text-xs text-[#9BB0A0] leading-relaxed">
              Models multi-year rotation sequences with explainable scoring. Quantifies biological nitrogen fixation credits from legumes (Alfalfa, Chickpea, Soybean) and disease-break values that naturally disrupt pathogen and weed cycles.
            </p>
          </div>
        </div>
      </div>

      {/* Scientific Principles & Truth Boundary */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] p-6 space-y-4">
        <h3 className="text-sm font-bold text-[#F3F7F1] flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#C5F36B]" />
          <span>The DAIS Data Truth & Scientific Integrity Charter</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <div className="flex items-center gap-1.5 text-[#C5F36B] font-bold mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>No Fabricated Data</span>
            </div>
            <p className="text-[#9BB0A0]">
              Every metric displays its explicit provenance: Certified Lab Test, In-Situ Sensor, Live Meteorological API, or Model Projection. Unmeasured parameters are labeled honestly.
            </p>
          </div>

          <div className="p-3.5 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <div className="flex items-center gap-1.5 text-[#C5F36B] font-bold mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Traceable Equations</span>
            </div>
            <p className="text-[#9BB0A0]">
              Calculations are grounded in published agronomic science: FAO-56 Penman-Monteith, USDA-NRCS soil nutrient guidelines, and empirical crop coefficient curves.
            </p>
          </div>

          <div className="p-3.5 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <div className="flex items-center gap-1.5 text-[#C5F36B] font-bold mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Planetary Accessibility</span>
            </div>
            <p className="text-[#9BB0A0]">
              Designed with full internationalization for both English and Arabic (RTL layout), supporting dual metric and imperial unit systems with regional currency adaptability.
            </p>
          </div>
        </div>
      </div>

      {/* Global Deployment Hubs */}
      <div className="bg-[#111F19] rounded-2xl border border-[#263A2D] p-6">
        <h3 className="text-sm font-bold text-[#F3F7F1] mb-3 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#C5F36B]" />
          <span>DAIS Research & Field Deployment Benchmark Hubs</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <span className="font-bold text-[#F3F7F1] block">Al-Kharj Oasis Station</span>
            <span className="text-[11px] text-[#C5F36B]">Riyadh Province, Saudi Arabia</span>
            <p className="text-[#9BB0A0] text-[10px] mt-1">Focus: Hyper-arid precision irrigation, brackish groundwater management, and heat-tolerant crop genetics.</p>
          </div>

          <div className="p-3 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <span className="font-bold text-[#F3F7F1] block">Central Valley Agro Station</span>
            <span className="text-[11px] text-[#C5F36B]">Fresno County, California, USA</span>
            <p className="text-[#9BB0A0] text-[10px] mt-1">Focus: Mediterranean deficit irrigation, high-value vegetable rotation, and groundwater sustainability compliance.</p>
          </div>

          <div className="p-3 bg-[#17271E] rounded-xl border border-[#263A2D]">
            <span className="font-bold text-[#F3F7F1] block">Danube Plains Mollisol Hub</span>
            <span className="text-[11px] text-[#C5F36B]">Ialomița, Romania</span>
            <p className="text-[#9BB0A0] text-[10px] mt-1">Focus: Deep Chernozem soil carbon dynamics, rainfed grain basket crop rotations, and conservation no-till.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
