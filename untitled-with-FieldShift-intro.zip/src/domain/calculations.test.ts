import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePolygonAreaHectares,
  isValidCoordinate,
  hectaresToAcres,
  acresToHectares,
  celsiusToFahrenheit,
  fahrenheitToCelsius,
  mmToInches,
  inchesToMm,
  mmHectareToCubicMeters,
  cubicMetersToGallons,
  calculateWaterBalance,
  calculateNitrogenBalance,
  calculateSoilHealthScore,
  normalizeWeights,
  scoreCropRotation,
  type CropData,
  type PriorityWeights,
} from './calculations.ts';

test('calculatePolygonAreaHectares accurately computes area for non-empty coordinates', () => {
  // A box approx ~100m x 100m near equator (0.001 deg lat is ~111m)
  const coords: Array<[number, number]> = [
    [0.0, 0.0],
    [0.001, 0.0],
    [0.001, 0.001],
    [0.0, 0.001],
  ];
  const area = calculatePolygonAreaHectares(coords);
  assert.ok(area > 1.0 && area < 1.5, `Expected area around ~1.2 ha, got ${area}`);

  // Empty or invalid coords
  assert.equal(calculatePolygonAreaHectares([]), 0);
  assert.equal(calculatePolygonAreaHectares([[1, 2]]), 0);
});

test('isValidCoordinate validates latitude and longitude limits', () => {
  assert.equal(isValidCoordinate(24.15, 47.31), true);
  assert.equal(isValidCoordinate(-33.86, 151.20), true);
  assert.equal(isValidCoordinate(95, 20), false);
  assert.equal(isValidCoordinate(20, 190), false);
  assert.equal(isValidCoordinate(NaN, 10), false);
});

test('Unit conversions behave deterministically and reversibly', () => {
  assert.equal(hectaresToAcres(10), 24.71);
  assert.equal(acresToHectares(24.71), 10);

  assert.equal(celsiusToFahrenheit(0), 32);
  assert.equal(celsiusToFahrenheit(100), 212);
  assert.equal(fahrenheitToCelsius(32), 0);

  assert.equal(mmToInches(25.4), 1);
  assert.equal(inchesToMm(1), 25.4);

  // 1 mm water on 1 ha must equal 10 m3 as mandated in the agronomic rule
  assert.equal(mmHectareToCubicMeters(1, 1), 10);
  assert.equal(mmHectareToCubicMeters(25, 4), 1000);
  assert.equal(cubicMetersToGallons(10), 2642);
});

test('calculateWaterBalance calculates inflows, crop ET, deficit and status', () => {
  const result = calculateWaterBalance({
    precipitationMm: 15,
    irrigationMm: 40,
    et0Mm: 50,
    cropCoefficientKc: 1.0, // ETc = 50 mm
    irrigationEfficiency: 0.90,
  });

  assert.ok(result.cropEtMm === 50);
  assert.ok(result.effectiveIrrigationMm === 36);
  assert.ok(result.waterBalanceStatus === 'Balanced' || result.waterBalanceStatus === 'Deficit');
  assert.equal(result.isWaterStressed, false);
});

test('calculateNitrogenBalance credits biological fixation for legumes', () => {
  // Non-legume wheat
  const wheatBalance = calculateNitrogenBalance({
    appliedFertilizerKgPerHa: 100,
    isLegume: false,
    cropType: 'Winter Wheat',
    expectedYieldTonPerHa: 4.5,
    nRemovalPerTonGrainKg: 20, // 90 kg N uptake
  });
  assert.equal(wheatBalance.biologicalFixationKgPerHa, 0);

  // Legume Chickpea
  const chickpeaBalance = calculateNitrogenBalance({
    appliedFertilizerKgPerHa: 20,
    isLegume: true,
    cropType: 'Chickpea',
    expectedYieldTonPerHa: 2.0,
    nRemovalPerTonGrainKg: 35,
  });
  assert.ok(chickpeaBalance.biologicalFixationKgPerHa > 50, 'Legume should fix significant nitrogen');
});

test('calculateSoilHealthScore handles missing data with honest coverage percentage', () => {
  const partialSoil = calculateSoilHealthScore({
    ph: 7.2,
    organicMatterPercent: 2.8,
  });
  assert.ok(partialSoil.compositeScore > 60);
  assert.ok(partialSoil.dataCoveragePercent < 100, 'Partial test must have less than 100% coverage');
  assert.ok(partialSoil.confidenceRating === 'Exploratory' || partialSoil.confidenceRating === 'Moderate');

  const completeSoil = calculateSoilHealthScore({
    ph: 6.8,
    organicMatterPercent: 3.5,
    electricalConductivityDsM: 0.8,
    nitrogenPpm: 30,
    phosphorusPpm: 25,
    potassiumPpm: 200,
    bulkDensityGPerCm3: 1.25,
  });
  assert.equal(completeSoil.confidenceRating, 'High');
  assert.ok(completeSoil.compositeScore >= 85);
});

test('normalizeWeights handles all-zero inputs safely without division by zero', () => {
  const zeroWeights: PriorityWeights = {
    waterConservation: 0,
    soilImprovement: 0,
    yieldPotential: 0,
    profitability: 0,
    riskReduction: 0,
    lowInput: 0,
  };
  const norm = normalizeWeights(zeroWeights);
  assert.ok(Math.abs(norm.waterConservation - 1/6) < 0.001);
  assert.ok(Math.abs(norm.profitability - 1/6) < 0.001);
});

test('scoreCropRotation calculates multi-criteria scoring and explains legume and break benefits', () => {
  const sampleCrops: CropData[] = [
    {
      id: 'wheat',
      name: 'Winter Wheat',
      scientificName: 'Triticum aestivum',
      category: 'Cereal',
      growingSeasonDays: 140,
      waterRequirementMm: 450,
      optimalPhRange: [6.0, 7.5],
      salinityToleranceDsM: 6.0,
      isLegume: false,
      nitrogenFixationKgPerHa: 0,
      expectedYieldTonPerHa: 4.8,
      marketPricePerTon: 260,
      estimatedInputCostPerHa: 520,
      rootDepthM: 1.2,
      droughtTolerance: 'Moderate',
      diseaseBreakValue: 5,
    },
    {
      id: 'chickpea',
      name: 'Chickpea',
      scientificName: 'Cicer arietinum',
      category: 'Legume',
      growingSeasonDays: 110,
      waterRequirementMm: 320,
      optimalPhRange: [6.5, 8.0],
      salinityToleranceDsM: 2.0,
      isLegume: true,
      nitrogenFixationKgPerHa: 65,
      expectedYieldTonPerHa: 2.2,
      marketPricePerTon: 750,
      estimatedInputCostPerHa: 420,
      rootDepthM: 1.0,
      droughtTolerance: 'High',
      diseaseBreakValue: 8,
    },
  ];

  const priorities: PriorityWeights = {
    waterConservation: 80,
    soilImprovement: 90,
    yieldPotential: 40,
    profitability: 60,
    riskReduction: 70,
    lowInput: 80,
  };

  const score = scoreCropRotation(sampleCrops, priorities, { ph: 7.0, organicMatterPercent: 2.2 });
  assert.ok(score.overallScore > 50 && score.overallScore <= 100);
  assert.ok(score.explanations.some(e => e.includes('legume')), 'Explanation should highlight legume benefits');
  assert.ok(score.netOperatingMarginPerHa > 0, 'Net operating margin should be positive');
});
