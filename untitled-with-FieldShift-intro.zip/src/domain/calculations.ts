/**
 * FieldShift — Agricultural Intelligence Domain Calculations
 * Decoupled, pure, testable agronomic & geospatial logic.
 */

export interface LatLng {
  lat: number;
  lng: number;
}

export interface WaterBalanceInput {
  precipitationMm: number;
  irrigationMm: number;
  et0Mm: number;
  cropCoefficientKc: number; // e.g. 0.4 initial, 1.15 mid-season
  irrigationEfficiency?: number; // 0.60 to 0.95
  soilTextureInfiltration?: 'sandy' | 'loam' | 'clay'; // affects runoff & water holding
}

export interface WaterBalanceResult {
  effectivePrecipitationMm: number;
  effectiveIrrigationMm: number;
  cropEtMm: number;
  runoffMm: number;
  deepDrainageMm: number;
  changeInSoilStorageMm: number;
  waterDeficitMm: number;
  isWaterStressed: boolean;
  waterBalanceStatus: 'Surplus' | 'Balanced' | 'Deficit' | 'Severe Deficit';
}

export interface NitrogenBalanceInput {
  appliedFertilizerKgPerHa: number;
  isLegume: boolean;
  cropType: string;
  expectedYieldTonPerHa: number;
  nRemovalPerTonGrainKg: number; // e.g. 20 kg N / ton wheat grain
  residueRetainedPercent?: number; // 0 to 100%
  soilOrganicMatterPercent?: number;
}

export interface NitrogenBalanceResult {
  biologicalFixationKgPerHa: number;
  fertilizerInputKgPerHa: number;
  mineralizationCreditKgPerHa: number;
  cropUptakeKgPerHa: number;
  estimatedLossKgPerHa: number; // leaching + volatilization
  netBalanceKgPerHa: number;
  status: 'Depletion Risk' | 'Optimal' | 'Excess / Leaching Risk';
}

export interface SoilProfileInput {
  ph?: number;
  organicMatterPercent?: number;
  electricalConductivityDsM?: number; // Salinity in dS/m
  nitrogenPpm?: number;
  phosphorusPpm?: number;
  potassiumPpm?: number;
  bulkDensityGPerCm3?: number; // 1.1 to 1.6 g/cm3
  depthCm?: number;
}

export interface SoilHealthResult {
  compositeScore: number; // 0 - 100
  dataCoveragePercent: number; // percentage of tested indicators provided
  phScore: number;
  somScore: number;
  salinityScore: number;
  nutrientScore: number;
  physicalScore: number;
  confidenceRating: 'High' | 'Moderate' | 'Exploratory' | 'Insufficient Data';
  limitingFactors: string[];
  recommendations: string[];
}

export interface PriorityWeights {
  waterConservation: number; // 0 - 100
  soilImprovement: number;   // 0 - 100
  yieldPotential: number;    // 0 - 100
  profitability: number;     // 0 - 100
  riskReduction: number;     // 0 - 100
  lowInput: number;          // 0 - 100
}

export interface NormalizedWeights {
  waterConservation: number;
  soilImprovement: number;
  yieldPotential: number;
  profitability: number;
  riskReduction: number;
  lowInput: number;
}

export interface CropData {
  id: string;
  name: string;
  scientificName: string;
  category: 'Cereal' | 'Legume' | 'Oilseed' | 'Forage' | 'Vegetable' | 'Fiber';
  growingSeasonDays: number;
  waterRequirementMm: number; // seasonal mm
  optimalPhRange: [number, number];
  salinityToleranceDsM: number; // threshold ECe
  isLegume: boolean;
  nitrogenFixationKgPerHa: number;
  expectedYieldTonPerHa: number;
  marketPricePerTon: number; // USD or configured
  estimatedInputCostPerHa: number;
  rootDepthM: number;
  droughtTolerance: 'Low' | 'Moderate' | 'High' | 'Very High';
  diseaseBreakValue: number; // 1 - 10
}

export interface RotationScoreResult {
  overallScore: number; // 0 - 100
  waterSuitabilityScore: number;
  soilHealthScore: number;
  diversityScore: number;
  pestBreakScore: number;
  economicMarginScore: number;
  riskMitigationScore: number;
  factorContributions: Record<string, number>;
  explanations: string[];
  totalExpectedRevenuePerHa: number;
  totalCostPerHa: number;
  netOperatingMarginPerHa: number;
  annualAverageWaterMm: number;
}

// ---------------------------------------------------------------------------
// 1. GEOSPATIAL & AREA CALCULATIONS
// ---------------------------------------------------------------------------

const EARTH_RADIUS_METERS = 6378137;

/**
 * Calculates polygon area in hectares using equirectangular projection Shoelace formula.
 * High precision for farm scale parcels (0.01 ha to 10,000 ha).
 * Supports coordinates array of [lat, lng].
 */
export function calculatePolygonAreaHectares(coords: Array<[number, number]>): number {
  if (!coords || coords.length < 3) return 0;

  // Mean latitude for planar equirectangular projection
  const meanLat = coords.reduce((sum, c) => sum + c[0], 0) / coords.length;
  const latRad = (meanLat * Math.PI) / 180;
  const metersPerDegLat = 111132.92 - 559.82 * Math.cos(2 * latRad) + 1.175 * Math.cos(4 * latRad);
  const metersPerDegLng = 111412.84 * Math.cos(latRad) - 93.5 * Math.cos(3 * latRad);

  // Convert lat/lng to projected local x, y in meters
  const projected = coords.map(([lat, lng]) => ({
    x: lng * metersPerDegLng,
    y: lat * metersPerDegLat,
  }));

  // Standard Shoelace formula on planar metric coordinates
  let sum = 0;
  const n = projected.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    sum += projected[i].x * projected[j].y;
    sum -= projected[j].x * projected[i].y;
  }

  const areaSqMeters = Math.abs(sum) / 2.0;
  // Convert square meters to hectares (1 ha = 10,000 m2)
  const hectares = areaSqMeters / 10000;
  return Math.round(hectares * 100) / 100;
}

export function isValidCoordinate(lat: number, lng: number): boolean {
  if (typeof lat !== 'number' || typeof lng !== 'number') return false;
  if (isNaN(lat) || isNaN(lng)) return false;
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}

// ---------------------------------------------------------------------------
// 2. UNIT CONVERSIONS
// ---------------------------------------------------------------------------

export function hectaresToAcres(ha: number): number {
  return Math.round(ha * 2.47105381 * 100) / 100;
}

export function acresToHectares(ac: number): number {
  return Math.round((ac / 2.47105381) * 100) / 100;
}

export function celsiusToFahrenheit(c: number): number {
  return Math.round(((c * 9) / 5 + 32) * 10) / 10;
}

export function fahrenheitToCelsius(f: number): number {
  return Math.round((((f - 32) * 5) / 9) * 10) / 10;
}

export function mmToInches(mm: number): number {
  return Math.round((mm / 25.4) * 100) / 100;
}

export function inchesToMm(inch: number): number {
  return Math.round(inch * 25.4 * 10) / 10;
}

/**
 * 1 mm water across 1 hectare corresponds to 10 cubic meters (10 m3).
 */
export function mmHectareToCubicMeters(depthMm: number, ha: number): number {
  if (depthMm <= 0 || ha <= 0) return 0;
  return Math.round(depthMm * ha * 10 * 10) / 10;
}

export function cubicMetersToGallons(m3: number): number {
  return Math.round(m3 * 264.172);
}

// ---------------------------------------------------------------------------
// 3. WATER BALANCE ENGINE
// ---------------------------------------------------------------------------

export function calculateWaterBalance(input: WaterBalanceInput): WaterBalanceResult {
  const {
    precipitationMm,
    irrigationMm,
    et0Mm,
    cropCoefficientKc,
    irrigationEfficiency = 0.85,
    soilTextureInfiltration = 'loam',
  } = input;

  // Runoff coefficient based on soil texture
  let runoffCoeff = 0.10;
  if (soilTextureInfiltration === 'sandy') runoffCoeff = 0.05;
  if (soilTextureInfiltration === 'clay') runoffCoeff = 0.22;

  const totalInflowMm = precipitationMm + irrigationMm;
  const runoffMm = Math.round(totalInflowMm * runoffCoeff * 10) / 10;
  const effectivePrecipitationMm = Math.max(0, Math.round((precipitationMm * (1 - runoffCoeff)) * 10) / 10);
  const effectiveIrrigationMm = Math.round(irrigationMm * irrigationEfficiency * 10) / 10;

  // Crop Evapotranspiration ETc = ET0 * Kc
  const cropEtMm = Math.round(et0Mm * cropCoefficientKc * 10) / 10;

  // Deep drainage occurs if water applied exceeds crop ET + holding buffer (simplified)
  const availableWater = effectivePrecipitationMm + effectiveIrrigationMm;
  const excess = availableWater - cropEtMm;
  const deepDrainageMm = excess > 15 ? Math.round((excess - 15) * 0.4 * 10) / 10 : 0;

  // Change in soil water storage: Inflows - Outflows
  const changeInSoilStorageMm = Math.round((effectivePrecipitationMm + effectiveIrrigationMm - cropEtMm - deepDrainageMm) * 10) / 10;

  // Water deficit is any unmet crop water requirement
  const waterDeficitMm = Math.max(0, Math.round((cropEtMm - availableWater) * 10) / 10);
  const isWaterStressed = waterDeficitMm > 15;

  let waterBalanceStatus: 'Surplus' | 'Balanced' | 'Deficit' | 'Severe Deficit' = 'Balanced';
  if (changeInSoilStorageMm > 20) waterBalanceStatus = 'Surplus';
  else if (waterDeficitMm > 35) waterBalanceStatus = 'Severe Deficit';
  else if (waterDeficitMm > 10) waterBalanceStatus = 'Deficit';

  return {
    effectivePrecipitationMm,
    effectiveIrrigationMm,
    cropEtMm,
    runoffMm,
    deepDrainageMm,
    changeInSoilStorageMm,
    waterDeficitMm,
    isWaterStressed,
    waterBalanceStatus,
  };
}

// ---------------------------------------------------------------------------
// 4. NITROGEN BALANCE ENGINE
// ---------------------------------------------------------------------------

export function calculateNitrogenBalance(input: NitrogenBalanceInput): NitrogenBalanceResult {
  const {
    appliedFertilizerKgPerHa,
    isLegume,
    cropType,
    expectedYieldTonPerHa,
    nRemovalPerTonGrainKg,
    residueRetainedPercent = 50,
    soilOrganicMatterPercent = 1.5,
  } = input;

  // Biological Fixation estimation
  let biologicalFixationKgPerHa = 0;
  if (isLegume) {
    const c = cropType.toLowerCase();
    if (c.includes('alfalfa')) biologicalFixationKgPerHa = 180;
    else if (c.includes('soybean')) biologicalFixationKgPerHa = 110;
    else if (c.includes('chickpea') || c.includes('lentil') || c.includes('faba')) biologicalFixationKgPerHa = 65;
    else biologicalFixationKgPerHa = 50;
  }

  // Soil Organic Matter mineralization credit: approx 15-20 kg N per 1% SOM per season
  const mineralizationCreditKgPerHa = Math.round(soilOrganicMatterPercent * 18);

  // Crop uptake removed in grain/harvest
  const cropUptakeKgPerHa = Math.round(expectedYieldTonPerHa * nRemovalPerTonGrainKg);

  // Residue return credit (if crop residue remains on field)
  const residueNCredit = Math.round((cropUptakeKgPerHa * 0.25) * (residueRetainedPercent / 100));

  // Losses (leaching, volatilization, denitrification ~15-20% of applied N)
  const estimatedLossKgPerHa = Math.round(appliedFertilizerKgPerHa * 0.18);

  // Net Balance = (Fertilizer + Fixation + Mineralization + Residue) - (Uptake + Losses)
  const totalInputs = appliedFertilizerKgPerHa + biologicalFixationKgPerHa + mineralizationCreditKgPerHa + residueNCredit;
  const totalOutputs = cropUptakeKgPerHa + estimatedLossKgPerHa;
  const netBalanceKgPerHa = Math.round(totalInputs - totalOutputs);

  let status: 'Depletion Risk' | 'Optimal' | 'Excess / Leaching Risk' = 'Optimal';
  if (netBalanceKgPerHa < -25) status = 'Depletion Risk';
  else if (netBalanceKgPerHa > 50) status = 'Excess / Leaching Risk';

  return {
    biologicalFixationKgPerHa,
    fertilizerInputKgPerHa: appliedFertilizerKgPerHa,
    mineralizationCreditKgPerHa,
    cropUptakeKgPerHa,
    estimatedLossKgPerHa,
    netBalanceKgPerHa,
    status,
  };
}

// ---------------------------------------------------------------------------
// 5. SOIL HEALTH SCORING (TRANSPARENT & HONEST)
// ---------------------------------------------------------------------------

export function calculateSoilHealthScore(soil: SoilProfileInput): SoilHealthResult {
  const limitingFactors: string[] = [];
  const recommendations: string[] = [];
  let evaluatedCount = 0;
  const totalTrackedIndicators = 6; // pH, SOM, EC, N, P, K

  // 1. pH Scoring (Optimum around 6.5 - 7.5)
  let phScore = 70; // baseline if missing
  if (soil.ph !== undefined && !isNaN(soil.ph)) {
    evaluatedCount++;
    const ph = soil.ph;
    if (ph >= 6.3 && ph <= 7.5) {
      phScore = 100;
    } else if (ph >= 5.8 && ph < 6.3) {
      phScore = 80;
    } else if (ph > 7.5 && ph <= 8.2) {
      phScore = 80;
      limitingFactors.push(`Mild alkalinity (pH ${ph.toFixed(1)}): may reduce micronutrient (Fe, Zn) availability.`);
    } else if (ph > 8.2) {
      phScore = 50;
      limitingFactors.push(`High alkalinity (pH ${ph.toFixed(1)}): phosphorus tie-up and micronutrient chlorosis risk.`);
      recommendations.push('Apply elemental sulfur, acidifying fertilizers, or gypsum depending on free lime content.');
    } else {
      phScore = 45;
      limitingFactors.push(`Soil acidity (pH ${ph.toFixed(1)}): potential aluminum toxicity and poor nodulation in legumes.`);
      recommendations.push('Consider agricultural lime application to bring pH closer to 6.5.');
    }
  }

  // 2. SOM % Scoring (Optimum > 3.0%)
  let somScore = 50;
  if (soil.organicMatterPercent !== undefined && !isNaN(soil.organicMatterPercent)) {
    evaluatedCount++;
    const som = soil.organicMatterPercent;
    if (som >= 3.5) somScore = 100;
    else if (som >= 2.5) somScore = 85;
    else if (som >= 1.5) somScore = 65;
    else if (som >= 0.8) {
      somScore = 45;
      limitingFactors.push(`Low soil organic matter (${som.toFixed(1)}%): reduced water-holding and microbial resilience.`);
      recommendations.push('Integrate cover crops, retain crop residue, and add composted organic matter.');
    } else {
      somScore = 25;
      limitingFactors.push(`Critically depleted organic matter (${som.toFixed(1)}%): degraded aggregate stability.`);
      recommendations.push('Urgent adoption of minimal tillage, cover cropping, and organic amendment.');
    }
  }

  // 3. Salinity / Electrical Conductivity EC (dS/m)
  let salinityScore = 80;
  if (soil.electricalConductivityDsM !== undefined && !isNaN(soil.electricalConductivityDsM)) {
    evaluatedCount++;
    const ec = soil.electricalConductivityDsM;
    if (ec < 1.0) salinityScore = 100;
    else if (ec < 2.0) salinityScore = 90;
    else if (ec < 4.0) {
      salinityScore = 65;
      limitingFactors.push(`Moderate salinity (EC ${ec.toFixed(1)} dS/m): yields of sensitive crops may be impaired.`);
      recommendations.push('Select salt-tolerant varieties (barley, sorghum) and practice leaching fraction irrigation.');
    } else if (ec < 8.0) {
      salinityScore = 40;
      limitingFactors.push(`High salinity (EC ${ec.toFixed(1)} dS/m): osmotic stress and seed germination inhibition.`);
      recommendations.push('Requires leaching with good quality water and adequate drainage installation.');
    } else {
      salinityScore = 20;
      limitingFactors.push(`Severe salinity (EC ${ec.toFixed(1)} dS/m): severe crop toxicity.`);
    }
  }

  // 4. Nutrients (N, P, K)
  let nutrientScore = 65;
  const nutrientPoints: number[] = [];
  if (soil.nitrogenPpm !== undefined && !isNaN(soil.nitrogenPpm)) {
    evaluatedCount++;
    nutrientPoints.push(soil.nitrogenPpm > 25 ? 90 : soil.nitrogenPpm > 12 ? 75 : 45);
  }
  if (soil.phosphorusPpm !== undefined && !isNaN(soil.phosphorusPpm)) {
    evaluatedCount++;
    nutrientPoints.push(soil.phosphorusPpm > 20 ? 90 : soil.phosphorusPpm > 10 ? 70 : 40);
  }
  if (soil.potassiumPpm !== undefined && !isNaN(soil.potassiumPpm)) {
    evaluatedCount++;
    nutrientPoints.push(soil.potassiumPpm > 150 ? 95 : soil.potassiumPpm > 80 ? 75 : 45);
  }
  if (nutrientPoints.length > 0) {
    nutrientScore = Math.round(nutrientPoints.reduce((a, b) => a + b, 0) / nutrientPoints.length);
  }

  // 5. Physical (Bulk Density)
  let physicalScore = 75;
  if (soil.bulkDensityGPerCm3 !== undefined && !isNaN(soil.bulkDensityGPerCm3)) {
    const bd = soil.bulkDensityGPerCm3;
    if (bd <= 1.35) physicalScore = 95;
    else if (bd <= 1.45) physicalScore = 80;
    else {
      physicalScore = 50;
      limitingFactors.push(`Soil compaction detected (Bulk density ${bd.toFixed(2)} g/cm³): restricted root penetration.`);
      recommendations.push('Perform targeted deep ripping or plant deep-taproot cover crops (tillage radish, alfalfa).');
    }
  }

  const dataCoveragePercent = Math.round((evaluatedCount / totalTrackedIndicators) * 100);

  // Composite calculation
  const compositeScore = Math.round(
    phScore * 0.25 +
    somScore * 0.25 +
    salinityScore * 0.20 +
    nutrientScore * 0.20 +
    physicalScore * 0.10
  );

  let confidenceRating: 'High' | 'Moderate' | 'Exploratory' | 'Insufficient Data' = 'Moderate';
  if (dataCoveragePercent >= 80) confidenceRating = 'High';
  else if (dataCoveragePercent >= 50) confidenceRating = 'Moderate';
  else if (dataCoveragePercent >= 20) confidenceRating = 'Exploratory';
  else confidenceRating = 'Insufficient Data';

  if (recommendations.length === 0) {
    recommendations.push('Maintain balanced fertility and continue routine annual soil testing.');
  }

  return {
    compositeScore,
    dataCoveragePercent,
    phScore,
    somScore,
    salinityScore,
    nutrientScore,
    physicalScore,
    confidenceRating,
    limitingFactors,
    recommendations,
  };
}

// ---------------------------------------------------------------------------
// 6. WEIGHT NORMALIZATION & MULTI-CRITERIA SCORING
// ---------------------------------------------------------------------------

export function normalizeWeights(weights: PriorityWeights): NormalizedWeights {
  const sum =
    weights.waterConservation +
    weights.soilImprovement +
    weights.yieldPotential +
    weights.profitability +
    weights.riskReduction +
    weights.lowInput;

  // Handle case where user sets all weights to zero
  if (sum <= 0) {
    const equalWeight = 1 / 6;
    return {
      waterConservation: equalWeight,
      soilImprovement: equalWeight,
      yieldPotential: equalWeight,
      profitability: equalWeight,
      riskReduction: equalWeight,
      lowInput: equalWeight,
    };
  }

  return {
    waterConservation: weights.waterConservation / sum,
    soilImprovement: weights.soilImprovement / sum,
    yieldPotential: weights.yieldPotential / sum,
    profitability: weights.profitability / sum,
    riskReduction: weights.riskReduction / sum,
    lowInput: weights.lowInput / sum,
  };
}

export function scoreCropRotation(
  sequence: CropData[],
  priorities: PriorityWeights,
  soil: SoilProfileInput,
  annualRainfallMm: number = 350
): RotationScoreResult {
  if (!sequence || sequence.length === 0) {
    return {
      overallScore: 0,
      waterSuitabilityScore: 0,
      soilHealthScore: 0,
      diversityScore: 0,
      pestBreakScore: 0,
      economicMarginScore: 0,
      riskMitigationScore: 0,
      factorContributions: {},
      explanations: ['No crops selected in sequence.'],
      totalExpectedRevenuePerHa: 0,
      totalCostPerHa: 0,
      netOperatingMarginPerHa: 0,
      annualAverageWaterMm: 0,
    };
  }

  const normalized = normalizeWeights(priorities);
  const n = sequence.length;

  // 1. Water Suitability
  const avgWaterDemand = sequence.reduce((acc, c) => acc + c.waterRequirementMm, 0) / n;
  // If rainfall + typical irrigation fulfills demand with minimal stress
  const waterRatio = annualRainfallMm / (avgWaterDemand || 1);
  const waterSuitabilityScore = Math.min(100, Math.max(30, Math.round(100 - Math.abs(1 - waterRatio) * 45)));

  // 2. Soil Health & Legume Bonus
  const legumeCount = sequence.filter((c) => c.isLegume).length;
  const legumeRatio = legumeCount / n;
  let soilHealthScore = 60 + legumeRatio * 35;
  if (soil.organicMatterPercent && soil.organicMatterPercent < 1.5 && legumeCount > 0) {
    soilHealthScore += 5; // Extra bonus for depleted soils receiving legume rotational benefits
  }
  soilHealthScore = Math.min(100, Math.round(soilHealthScore));

  // 3. Crop Diversity & Family Separation (avoid monoculture repetition)
  const uniqueCategories = new Set(sequence.map((c) => c.category)).size;
  const diversityScore = Math.min(100, Math.round((uniqueCategories / Math.min(4, n)) * 95));

  // 4. Pest / Disease Break Score
  let consecutiveSameCount = 0;
  for (let i = 0; i < n - 1; i++) {
    if (sequence[i].category === sequence[i + 1].category) {
      consecutiveSameCount++;
    }
  }
  const avgDiseaseBreak = sequence.reduce((acc, c) => acc + c.diseaseBreakValue, 0) / n;
  const pestBreakScore = Math.max(25, Math.min(100, Math.round(avgDiseaseBreak * 10 - consecutiveSameCount * 20)));

  // 5. Economic Margin Score
  let totalRev = 0;
  let totalCost = 0;
  sequence.forEach((c) => {
    totalRev += c.expectedYieldTonPerHa * c.marketPricePerTon;
    totalCost += c.estimatedInputCostPerHa;
  });
  const netOperatingMarginPerHa = Math.round((totalRev - totalCost) / n);
  // Normalize margin (assume $200 - $1500 range)
  const economicMarginScore = Math.min(100, Math.max(20, Math.round((netOperatingMarginPerHa / 1200) * 100)));

  // 6. Risk Mitigation (Drought tolerance & salinity tolerance)
  const soilEc = soil.electricalConductivityDsM || 1.2;
  const salinityCompatibility = sequence.every((c) => c.salinityToleranceDsM >= soilEc);
  const droughtHighCount = sequence.filter((c) => c.droughtTolerance === 'High' || c.droughtTolerance === 'Very High').length;
  let riskMitigationScore = 55 + (droughtHighCount / n) * 35;
  if (!salinityCompatibility) riskMitigationScore -= 20;
  riskMitigationScore = Math.min(100, Math.max(15, Math.round(riskMitigationScore)));

  // Weighted overall composite
  const factorContributions: Record<string, number> = {
    waterConservation: Math.round(waterSuitabilityScore * normalized.waterConservation * 10) / 10,
    soilImprovement: Math.round(soilHealthScore * normalized.soilImprovement * 10) / 10,
    yieldPotential: Math.round(diversityScore * normalized.yieldPotential * 10) / 10,
    profitability: Math.round(economicMarginScore * normalized.profitability * 10) / 10,
    riskReduction: Math.round(riskMitigationScore * normalized.riskReduction * 10) / 10,
    lowInput: Math.round(pestBreakScore * normalized.lowInput * 10) / 10,
  };

  const overallScore = Math.round(
    waterSuitabilityScore * normalized.waterConservation +
    soilHealthScore * normalized.soilImprovement +
    diversityScore * normalized.yieldPotential +
    economicMarginScore * normalized.profitability +
    riskMitigationScore * normalized.riskReduction +
    pestBreakScore * normalized.lowInput
  );

  const explanations: string[] = [];
  if (legumeCount > 0) {
    explanations.push(`Contains ${legumeCount} legume season(s) providing natural biological nitrogen fixation.`);
  } else {
    explanations.push('No legumes in sequence; rotation relies entirely on synthetic nitrogen fertilizer.');
  }

  if (consecutiveSameCount > 0) {
    explanations.push(`Warning: ${consecutiveSameCount} consecutive season(s) with identical crop categories may elevate pathogen risk.`);
  } else {
    explanations.push('Strong rotation separation interrupts pest and weed lifecycle cycles.');
  }

  if (avgWaterDemand > 600) {
    explanations.push(`High average water demand (${Math.round(avgWaterDemand)} mm/season) requires reliable irrigation infrastructure.`);
  } else {
    explanations.push(`Water-conserving sequence averaging ${Math.round(avgWaterDemand)} mm/season.`);
  }

  return {
    overallScore,
    waterSuitabilityScore,
    soilHealthScore,
    diversityScore,
    pestBreakScore,
    economicMarginScore,
    riskMitigationScore,
    factorContributions,
    explanations,
    totalExpectedRevenuePerHa: Math.round(totalRev / n),
    totalCostPerHa: Math.round(totalCost / n),
    netOperatingMarginPerHa,
    annualAverageWaterMm: Math.round(avgWaterDemand),
  };
}
