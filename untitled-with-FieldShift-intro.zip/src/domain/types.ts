/**
 * FieldShift — Core Domain Types
 */

import { CropData, SoilProfileInput } from './calculations';

export interface FieldBoundary {
  type: 'Polygon';
  coordinates: Array<[number, number]>; // [lat, lng]
}

export interface SoilObservationRecord {
  id: string;
  fieldId: string;
  date: string;
  sourceType: 'Measured Lab Test' | 'In-Situ Sensor' | 'Model Estimate' | 'User Observation';
  laboratory?: string;
  sampleDepthCm: number;
  ph: number;
  organicMatterPercent: number;
  electricalConductivityDsM: number;
  nitrogenPpm: number;
  phosphorusPpm: number;
  potassiumPpm: number;
  bulkDensityGPerCm3: number;
  notes?: string;
}

export interface IrrigationEvent {
  id: string;
  fieldId: string;
  date: string;
  volumeM3: number;
  depthMm: number;
  method: 'Precision Drip' | 'Center Pivot' | 'Micro-Sprinkler' | 'Furrow / Surface';
  durationHours: number;
  waterSource: 'Deep Aquifer' | 'Canal Irrigation' | 'Treated Recycled' | 'Rainwater Catchment';
  notes?: string;
}

export interface PlannedSeason {
  year: number;
  seasonLabel: string; // e.g. "Year 1 - Fall/Winter"
  cropId: string;
  targetYieldTonPerHa: number;
  plannedIrrigationMm: number;
  syntheticNitrogenKgPerHa: number;
  residueManagement: 'Retained 100%' | 'Mulched 50%' | 'Removed / Baled';
}

export interface CropPlan {
  id: string;
  fieldId: string;
  name: string;
  createdDate: string;
  isBaseline: boolean;
  seasons: PlannedSeason[];
}

export interface ClimateHazardAlert {
  id: string;
  hazardType: 'Extreme Heat' | 'Late Frost' | 'Prolonged Drought' | 'Heavy Precipitation Runoff' | 'Saline Osmotic Stress';
  severity: 'Critical' | 'Warning' | 'Advisory';
  title: string;
  description: string;
  thresholdExceeded: string;
  mitigationAction?: string;
  isReviewed: boolean;
  timestamp: string;
}

export interface FieldEntity {
  id: string;
  farmId: string;
  name: string;
  areaHa: number;
  soilType: string;
  slopePercent: number;
  irrigationSystem: 'Drip' | 'Pivot' | 'Sprinkler' | 'Rainfed';
  boundary: FieldBoundary;
  activeCropId: string;
  plantingDate?: string;
  currentSoil: SoilProfileInput;
  soilHistory: SoilObservationRecord[];
  irrigationEvents: IrrigationEvent[];
  cropPlans: CropPlan[];
  activePlanId: string;
  alerts: ClimateHazardAlert[];
}

export interface FarmEntity {
  id: string;
  name: string;
  owner: string;
  region: string;
  country: string;
  centerCoordinates: [number, number]; // [lat, lng]
  elevationMeters: number;
  climateZone: string;
  currency: 'USD' | 'SAR' | 'EUR';
  unitSystem: 'metric' | 'imperial';
  fields: FieldEntity[];
  notes?: string;
}

export interface WeatherDay {
  date: string;
  weatherCode: number;
  tempMaxC: number;
  tempMinC: number;
  precipSumMm: number;
  precipProbMax: number;
  windSpeedMaxKmh: number;
  et0Mm: number;
}

export interface WeatherCurrent {
  temperatureC: number;
  relativeHumidity: number;
  precipitationMm: number;
  windSpeedKmh: number;
  windDirectionDeg: number;
  surfacePressureHpa: number;
  cloudCoverPercent: number;
  weatherCode: number;
  time: string;
}

export interface WeatherState {
  current: WeatherCurrent | null;
  daily: WeatherDay[];
  isLoading: boolean;
  error: string | null;
  lastUpdated: string | null;
  source: string;
  isStale: boolean;
}
