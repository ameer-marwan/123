/**
 * FieldShift — Internationalization & Localization (English & Arabic)
 */

export type Language = 'en' | 'ar';
export type UnitSystem = 'metric' | 'imperial';
export type Currency = 'USD' | 'SAR' | 'EUR';

export interface Translations {
  appName: string;
  tagline: string;
  // Navigation
  navOverview: string;
  navMap: string;
  navGlobe: string;
  navWeather: string;
  navSoil: string;
  navCrops: string;
  navSimulation: string;
  navWater: string;
  navClimate: string;
  navAnalytics: string;
  navReports: string;
  navAbout: string;
  navSettings: string;

  // Overview
  currentFarm: string;
  currentField: string;
  switchFarm: string;
  switchField: string;
  demoDatasetBadge: string;
  liveApiBadge: string;
  measuredDataBadge: string;
  modelEstimateBadge: string;
  intelligenceFeedTitle: string;
  quickMetrics: string;
  temperature: string;
  precipitation: string;
  soilMoisture: string;
  soilPh: string;
  soilOrganicMatter: string;
  irrigationDemand: string;
  waterBalance: string;
  activeCrop: string;
  rotationScore: string;
  estimatedMargin: string;

  // Actions
  actionSearch: string;
  actionExportCsv: string;
  actionGenerateReport: string;
  actionAddObservation: string;
  actionAddIrrigation: string;
  actionSimulate: string;
  actionSavePlan: string;
  actionResetDemo: string;
  actionAskAdvisor: string;
  actionGroundingSearch: string;
  actionGroundingMaps: string;

  // Common
  loading: string;
  error: string;
  noData: string;
  confidence: string;
  dataCoverage: string;
  viewDetails: string;
  close: string;
  cancel: string;
  save: string;
  edit: string;
  delete: string;
  status: string;
}

export const DICTIONARY: Record<Language, Translations> = {
  en: {
    appName: 'FieldShift',
    tagline: 'Geospatial Agricultural Decision-Support & Intelligence Platform',
    navOverview: 'Overview',
    navMap: 'Farm Map',
    navGlobe: '3D Globe',
    navWeather: 'Weather',
    navSoil: 'Soil Diagnostics',
    navCrops: 'Crop Planner',
    navSimulation: 'Simulation',
    navWater: 'Water & Irrigation',
    navClimate: 'Climate Risk',
    navAnalytics: 'Analytics',
    navReports: 'Reports',
    navAbout: 'About DAIS',
    navSettings: 'Settings',

    currentFarm: 'Active Farm',
    currentField: 'Active Field',
    switchFarm: 'Switch Farm',
    switchField: 'Switch Field',
    demoDatasetBadge: 'Demo Benchmark Data',
    liveApiBadge: 'Live Open-Meteo API',
    measuredDataBadge: 'Certified Lab Observation',
    modelEstimateBadge: 'Agronomic Model Estimate',
    intelligenceFeedTitle: 'Farm Intelligence & Agronomic Alerts',
    quickMetrics: 'Key Agro-Climatic Indicators',
    temperature: 'Air Temperature',
    precipitation: 'Precipitation',
    soilMoisture: 'Topsoil Moisture',
    soilPh: 'Soil pH',
    soilOrganicMatter: 'Organic Matter (SOM)',
    irrigationDemand: 'Irrigation Requirement',
    waterBalance: 'Seasonal Water Balance',
    activeCrop: 'Current Crop',
    rotationScore: 'Rotation Resilience',
    estimatedMargin: 'Est. Operating Margin',

    actionSearch: 'Search Location or Coordinates',
    actionExportCsv: 'Export Data (CSV)',
    actionGenerateReport: 'Generate Field Report',
    actionAddObservation: 'Record Soil Test',
    actionAddIrrigation: 'Log Irrigation Event',
    actionSimulate: 'Run Scenario Simulation',
    actionSavePlan: 'Save Crop Plan',
    actionResetDemo: 'Reset Demo Data',
    actionAskAdvisor: 'Ask Agronomic Consultant',
    actionGroundingSearch: 'Verify with Live Search',
    actionGroundingMaps: 'Find Nearby Agri-Suppliers',

    loading: 'Processing agricultural telemetry...',
    error: 'An error occurred while loading data.',
    noData: 'No observational data available',
    confidence: 'Confidence',
    dataCoverage: 'Data Coverage',
    viewDetails: 'View Details',
    close: 'Close',
    cancel: 'Cancel',
    save: 'Save Changes',
    edit: 'Edit Boundary',
    delete: 'Delete',
    status: 'Status',
  },
  ar: {
    appName: 'فيلد شفت (FieldShift)',
    tagline: 'منصة الذكاء الزراعي والدعم الجغرافي المكاني لاتخاذ القرار',
    navOverview: 'نظرة عامة',
    navMap: 'خريطة الحقل',
    navGlobe: 'الكرة الأرضية 3D',
    navWeather: 'الأرصاد الجوية',
    navSoil: 'صحة وتشخيص التربة',
    navCrops: 'مخطط الدورات الزراعية',
    navSimulation: 'المحاكاة الزراعية',
    navWater: 'إدارة الري والمياه',
    navClimate: 'المخاطر المناخية',
    navAnalytics: 'التحليلات البيانية',
    navReports: 'التقارير المتكاملة',
    navAbout: 'عن منصة DAIS',
    navSettings: 'الإعدادات',

    currentFarm: 'المزرعة الحالية',
    currentField: 'الحقل المحدد',
    switchFarm: 'تبديل المزرعة',
    switchField: 'تبديل الحقل',
    demoDatasetBadge: 'بيانات تجريبية قياسية',
    liveApiBadge: 'بيانات مباشرة من Open-Meteo',
    measuredDataBadge: 'فحص مخبري معتمد',
    modelEstimateBadge: 'تقدير نموذجي زراعي',
    intelligenceFeedTitle: 'تنبيهات واستشارات الذكاء الزراعي',
    quickMetrics: 'المؤشرات الزراعية والمناخية الرئيسية',
    temperature: 'درجة حرارة الهواء',
    precipitation: 'هطول الأمطار',
    soilMoisture: 'رطوبة الطبقة السطحية',
    soilPh: 'حموضة التربة (pH)',
    soilOrganicMatter: 'المادة العضوية (SOM)',
    irrigationDemand: 'الاحتياج المائي للري',
    waterBalance: 'الميزان المائي الموسمي',
    activeCrop: 'المحصول الحالي',
    rotationScore: 'كفاءة الدورة الزراعية',
    estimatedMargin: 'هامش الربح التشغيلي التقديري',

    actionSearch: 'بحث عن موقع أو إحداثيات',
    actionExportCsv: 'تصدير البيانات (CSV)',
    actionGenerateReport: 'إنشاء تقرير الحقل',
    actionAddObservation: 'تسجيل فحص تربة جديد',
    actionAddIrrigation: 'تسجيل عملية ري',
    actionSimulate: 'تشغيل محاكاة السيناريو',
    actionSavePlan: 'حفظ الخطة الزراعية',
    actionResetDemo: 'إعادة ضبط البيانات التجريبية',
    actionAskAdvisor: 'استشارة الخبير الزراعي',
    actionGroundingSearch: 'التحقق عبر بحث Google المباشر',
    actionGroundingMaps: 'البحث عن الموردين والمختبرات القريبة',

    loading: 'جاري تحميل البيانات الزراعية...',
    error: 'حدث خطأ أثناء تحميل البيانات.',
    noData: 'لا تتوفر بيانات قياس مسجلة',
    confidence: 'مستوى الثقة',
    dataCoverage: 'اكتمال البيانات',
    viewDetails: 'عرض التفاصيل',
    close: 'إغلاق',
    cancel: 'إلغاء',
    save: 'حفظ التغييرات',
    edit: 'تعديل الحدود',
    delete: 'حذف',
    status: 'الحالة',
  },
};

export function formatCurrency(amount: number, currency: Currency): string {
  if (currency === 'SAR') {
    return `${amount.toLocaleString()} SAR`;
  }
  if (currency === 'EUR') {
    return `€${amount.toLocaleString()}`;
  }
  return `$${amount.toLocaleString()}`;
}

export function formatArea(areaHa: number, unitSystem: UnitSystem): string {
  if (unitSystem === 'imperial') {
    const acres = areaHa * 2.47105;
    return `${acres.toFixed(1)} ac`;
  }
  return `${areaHa.toFixed(1)} ha`;
}

export function formatTemperature(celsius: number, unitSystem: UnitSystem): string {
  if (unitSystem === 'imperial') {
    const f = (celsius * 9) / 5 + 32;
    return `${f.toFixed(1)}°F`;
  }
  return `${celsius.toFixed(1)}°C`;
}

export function formatDepth(mm: number, unitSystem: UnitSystem): string {
  if (unitSystem === 'imperial') {
    const inches = mm / 25.4;
    return `${inches.toFixed(2)} in`;
  }
  return `${mm.toFixed(1)} mm`;
}
