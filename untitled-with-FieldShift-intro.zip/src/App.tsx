import React, { useEffect, useState } from 'react';
import { FarmProvider, useFarm } from './context/FarmContext';
import { AppShell } from './components/layout/AppShell';
import { OverviewView } from './components/dashboard/OverviewView';
import { LeafletFarmMap } from './components/map/LeafletFarmMap';
import { ThreeGlobe } from './components/globe/ThreeGlobe';
import { WeatherView } from './components/weather/WeatherView';
import { SoilView } from './components/soil/SoilView';
import { CropPlannerView } from './components/crops/CropPlannerView';
import { SimulationView } from './components/simulation/SimulationView';
import { WaterManagementView } from './components/water/WaterManagementView';
import { ClimateRiskView } from './components/climate/ClimateRiskView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { ReportsView } from './components/reports/ReportsView';
import { AboutView } from './components/about/AboutView';
import { SettingsView } from './components/settings/SettingsView';
import { FieldShiftIntro } from './components/FieldShiftIntro';
import './components/FieldShiftIntro.css';

const TabRouter: React.FC = () => {
  const { activeTab } = useFarm();

  switch (activeTab) {
    case 'overview':
      return <OverviewView />;
    case 'map':
      return <LeafletFarmMap />;
    case 'globe':
      return <ThreeGlobe />;
    case 'weather':
      return <WeatherView />;
    case 'soil':
      return <SoilView />;
    case 'crops':
      return <CropPlannerView />;
    case 'simulation':
      return <SimulationView />;
    case 'water':
      return <WaterManagementView />;
    case 'climate':
      return <ClimateRiskView />;
    case 'analytics':
      return <AnalyticsView />;
    case 'reports':
      return <ReportsView />;
    case 'about':
      return <AboutView />;
    case 'settings':
      return <SettingsView />;
    default:
      return <OverviewView />;
  }
};

export default function App() {
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    document.body.style.overflow = showIntro ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [showIntro]);

  return (
    <FarmProvider>
      {showIntro ? <FieldShiftIntro onComplete={() => setShowIntro(false)} /> : (
        <div className="fieldshift-workspace-enter">
          <AppShell><TabRouter /></AppShell>
        </div>
      )}
    </FarmProvider>
  );
}
