# FieldShift — Agricultural Intelligence Platform

FieldShift is a production-grade, full-stack geospatial agricultural decision-support platform designed for farm managers, agronomists, and precision agriculture practitioners. It combines 3D planetary Earth visualization, 2D satellite farm boundary mapping, live weather intelligence, multi-season crop rotation optimization, water balance modeling, soil diagnostics, and grounded AI consultation.

---

## Architecture Overview

- **Frontend:** React 19, TypeScript (strict), Vite, Tailwind CSS, Three.js (3D Earth & Farm Markers), Leaflet (2D satellite farm parcels & polygon drawing).
- **Backend:** Node.js Express server (`server.ts`) with Vite dev middleware (`"dev": "tsx server.ts"`).
- **AI Intelligence:** `@google/genai` TypeScript SDK:
  - **Google Search Grounding:** Real-time web citations for grain commodity prices, regional pest alerts, and extension publications via `gemini-3.8-flash`.
  - **Google Maps Grounding:** Geolocation-grounded supplier mapping for local soil testing labs, seed depots, and irrigation parts via `gemini-3.8-flash`.
  - **Agronomy Chatbot & Advisor:** Multi-turn conversational agronomist with conversation history and domain system instructions.
- **Weather Services:** Open-Meteo API proxy with in-memory caching and fallback baselines.
- **Agronomic Modeling Engine:**
  - Planar equirectangular Shoelace polygon area calculation ($0.01$ to $10,000$ ha).
  - Dual $K_c$ crop coefficient evapotranspiration ($ET_c = ET_0 \times K_c$).
  - FAO-56 single-layer soil water balance ($\Delta S = P + I - ET_c - R - D$).
  - Volumetric conversion: $1\text{ mm}$ across $1\text{ ha} = 10\text{ m}^3$.
  - Biological nitrogen fixation credits for legumes (Alfalfa, Chickpea, Soybean, Lentil, Faba bean).
  - Multi-criteria weighted rotation scoring with user-defined priority sliders.

---

## Quick Start & Development

### 1. Prerequisites
- Node.js version: **v22+**
- Package manager: **npm** or **bun**

### 2. Installation
```bash
npm install
```

### 3. Environment Variables
Create a `.env` file in the project root:
```env
GEMINI_API_KEY="your-gemini-api-key"
PORT=3000
```
*(The key is accessed strictly server-side and is never exposed in browser bundles).*

### 4. Running the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Running Automated Unit Tests
```bash
npm test
```
Runs the native Node 22 test suite (`node --test`) covering geodesic field area, unit conversions, water balance, nitrogen budgets, and rotation scoring.

### 6. Production Build
```bash
npm run build
npm start
```

---

## Primary Navigation Modules

1. **Overview Dashboard:** Consolidated KPI cards, live temperature/ET0, soil reaction, composite health score, and farm intelligence alerts.
2. **Farm Map:** Interactive 2D satellite map powered by Leaflet & Esri World Imagery with interactive polygon boundary drawing and live hectare area computation.
3. **3D Globe:** Interactive Three.js Earth sphere with procedural terrain shader, day/night lighting, and glowing farm location pins.
4. **Agrometeorology:** Open-Meteo live synchronization, 7-day forecast cards, and FAO-56 Penman-Monteith reference evapotranspiration trend chart.
5. **Soil Diagnostics:** Laboratory test logging, historical observations log, limiting factor diagnostics, and composite soil health index.
6. **Crop Planner:** Multi-season rotation builder with 16 distinct crops, live weighted priority sliders, and transparent explainability findings.
7. **Simulation Engine:** Configurable tillage disturbance, irrigation strategy, synthetic N, and residue retention with low/central/high margin sensitivity.
8. **Water Management:** Volumetric water accounting ($1\text{ mm/ha} = 10\text{ m}^3$), irrigation logging, and delivery efficiency benchmarking.
9. **Climate Risk:** Threshold-based hazard tracking for extreme heat, frost, salinity osmotic stress, and drought dry spells.
10. **Analytics:** Cross-field comparative table, metric distributions, and one-click CSV data export.
11. **Reports Generator:** Print-ready certified field dossiers with customizable sections and print styles.
12. **Agronomy AI Assistant:** Multi-turn chatbot with Google Search Grounding and Google Maps Grounding.
13. **Settings:** Internationalization (English LTR and Arabic RTL), Dark/Light visual themes, and Metric/Imperial unit conversions.

---

## Benchmark Demo Farms

- **Al-Kharj Precision Oasis Farm** (Saudi Arabia): Arid desert climate, center-pivot and drip irrigation, salinity management for barley, sorghum, and alfalfa.
- **Central Valley Agro-Ecological Station** (California, USA): Mediterranean climate, high-value processing tomato and wheat rotation.
- **Danube Plains Chernozem Farm** (Romania): Continental chernozem mollisols, rainfed wheat and sunflower rotation.
