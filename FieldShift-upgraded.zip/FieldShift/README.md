# FieldShift upgraded workspace

The application is in `artifacts/fieldshift`. Start with [its README](artifacts/fieldshift/README.md) for installation, development, production builds, tests, data contracts and limitations. [The upgrade report](artifacts/fieldshift/UPGRADE-REPORT.md) records changes and actual verification.

From this directory, run `pnpm install --frozen-lockfile`, then `pnpm --filter @workspace/fieldshift run dev`. Node.js 24 and pnpm 11.25.0 were used for validation. No database or API key is required for this browser-local app. External weather, geocoding and tiles require network access.

The supplied shared API/database packages are retained, but FieldShift does not depend on their service running. No tracked files in the separate `/workspace/123` checkout were changed.
