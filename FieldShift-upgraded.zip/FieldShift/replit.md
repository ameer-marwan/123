# FieldShift

An agricultural decision-support web app for exploring farm fields, live weather, soil observations, crop plans, irrigation records, climate signals, and reports.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Optional API/database scaffold only: `DATABASE_URL` — not required by FieldShift
- For the standalone app, `pnpm --filter @workspace/fieldshift run dev` uses port 5173 by default; `PORT` can override it.
- `pnpm --filter @workspace/fieldshift run typecheck` — typecheck FieldShift.
- `PORT=5000 BASE_PATH=/ pnpm --filter @workspace/fieldshift run build` — build FieldShift.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/fieldshift/src/App.tsx` — routes, local record workflows and browser persistence.
- `artifacts/fieldshift/src/domain/` — geometry, planning, storage validation and screening rules.
- `artifacts/fieldshift/src/services/environment.ts` — validated Open-Meteo requests and freshness cache.
- `artifacts/fieldshift/src/components/LocationBar.tsx` — shared selection, search and coordinates.
- `artifacts/fieldshift/src/components/GeoGlobe.tsx` — interaction-rendered globe with surface selection.
- `artifacts/fieldshift/src/index.css` — FieldShift visual theme and responsive styles.
- `artifacts/fieldshift/README.md` — setup, demo-data provenance, integrations, and limitations.
- `artifacts/api-server` and `lib/api-spec` are shared workspace scaffolds; FieldShift does not currently use them for its farm data.

## Architecture decisions

- FieldShift farm data is browser-local in this version; no account, server sync, or cross-device persistence is connected.
- Live weather and place search use public Open-Meteo endpoints; map tiles use OpenStreetMap with attribution.
- Sample soil, crop, yield, cost, and irrigation data is deterministic and visibly labeled; it must not be presented as measured farm data.

## Product

FieldShift provides a field overview, interactive Leaflet map and Three.js globe, weather, soil observations, weighted crop rotation planning, irrigation and water-balance estimates, near-term climate signals, analytics, printable/CSV reports, and English/Arabic plus theme and unit preferences.

## User preferences

Keep the difference between live external data, user-entered observations, sample demo data, and modeled estimates visible. Never replace a failed live data request with fabricated observations.

See `artifacts/fieldshift/README.md` and `UPGRADE-REPORT.md` for source contracts, test commands, limitations and upgrade evidence.

## Gotchas

- The FieldShift demo reset removes locally entered browser data and restores deterministic sample records.
- Weather, geocoding, and map tiles require an internet connection.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
