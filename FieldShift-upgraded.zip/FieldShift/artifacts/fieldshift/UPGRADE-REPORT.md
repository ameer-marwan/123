# FieldShift upgrade report

## Scope and preservation

The user-supplied ZIP, rather than the separate `ameer-marwan/123` checkout,
was upgraded according to the attached text brief. The original uploaded ZIP
remains the backup. All original archive files were retained. Existing branding,
assets, navigation, local record storage and usable map/globe workflows were
preserved. The separate GitHub checkout has no modifications from this work.

The initial audit found a pnpm React/TypeScript workspace with a large App.tsx,
Leaflet, Three.js, browser-local records, public Open-Meteo requests and unused
shared API/database scaffolding. Main issues were inconsistent selection across
field controls, reference-marker-only globe picking, a continuous render loop,
stale data risk, weak response/storage validation, manually entered polygon
areas, all-field analytics under a selected-field label, prefilled soil entries,
and an invalid pnpm esbuild permission placeholder.

## Implemented

- Persistent shared selected point across all pages, with place search,
  coordinate entry, map clicks, globe surface picking, explicit field selection,
  selection method/time and reset. Saved field records stay separate from an
  unrelated point. No device-location permission is requested.
- Interaction-rendered, stationary globe with corrected texture-coordinate
  mapping, a synchronized point marker, drag/keyboard rotation, zoom and useful
  WebGL failure alternatives. Three.js is lazy-loaded in a separate chunk.
- Selected-point map marker, scale control, visible tile-error state and field
  reconstruction after switching back from the globe.
- Draw/edit/save outlines with undo and computed spherical area. Invalid,
  intersecting, duplicate, degenerate, oversized and date-line-crossing shapes
  are rejected. Existing demo shapes/areas remain explicitly illustrative.
- Shared typed environmental client: exact selected coordinates, 15-second
  timeout, cancellation, response/array/unit validation, bounded 15-minute cache,
  retrieval times and honest missing/error states. Model soil properties use
  hourly fields instead of requesting unsupported current soil variables.
- Current weather labeled as model output; daily forecast distinguishes null
  from zero. Soil depth/time and water/ET₀ meanings remain explicit.
- Live water/environment panel actually rendered on Water; the local reference
  difference no longer subtracts unknown rainfall as though it were zero.
- Entered soil records start blank and retain depth, method and lab reference.
  Values are validated and remain separate from seeded demo assumptions.
- Crop comparisons use linked entered pH and optional water-budget scenarios,
  explain all assumptions, normalize priorities and handle all-zero/invalid
  inputs. Same-family adjacent rotation years are flagged. Generic forecast
  screening shows explicit heat/frost/rain thresholds and limitations.
- Analytics filters data to the selected field. CSV reports retain provenance,
  selected-point scope, timestamps and spreadsheet-formula protection.
- Area/currency display preferences, accessible location forms, focus/skip
  controls, reduced-motion support, responsive layouts and zoomable viewport.
- Schema-checked local records. Invalid stored originals are preserved with a
  recovery warning, rather than overwritten silently.
- Standalone development defaults, documented setup/deployment, source contracts,
  asset notes, tests and production output.

## Verification

Environment: Linux, Node v24.19.0, pnpm 11.25.0, Chromium with software WebGL.

| Check | Result |
| --- | --- |
| Frozen dependency installation | Passed after replacing supplied `allowBuilds.esbuild` placeholder with `true`; checksum/TLS/package-age protections retained |
| Workspace TypeScript checks | Passed across library and artifact packages |
| Domain/data-contract tests | 19 passed, 0 failed, 0 skipped |
| Browser checks on dev server | 22 passed |
| Same browser checks on production preview | 22 passed |
| Workspace production builds | Passed with `PORT=5173 BASE_PATH=/ pnpm run build` |
| Original files preserved | No original archive files removed |
| Separate GitHub checkout | Clean, unchanged |
| Live weather/geocoder/tile retrieval | Blocked by this runtime's outbound policy, HTTP 403 |

The first unconfigured root build failed because the unrelated mockup sandbox
requires `PORT`; supplying its documented environment fixed it. FieldShift has
standalone defaults and builds without those exports. Build warnings remain for
a >500 kB main JavaScript chunk and the retained API scaffold's bundle sizes;
these are warnings, not hidden build failures. The Earth module is separately
lazy-loaded (~484 kB uncompressed).

Browser coverage includes all ten routes, onboarding keyboard entry, persisted
coordinates, explicit search choice, map/field/globe synchronization, stationary
rendering, manual rotation and zoom, map reconstruction, boundary creation and
editing, soil metadata, field-filtered analytics, CSV export, invalid planning
inputs, stale response protection, malformed responses, 390px and 768px layouts,
no uncaught app exceptions, WebGL fallback and corrupted-storage preservation.

**All successful provider responses in automated tests are fixtures.** They are
not evidence of live weather, actual soil measurements, provider availability or
validated agricultural recommendations. The unmocked API/geocoder/tile requests
returned proxy 403 errors. No live success is claimed. Provider documentation
was also blocked in this runtime; current terms/coverage must be verified before
production use.

## Configuration and running

Run from `FieldShift/`:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/fieldshift run dev
```

Open the printed local address in your own browser; default port is 5173.
The prepared cloud instance also has a production preview process on port 5174.
Processes are temporary and not a deployment or shareable preview. This chat's
onboarding UI does not provide a public preview link.

No app API keys or database environment variables are needed. `PORT` is optional;
`BASE_PATH` must be `/`. Public data requests require access to
`api.open-meteo.com`, `geocoding-api.open-meteo.com` and `tile.openstreetmap.org`.
Provider documentation uses `open-meteo.com`. These domains were added to the
saved cloud-environment draft, preserving previous domain entries. Review/save
settings and publish to apply the draft, then retry live requests. Saving a
draft did not apply networking or publish this app. Existing onboarding startup
instructions for the separate Node repository were preserved.

## Remaining limitations

This is an improved browser-local learning/planning application, not the entire
production platform envisioned in the brief. No multi-user authentication,
server-backed farm persistence, cloud backups, live AI assistant, NASA/NDVI
layers, SoilGrids/national soil survey client, actual groundwater/reservoir
supply, historical climate baselines, field-wide spatial aggregation, calibrated
crop model, local planting calendar or lab-file import is connected. Arabic
translation remains partial. No external security audit, physical-device/GPU
matrix, commercial licensing review or calibrated scientific validation was
performed. Photos/texture licensing should be reviewed before distribution.

Read README.md for exact data meanings, formulas, units, privacy implications,
test commands, deployment requirements and known limitations. These limitations
are not silently replaced with demo measurements or invented credentials.
