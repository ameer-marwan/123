import { test } from "node:test";
import assert from "node:assert/strict";
import {
  previewSoilCsv,
  soilObservationSchema,
  optionalMeasurement,
  soilFingerprint,
  sampleDateSchema,
} from "../src/domain/soil.ts";
const importCsv = (
  text: string,
  existing: ReturnType<typeof soilObservationSchema.parse>[] = [],
) => previewSoilCsv(text, "field-1", "lab.csv", existing);
const row = () => ({
  id: "sample-1",
  fieldId: "field-1",
  date: "2025-01-01",
  ph: 6.8,
  organicMatterPct: null,
  moisturePct: null,
  nitrogenMgKg: null,
  source: "Entered",
  notes: "",
});
test("blank measurements stay null while an entered zero is retained", () => {
  assert.equal(optionalMeasurement(""), null);
  assert.equal(optionalMeasurement("  "), null);
  assert.equal(optionalMeasurement("0"), 0);
  assert.equal(optionalMeasurement("1.2e1"), 12);
});
test("numbers reject units, percent signs, hex and nonfinite values", () => {
  for (const s of [
    "6.8 pH",
    "20%",
    "0x10",
    "NaN",
    "Infinity",
    "1e999",
    "1,000",
  ])
    assert.throws(() => optionalMeasurement(s));
});
test("a partial manual soil record is valid without invented nutrient values", () => {
  assert.equal(soilObservationSchema.parse(row()).nitrogenMgKg, null);
});
test("a record with no measurements is rejected", () => {
  assert.equal(
    soilObservationSchema.safeParse({ ...row(), ph: null }).success,
    false,
  );
});
test("invalid calendar and future sample dates are rejected", () => {
  for (const date of ["2025-02-30", "2025-13-01", "2099-01-01", "01/02/2025"])
    assert.equal(sampleDateSchema.safeParse(date).success, false);
  assert.equal(sampleDateSchema.safeParse("2024-02-29").success, true);
});
test("ranges are validated for manual and imported samples", () => {
  assert.equal(
    soilObservationSchema.safeParse({ ...row(), ph: 14.1 }).success,
    false,
  );
  assert.equal(
    soilObservationSchema.safeParse({ ...row(), moisturePct: 101 }).success,
    false,
  );
  assert.equal(
    soilObservationSchema.safeParse({ ...row(), samplingDepthCm: -1 }).success,
    false,
  );
});
test("CSV preserves omitted values and records field, file and source", () => {
  const p = importCsv("sample_date,ph,reference\n2025-01-01,6.8,LAB-42");
  assert.equal(p.errors.length, 0);
  assert.equal(p.rows[0].nitrogenMgKg, null);
  assert.equal(p.rows[0].reference, "LAB-42");
  assert.equal(p.rows[0].fieldId, "field-1");
  assert.equal(p.rows[0].source, "Entered");
  assert.equal(p.rows[0].inputMethod, "csv");
  assert.equal(p.rows[0].importFile, "lab.csv");
});
test("BOM CRLF and quoted commas, quotes and newlines are supported", () => {
  const p = importCsv(
    '\uFEFFsample_date,ph,method,notes\r\n2025-01-01,6.8,"water, 1:2","Line one\nLine ""two"""\r\n',
  );
  assert.equal(p.errors.length, 0);
  assert.equal(p.rows[0].method, "water, 1:2");
  assert.equal(p.rows[0].notes, 'Line one\nLine "two"');
});
test("unit-bearing headers are explicit and SOC is not treated as OM", () => {
  for (const header of ["soc_pct", "nitrogen_ppm", "ph,ph"]) {
    const p = importCsv(`sample_date,${header}\n2025-01-01,4`);
    assert.equal(p.rows.length, 0);
    assert.ok(p.errors.length);
  }
});
test("malformed quoted CSV and wrong column counts do not partially import", () => {
  for (const text of [
    'sample_date,ph\n2025-01-01,"6.8',
    "sample_date,ph\n2025-01-01,6.8,extra",
    'sample_date,ph\n2025-01-01,"6.8"bad',
  ])
    assert.ok(importCsv(text).errors.length);
});
test("import is atomic when any row is invalid", () => {
  const p = importCsv("sample_date,ph\n2025-01-01,6.8\n2025-02-30,7");
  assert.equal(p.rows.length, 0);
  assert.match(p.errors[0], /Row 3/);
});
test("duplicate samples are skipped within a file and against saved records", () => {
  const first = importCsv("sample_date,ph\n2025-01-01,6.8\n2025-01-01,6.8");
  assert.equal(first.rows.length, 1);
  assert.equal(first.duplicates, 1);
  const again = importCsv("sample_date,ph\n2025-01-01,6.8", first.rows);
  assert.equal(again.rows.length, 0);
  assert.equal(again.duplicates, 1);
});
test("samples in a different field are not incorrectly deduplicated", () => {
  const p = importCsv("sample_date,ph\n2025-01-01,6.8", [
    { ...row(), fieldId: "other" },
  ]);
  assert.equal(p.rows.length, 1);
});
test("duplicate fingerprint is independent of import file and record id", () => {
  assert.equal(
    soilFingerprint(row()),
    soilFingerprint({
      ...row(),
      id: "another",
      inputMethod: "csv",
      importFile: "another.csv",
    }),
  );
});
test("CSV size and row limits are enforced", () => {
  assert.ok(importCsv("x".repeat(1024 * 1024 + 1)).errors.length);
  assert.ok(
    importCsv("sample_date,ph\n" + Array(501).fill("2025-01-01,6.8").join("\n"))
      .errors.length,
  );
});
test("empty CSV, headers only and unmeasured rows are rejected", () => {
  for (const text of [
    "",
    "sample_date,ph",
    "sample_date,notes\n2025-01-01,test",
    "sample_date,ph\n2025-01-01,",
  ])
    assert.ok(importCsv(text).errors.length);
});
