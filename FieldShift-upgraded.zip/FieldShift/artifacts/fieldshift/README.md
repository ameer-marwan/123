# FieldShift

FieldShift is a React/TypeScript agricultural learning and planning workspace.
This upgrade preserves the supplied design, branding, local records, images,
Leaflet map and Three.js Earth texture. It improves shared geography, data
integrity and explainable planning. It is **not** a validated agronomic model
or a production multi-user farm management service.

## Run locally

Requirements: Node.js 24 and pnpm 11.25.0. From the archive's `FieldShift/` root:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/fieldshift run dev
```

Open the dev server's printed address in your local browser (default port 5173).
`PORT` can override the port. `BASE_PATH` defaults to `/`; only root-hosted
routing is supported. No database, authentication or API key is required for
this browser-local app. The unrelated API-server/database scaffold remains in
the workspace; do not run database migrations to use FieldShift.

In a sandbox with an unwritable home, set `XDG_DATA_HOME` and `XDG_CACHE_HOME`
to writable directories and pass a writable `--store-dir` during installation.
These are tooling settings, not application secrets.

## Build, preview and tests

From the workspace root:

```sh
pnpm run typecheck
pnpm --filter @workspace/fieldshift run test
pnpm --filter @workspace/fieldshift run build
pnpm --filter @workspace/fieldshift run serve
```

The preview server serves `artifacts/fieldshift/dist/public`. For browser tests,
start the dev or preview server separately, then run:

```sh
pnpm --filter @workspace/fieldshift exec playwright install chromium
pnpm --filter @workspace/fieldshift run test:e2e
```

If a compatible Chromium is already installed, skip downloading the browser and
set `CHROMIUM_PATH` to its executable. `TEST_BASE_URL` defaults to the local
server on port 5173. Browser tests use explicitly mocked provider responses and
blocked tile requests; passing tests do not establish live provider health.
Screenshots and a sample CSV are written to `test-results/` in the test working
directory. Domain tests use Node's built-in TypeScript support and test runner.

## One selected point, separate field records

The persistent location bar accepts place search and `latitude, longitude`
coordinates. Search shows choices; it never silently chooses an ambiguous name.
Map clicks and globe surface clicks update this same state across all pages.
Selection records its method and time. Reset restores the original demo point.
Device location is never requested.

Saved field selection uses its boundary's mean latitude and circular mean
longitude as a **reference point**, not a polygon average or guaranteed interior
centroid. This is explicitly separate from field-wide environmental analysis.
Selecting an unrelated point does not relocate the saved demo farm or attach
its samples to that point. Only soil entries linked to an explicitly selected
field are eligible for that field's pH screening.

Field outlines can be drawn, edited, saved and deleted. Area is computed on a
sphere (radius 6,371,008.8 m) and stored in hectares, using the longitude-edge /
sine-latitude spherical area formula. The app rejects duplicate vertices,
intersections, degenerate or very large shapes and date-line-crossing outlines.
Planning shapes are not cadastral surveys. Existing demo areas remain seeded
assumptions until an outline is edited; they are not surveyed polygon areas.
Editing an outline does not rewrite previously logged irrigation volumes.

The globe is stationary by default, renders on interaction/resize/texture
completion, supports manual drag, wheel/button zoom, arrow-key rotation and
surface point picking. The selection marker matches the equirectangular texture
coordinate convention. Selection changes do not reorient the camera. No land
mask, country polygon classification, satellite overlays or farm polygon
highlighting is inferred from the texture. Coordinate input and reference
buttons work if WebGL is unavailable.

## Data sources and contracts

| Data | Provider and meaning | Units / time | Important limits |
| --- | --- | --- | --- |
| Current weather | Open-Meteo forecast API, gridded model output | Provider units; provider local valid time and timezone | Not a field-station observation |
| Daily forecast | Open-Meteo, requested up to seven days | °C/°F, mm, probability %, WMO weather code | Forecast, not measured history |
| Soil moisture | Open-Meteo hourly model, 0–7 cm | m³/m³; last returned hour at or before current model time | Not laboratory soil water or whole-field sampling |
| Soil temperature | Open-Meteo hourly model, 0 cm | °C in soil view; hourly valid time shown | Surface model value, not root-zone lab temperature |
| Reference ET₀ | Open-Meteo daily FAO reference evapotranspiration | mm/day; forecast day | Atmospheric demand, not actual crop ET or irrigation supply |
| Place lookup | Open-Meteo geocoding | Named choices and coordinates | Points do not define a farm |
| Basemap | OpenStreetMap standard tiles | Cartographic context; © contributors attribution | No guaranteed satellite, terrain or cadastral layer |
| Soil records | Entered by the user, or explicit demo assumptions | Date, pH, OM %, moisture %, nitrogen mg/kg, optional depth/method/reference | Entered values are unverified; moisture % requires user method clarification |
| Crop references | Supplied illustrative catalog | Seasonal mm, pH bands, costs/yields, heuristic factors | Not calibrated or regionally validated recommendations |

External endpoints:

- `https://api.open-meteo.com/v1/forecast`
- `https://geocoding-api.open-meteo.com/v1/search`
- `https://tile.openstreetmap.org/{z}/{x}/{y}.png`
- Provider reference: `https://open-meteo.com/en/docs`
- Terms: `https://open-meteo.com/en/terms` and `https://open-meteo.com/en/licence`
- Tile policy: `https://operations.osmfoundation.org/policies/tiles/`

Provider model resolution varies with region/model; the app does not claim a
fixed field-scale resolution. Read current provider documentation, licensing,
commercial-use rules and quotas before deployment. Public endpoints are not a
production SLA. Static Blue Marble imagery has no live acquisition timestamp;
it is labeled a supplied Earth texture. The original image provenance remains
in `ASSET-NOTES.md`.

Responses are validated with Zod. Mismatched arrays, invalid required values and
missing units produce errors. Nullable forecast and soil values stay missing,
never zero. Requests have 15-second timeouts and are aborted on selection change;
obsolete results cannot replace the active location. A bounded, in-memory cache
uses a 15-minute freshness window and preserves the original retrieval time.
Cached responses are labeled; failed requests never produce fictional readings.
Place lookup has a 12-second timeout and runs only when submitted. This is not
a claim that source models update every 15 minutes.

## Planning, risk and water calculations

Crop ranking is an exploratory weighted comparison. Weights are normalized by
their total; all-zero weights produce an explanation rather than `NaN`.
Entered field pH changes the illustrative soil factor (90 in range, 30 out of
range); without it the original assumed factor remains explicitly labeled.
An optional seasonal water-budget scenario changes the water factor to
`min(100, budget / illustrative crop water reference × 100)`. Blank means
unknown and zero means no scenario water. Neither rainfall nor efficiency is
inferred. Consecutive same-family crops receive a screening flag and a lower
illustrative diversity factor. This does not predict a yield loss or guarantee
legume nitrogen benefits. Current crop is used as an assumed predecessor if no
previous planned year exists; recorded historical cropping is not connected.
No seven-day forecast is used as a substitute for seasonal climate suitability.

Generic near-term screening flags forecast maxima ≥35 °C, minima ≤0 °C and
precipitation ≥30 mm/day. Criteria, date, units and source are shown. These are
not official warnings, crop-specific predictions or a drought assessment.

Water view keeps current precipitation, daily forecast rainfall and reference
ET₀ distinct. Its scenario difference is **crop reference minus all logged
irrigation**, not a seasonal irrigation balance: records can span different
years and rainfall, efficiency, crop stage and soil storage are unknown. Unknown
rainfall is not entered as zero. Irrigation volume is depth mm × field ha × 10.
Groundwater, reservoir storage and actual water availability are unavailable.
Area preferences convert ha to acres (2.4710538147 ac/ha). Monetary display uses
a fixed 3.75 SAR/USD scenario, not a live exchange-rate feed.

## Persistence, exports and privacy

Data stays in this browser's localStorage. No accounts, authorization, server
sync, private-record encryption, cross-device recovery or cloud backup is
connected. Browser records are schema-checked on reload; invalid originals are
preserved and a warning prevents silently overwriting them. Explicit demo reset
removes records only after confirmation. Storage failures are reported.

Public weather requests transmit selected coordinates to Open-Meteo; submitted
place names go to its geocoder. Tile requests disclose the viewed map region to
OpenStreetMap. Do not use this prototype as a secure private farm-record store.
No private AI keys are stored or sent, and no AI provider is connected.

CSV reports include field identity, selected point, generation time, source
labels and scope limitations. Spreadsheet-formula prefixes are escaped. Soil
sample provenance is included. Print uses the browser's print dialog (and PDF
where that browser supports it); no server PDF service exists. Live
weather/model values are deliberately excluded from the saved-record report.

## Deployment and troubleshooting

Deploy `dist/public` to a static host with SPA fallback to `index.html`, at `/`.
Serve over HTTPS. Production does not need the development Vite overlay or a
PostgreSQL connection. A build output is included in the upgraded archive;
rebuild after source edits. Browsers need outbound access to provider endpoints.

- Network 403: this cloud runtime blocked weather, geocoding and OSM tiles during
  validation. Required domains were saved in the environment draft, preserving
  earlier settings. Review/save settings and publish to activate them, then
  retry actual provider requests. Draft persistence is not runtime activation.
- Blank tiles: a visible error explains the failure; point selection, outlines
  and coordinate controls remain usable. There is no substituted basemap.
- Provider 429: wait and retry; do not increase polling to bypass limits.
- Soil values unavailable: enter real lab results; missing N/P/K or pH is not
  inferred from imagery or weather. No SoilGrids integration is claimed.
- WebGL unavailable: use coordinates, reference places and the 2D map.
- pnpm esbuild policy: `allowBuilds.esbuild: true` fixes an invalid placeholder in
  the supplied workspace config. Package age, checksum and TLS protections
  remain enabled.

## Remaining work

The broad product brief is not fully implemented. NASA/vegetation layers,
SoilGrids and national surveys, real hydrological supply, historical climate
baselines, spatial aggregation over fields, calibrated crop suitability,
planting calendars, authenticated multi-user persistence, lab-file import,
a live AI advisor and production operational/security audits remain separate
work. Arabic translation remains partial. The application is an improved,
tested learning/planning workspace, not a scientifically validated production
intelligence platform. See `UPGRADE-REPORT.md` for exact validation evidence.
