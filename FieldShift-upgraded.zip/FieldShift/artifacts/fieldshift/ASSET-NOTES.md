# Supplied visual assets

Brand, school seal, field and forest photographs and Earth textures were retained from the user-supplied archive. Their original provenance/licensing was not independently verified; review before public distribution. Static Earth imagery is illustrative, not a current observation.

The original README identified local Unsplash images with these source IDs: `photo-1500375592092-40eb2168fd21`, `photo-1534088568595-a066f410bcda`, `photo-1428592953211-077101b2021b`, `photo-1534274988757-a28bf1a57c17`. Existing files remain supplied assets; this upgrade did not download external imagery or assert new licensing rights.

The Water banner now uses the supplied inland-water image instead of an unrelated sea/coast scene. Weather backgrounds are explicitly thematic and model-dependent, not photographs of the selected site.
