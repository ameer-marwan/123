import { useEffect, useRef, useState } from "react";
import {
  fetchEnvironment,
  type EnvironmentData,
} from "../services/environment";
import type { GeoSelection } from "../domain/location";
export function useEnvironment(location: GeoSelection, unit: "C" | "F" = "C") {
  const key = `${location.latitude}/${location.longitude}/${unit}`;
  const [attempt, setAttempt] = useState(0);
  const lastAttempt = useRef(0);
  const [state, setState] = useState<{
    key: string;
    data: EnvironmentData | null;
    error: string;
    loading: boolean;
  }>({ key, data: null, error: "", loading: true });
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setState({ key, data: null, error: "", loading: true });
    const force = lastAttempt.current !== attempt;
    lastAttempt.current = attempt;
    fetchEnvironment(
      location.latitude,
      location.longitude,
      unit,
      controller.signal,
      force,
    )
      .then((data) => {
        if (active) setState({ key, data, error: "", loading: false });
      })
      .catch((e) => {
        if (active)
          setState({
            key,
            data: null,
            error:
              e instanceof Error
                ? e.message
                : "Environmental data unavailable.",
            loading: false,
          });
      });
    const timer = setTimeout(() => setAttempt((v) => v + 1), 15 * 60 * 1000);
    return () => {
      active = false;
      controller.abort();
      clearTimeout(timer);
    };
  }, [key, attempt]);
  return {
    ...(state.key === key
      ? state
      : { key, data: null, error: "", loading: true }),
    refresh: () => setAttempt((v) => v + 1),
  };
}
