import { z } from "zod";
import { validCoordinates } from "../domain/location.ts";
const num = z.number().finite();
const list = z.array(num.nullable());
export const environmentSchema = z
  .object({
    latitude: num,
    longitude: num,
    timezone: z.string().min(1),
    current: z.object({
      time: z.string().min(10),
      temperature_2m: num,
      relative_humidity_2m: num,
      precipitation: num,
      wind_speed_10m: num,
      weather_code: num,
    }),
    current_units: z.record(z.string()),
    daily_units: z.record(z.string()),
    daily: z.object({
      time: z.array(z.string()).min(1),
      temperature_2m_max: list,
      temperature_2m_min: list,
      precipitation_probability_max: list,
      precipitation_sum: list,
      weather_code: list,
      et0_fao_evapotranspiration: list,
    }),
    hourly: z.object({
      time: z.array(z.string()),
      soil_moisture_0_to_7cm: list,
      soil_temperature_0cm: list,
    }),
  })
  .superRefine((v, ctx) => {
    for (const [k, a] of Object.entries(v.daily))
      if (a.length !== v.daily.time.length)
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Daily array length mismatch: ${k}`,
        });
    for (const [k, a] of Object.entries(v.hourly))
      if (a.length !== v.hourly.time.length)
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Hourly array length mismatch: ${k}`,
        });
    for (const key of [
      "temperature_2m",
      "relative_humidity_2m",
      "precipitation",
      "wind_speed_10m",
    ])
      if (!v.current_units[key])
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Missing units: ${key}`,
        });
    for (const key of [
      "temperature_2m_max",
      "temperature_2m_min",
      "precipitation_sum",
      "precipitation_probability_max",
    ])
      if (!v.daily_units[key])
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Missing daily units: ${key}`,
        });
  });
export type EnvironmentData = z.infer<typeof environmentSchema> & {
  retrievedAt: string;
  cached: boolean;
  soilTime: string | null;
  soilMoisture: number | null;
  soilTemperature: number | null;
};
const cache = new Map<string, EnvironmentData>();
export function environmentUrl(
  lat: number,
  lon: number,
  unit: "C" | "F" = "C",
): string {
  if (!validCoordinates(lat, lon))
    throw new Error("Invalid environmental coordinates.");
  const q = new URLSearchParams({
    latitude: String(lat),
    longitude: String(lon),
    current:
      "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code",
    hourly: "soil_moisture_0_to_7cm,soil_temperature_0cm",
    daily:
      "temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,weather_code,et0_fao_evapotranspiration",
    forecast_days: "7",
    temperature_unit: unit === "F" ? "fahrenheit" : "celsius",
    timezone: "auto",
  });
  return `https://api.open-meteo.com/v1/forecast?${q}`;
}
export async function fetchEnvironment(
  lat: number,
  lon: number,
  unit: "C" | "F",
  signal: AbortSignal,
  force = false,
  fetcher: typeof fetch = fetch,
): Promise<EnvironmentData> {
  const url = environmentUrl(lat, lon, unit),
    old = cache.get(url);
  if (
    !force &&
    old &&
    Date.now() - Date.parse(old.retrievedAt) < 15 * 60 * 1000
  )
    return { ...old, cached: true };
  const timeout = AbortSignal.timeout(15000);
  const response = await fetcher(url, {
    signal: AbortSignal.any([signal, timeout]),
  });
  if (!response.ok)
    throw new Error(
      response.status === 429
        ? "Provider rate limit reached. Wait before retrying."
        : `Environmental provider returned HTTP ${response.status}.`,
    );
  const parsed = environmentSchema.safeParse(await response.json());
  if (!parsed.success)
    throw new Error(
      "Provider returned incomplete or invalid environmental data. No estimates substituted.",
    );
  const raw = parsed.data;
  let i = -1;
  for (let j = 0; j < raw.hourly.time.length; j++)
    if (raw.hourly.time[j] <= raw.current.time) i = j;
  const data: EnvironmentData = {
    ...raw,
    retrievedAt: new Date().toISOString(),
    cached: false,
    soilTime: i < 0 ? null : raw.hourly.time[i],
    soilMoisture: i < 0 ? null : raw.hourly.soil_moisture_0_to_7cm[i],
    soilTemperature: i < 0 ? null : raw.hourly.soil_temperature_0cm[i],
  };
  if (cache.size >= 60) cache.delete(cache.keys().next().value!);
  cache.set(url, data);
  return data;
}
