import { z } from "zod";

export const soilMeasurementKeys = [
  "ph",
  "organicMatterPct",
  "moisturePct",
  "nitrogenMgKg",
] as const;
export const sampleDateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD.")
  .refine((value) => {
    const date = new Date(`${value}T00:00:00Z`);
    return (
      Number.isFinite(date.getTime()) &&
      date.toISOString().slice(0, 10) === value
    );
  }, "Invalid calendar date.")
  .refine(
    (value) => value <= new Date().toISOString().slice(0, 10),
    "Sample date cannot be in the future.",
  );

export const soilObservationSchema = z
  .object({
    id: z.string().min(1).max(200),
    fieldId: z.string().min(1).max(200),
    date: sampleDateSchema,
    ph: z.number().finite().min(0).max(14).nullable(),
    organicMatterPct: z.number().finite().min(0).max(100).nullable(),
    moisturePct: z.number().finite().min(0).max(100).nullable(),
    nitrogenMgKg: z.number().finite().min(0).nullable(),
    source: z.string().max(200),
    notes: z.string().max(4000),
    samplingDepthCm: z.number().finite().min(0).max(300).optional(),
    method: z.string().max(200).optional(),
    reference: z.string().max(300).optional(),
    inputMethod: z.enum(["manual", "csv"]).optional(),
    importFile: z.string().max(200).optional(),
  })
  .superRefine((value, ctx) => {
    if (!soilMeasurementKeys.some((key) => value[key] !== null))
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "Enter at least one measured property. Blank values stay unavailable.",
      });
  });
export type SoilObservation = z.infer<typeof soilObservationSchema>;

export function optionalMeasurement(text: string): number | null {
  const trimmed = text.trim();
  if (trimmed === "") return null;
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(trimmed))
    throw new Error(
      "Use decimal numbers with a dot; no embedded units or thousands separators.",
    );
  const number = Number(trimmed);
  if (!Number.isFinite(number))
    throw new Error("Measurements must be finite numbers.");
  return number;
}

export function soilFingerprint(row: SoilObservation): string {
  return JSON.stringify([
    row.fieldId,
    row.date,
    ...soilMeasurementKeys.map((k) => row[k]),
    row.samplingDepthCm ?? null,
    row.method?.trim() ?? "",
    row.reference?.trim() ?? "",
    row.notes.trim(),
  ]);
}

// A bounded RFC-4180-style parser. No spreadsheet evaluation, HTML parsing or uploads.
function parseCsv(text: string): string[][] {
  if (new TextEncoder().encode(text).byteLength > 1024 * 1024)
    throw new Error("CSV must be no larger than 1 MiB.");
  const input = text.replace(/^\uFEFF/, "");
  const rows: string[][] = [];
  let row: string[] = [],
    cell = "",
    quoted = false,
    closed = false;
  const finishCell = () => {
    row.push(cell);
    cell = "";
    closed = false;
  };
  const finishRow = () => {
    finishCell();
    if (row.some((v) => v.trim() !== "")) rows.push(row);
    row = [];
    if (rows.length > 501)
      throw new Error("Import at most 500 records at once.");
  };
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    if (quoted) {
      if (char === '"') {
        if (input[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          quoted = false;
          closed = true;
        }
      } else cell += char;
    } else if (closed) {
      if (char === ",") finishCell();
      else if (char === "\r" || char === "\n") {
        if (char === "\r" && input[i + 1] === "\n") i++;
        finishRow();
      } else if (char !== " " && char !== "\t")
        throw new Error("Unexpected text after a quoted CSV value.");
    } else if (char === '"') {
      if (cell !== "")
        throw new Error("Quotes must enclose a whole CSV value.");
      quoted = true;
    } else if (char === ",") finishCell();
    else if (char === "\r" || char === "\n") {
      if (char === "\r" && input[i + 1] === "\n") i++;
      finishRow();
    } else cell += char;
  }
  if (quoted) throw new Error("A CSV quoted value was not closed.");
  if (cell !== "" || row.length || closed) finishRow();
  return rows;
}

export const soilCsvHeaders = [
  "sample_date",
  "ph",
  "organic_matter_pct",
  "moisture_pct",
  "nitrogen_mg_kg",
  "sampling_depth_cm",
  "method",
  "reference",
  "notes",
] as const;
export const soilCsvTemplate = soilCsvHeaders.join(",") + "\r\n";
export type SoilImportPreview = {
  rows: SoilObservation[];
  duplicates: number;
  total: number;
  errors: string[];
};

export function previewSoilCsv(
  text: string,
  fieldId: string,
  fileName: string,
  existing: SoilObservation[],
): SoilImportPreview {
  const fail = (message: string): SoilImportPreview => ({
    rows: [],
    duplicates: 0,
    total: 0,
    errors: [message],
  });
  let table: string[][];
  try {
    table = parseCsv(text);
  } catch (e) {
    return fail(e instanceof Error ? e.message : "Unable to read CSV.");
  }
  if (table.length < 2)
    return fail("CSV needs a header and at least one sample row.");
  const headers = table[0].map((s) => s.trim().toLowerCase());
  if (new Set(headers).size !== headers.length)
    return fail("CSV contains duplicate column names.");
  const unknown = headers.filter(
    (h) => !soilCsvHeaders.includes(h as (typeof soilCsvHeaders)[number]),
  );
  if (unknown.length)
    return fail(
      `Unsupported columns: ${unknown.join(", ")}. Use the template; units are part of column names. Soil organic carbon cannot be imported as organic matter.`,
    );
  if (!headers.includes("sample_date")) return fail("sample_date is required.");
  if (
    !["ph", "organic_matter_pct", "moisture_pct", "nitrogen_mg_kg"].some((h) =>
      headers.includes(h),
    )
  )
    return fail("Include at least one measurement column.");
  const errors: string[] = [],
    rows: SoilObservation[] = [];
  let duplicates = 0;
  const known = new Set(existing.map(soilFingerprint));
  for (let i = 1; i < table.length; i++) {
    if (table[i].length !== headers.length) {
      errors.push(`Row ${i + 1}: column count does not match the header.`);
      continue;
    }
    const data = Object.fromEntries(
      headers.map((h, j) => [h, table[i][j].trim()]),
    );
    try {
      const depth = optionalMeasurement(data.sampling_depth_cm ?? "");
      const candidate = {
        id: crypto.randomUUID(),
        fieldId,
        date: data.sample_date,
        ph: optionalMeasurement(data.ph ?? ""),
        organicMatterPct: optionalMeasurement(data.organic_matter_pct ?? ""),
        moisturePct: optionalMeasurement(data.moisture_pct ?? ""),
        nitrogenMgKg: optionalMeasurement(data.nitrogen_mg_kg ?? ""),
        ...(depth === null ? {} : { samplingDepthCm: depth }),
        method: data.method ?? "",
        reference: data.reference ?? "",
        notes: data.notes ?? "",
        source: "Entered",
        inputMethod: "csv" as const,
        importFile: fileName.slice(0, 200),
      };
      const result = soilObservationSchema.safeParse(candidate);
      if (!result.success) {
        errors.push(
          `Row ${i + 1}: ${result.error.issues.map((e) => `${e.path.join(".") || "sample"}: ${e.message}`).join("; ")}`,
        );
        continue;
      }
      const fingerprint = soilFingerprint(result.data);
      if (known.has(fingerprint)) {
        duplicates++;
        continue;
      }
      known.add(fingerprint);
      rows.push(result.data);
    } catch (e) {
      errors.push(
        `Row ${i + 1}: ${e instanceof Error ? e.message : "Invalid value."}`,
      );
    }
  }
  // Atomic import: one invalid row prevents every row from being committed.
  return {
    rows: errors.length ? [] : rows,
    duplicates,
    total: table.length - 1,
    errors,
  };
}
