export type GeoSelection = {
  latitude: number;
  longitude: number;
  label: string;
  method?: "map" | "globe" | "search" | "coordinates" | "field" | "reset";
  selectedAt?: string;
  fieldId?: string;
};
export const validCoordinates = (lat: unknown, lon: unknown): boolean =>
  typeof lat === "number" &&
  typeof lon === "number" &&
  Number.isFinite(lat) &&
  Number.isFinite(lon) &&
  Math.abs(lat) <= 90 &&
  Math.abs(lon) <= 180;
export function selection(
  latitude: number,
  longitude: number,
  label: string,
  method: GeoSelection["method"],
  fieldId?: string,
): GeoSelection {
  if (!validCoordinates(latitude, longitude))
    throw new Error("Latitude must be −90…90 and longitude −180…180.");
  return {
    latitude,
    longitude,
    label: label.trim().slice(0, 200) || "Selected point",
    method,
    selectedAt: new Date().toISOString(),
    ...(fieldId ? { fieldId } : {}),
  };
}
export function parseCoordinates(text: string): [number, number] | null {
  const match = text
    .trim()
    .match(/^(-?\d+(?:\.\d+)?)\s*[,;]\s*(-?\d+(?:\.\d+)?)$/);
  if (!match) return null;
  const lat = Number(match[1]),
    lon = Number(match[2]);
  if (!validCoordinates(lat, lon))
    throw new Error(
      "Coordinates are outside the valid latitude/longitude range.",
    );
  return [lat, lon];
}
export function surfaceCoordinates(
  x: number,
  y: number,
  z: number,
): [number, number] {
  const radius = Math.hypot(x, y, z);
  return [
    (Math.asin(Math.max(-1, Math.min(1, y / radius))) * 180) / Math.PI,
    (Math.atan2(-z, x) * 180) / Math.PI,
  ];
}
export function surfacePoint(
  lat: number,
  lon: number,
  radius = 1,
): [number, number, number] {
  const a = (lat * Math.PI) / 180,
    b = (lon * Math.PI) / 180;
  return [
    radius * Math.cos(a) * Math.cos(b),
    radius * Math.sin(a),
    -radius * Math.cos(a) * Math.sin(b),
  ];
}
export function fieldCenter(
  boundary?: [number, number][],
): [number, number] | null {
  if (!boundary?.length) return null;
  const lon =
    (Math.atan2(
      boundary.reduce((s, p) => s + Math.sin((p[1] * Math.PI) / 180), 0),
      boundary.reduce((s, p) => s + Math.cos((p[1] * Math.PI) / 180), 0),
    ) *
      180) /
    Math.PI;
  return [boundary.reduce((s, p) => s + p[0], 0) / boundary.length, lon];
}
const wrap = (n: number) => ((n + 540) % 360) - 180;
export function polygonAreaHa(points: [number, number][]): number {
  if (points.length < 3) return 0;
  const rad = Math.PI / 180;
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i],
      b = points[(i + 1) % points.length];
    sum +=
      wrap(b[1] - a[1]) *
      rad *
      (2 + Math.sin(a[0] * rad) + Math.sin(b[0] * rad));
  }
  return (Math.abs(sum) * 6371008.8 ** 2) / 2 / 10000;
}
export function validatePolygon(points: [number, number][]): string | null {
  if (points.length < 3 || points.length > 500)
    return "Use between 3 and 500 vertices.";
  if (points.some((p) => !validCoordinates(p[0], p[1])))
    return "Invalid boundary coordinates.";
  if (new Set(points.map((p) => p.join(","))).size !== points.length)
    return "Remove duplicate vertices.";
  if (
    points.some(
      (p, i) => Math.abs(p[1] - points[(i + 1) % points.length][1]) > 180,
    )
  )
    return "Split boundaries crossing the date line before importing.";
  const cross = (a: number[], b: number[], c: number[]) =>
    (b[1] - a[1]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[1] - a[1]);
  const between = (a: number[], b: number[], c: number[]) =>
    c[0] >= Math.min(a[0], b[0]) &&
    c[0] <= Math.max(a[0], b[0]) &&
    c[1] >= Math.min(a[1], b[1]) &&
    c[1] <= Math.max(a[1], b[1]);
  for (let i = 0; i < points.length; i++)
    for (let j = i + 1; j < points.length; j++) {
      if (j === i + 1 || (i === 0 && j === points.length - 1)) continue;
      const a = points[i],
        b = points[(i + 1) % points.length],
        c = points[j],
        d = points[(j + 1) % points.length];
      const u = cross(a, b, c),
        v = cross(a, b, d),
        w = cross(c, d, a),
        t = cross(c, d, b);
      if (
        (u * v < 0 && w * t < 0) ||
        (u === 0 && between(a, b, c)) ||
        (v === 0 && between(a, b, d)) ||
        (w === 0 && between(c, d, a)) ||
        (t === 0 && between(c, d, b))
      )
        return "Boundary edges intersect. Draw a simple outline.";
    }
  const area = polygonAreaHa(points);
  if (area < 0.001 || area > 100000)
    return "Boundary must cover 0.001–100,000 hectares; use field-scale outlines.";
  return null;
}
