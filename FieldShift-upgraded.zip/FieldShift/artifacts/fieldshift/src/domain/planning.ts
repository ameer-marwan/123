export type PlanningCrop = {
  id: string;
  name: string;
  category: string;
  phMin: number;
  phMax: number;
  waterNeedMm: number;
  soilScore: number;
  waterScore: number;
  diversityScore: number;
  riskScore: number;
};
export type Priorities = {
  soil: number;
  water: number;
  diversity: number;
  risk: number;
};
const families: Record<string, string> = {
  wheat: "Poaceae",
  barley: "Poaceae",
  sorghum: "Poaceae",
  alfalfa: "Fabaceae",
  chickpea: "Fabaceae",
  tomato: "Solanaceae",
};
export function cropFamily(id: string) {
  return families[id] ?? "Unknown family";
}
export function rotationWarnings(
  seasons: { year: number; cropId: string }[],
): string[] {
  const sorted = [...seasons].sort((a, b) => a.year - b.year),
    warnings: string[] = [];
  for (let i = 1; i < sorted.length; i++) {
    const a = sorted[i - 1],
      b = sorted[i];
    if (b.year === a.year)
      warnings.push(`${b.year}: more than one crop assigned to a yearly slot.`);
    if (
      b.year === a.year + 1 &&
      cropFamily(a.cropId) !== "Unknown family" &&
      cropFamily(a.cropId) === cropFamily(b.cropId)
    )
      warnings.push(
        `${a.year}–${b.year}: consecutive ${cropFamily(b.cropId)} crops. Review local pest and disease guidance; shared family is a screening flag, not a predicted loss.`,
      );
  }
  return warnings;
}
export function rankCrops<T extends PlanningCrop>(
  crops: T[],
  weights: Priorities,
  context: {
    ph: number | null;
    waterBudgetMm: number | null;
    previousCropId?: string;
  },
) {
  if (Object.values(weights).some((v) => !Number.isFinite(v) || v < 0))
    throw new Error("Priorities must be nonnegative finite numbers.");
  const total = Object.values(weights).reduce((a, b) => a + b, 0);
  if (!total) return [];
  return crops
    .map((c) => {
      const phKnown = context.ph !== null && Number.isFinite(context.ph),
        waterKnown =
          context.waterBudgetMm !== null &&
          Number.isFinite(context.waterBudgetMm);
      const within =
        phKnown && context.ph! >= c.phMin && context.ph! <= c.phMax;
      const soilScore = phKnown ? (within ? 90 : 30) : c.soilScore;
      const waterScore = waterKnown
        ? Math.min(
            100,
            Math.max(0, (context.waterBudgetMm! / c.waterNeedMm) * 100),
          )
        : c.waterScore;
      const repeated =
        !!context.previousCropId &&
        cropFamily(context.previousCropId) === cropFamily(c.id);
      const diversityScore = repeated ? 35 : c.diversityScore;
      const reasons = [
        phKnown
          ? `Entered soil pH ${context.ph} is ${within ? "inside" : "outside"} the illustrative ${c.phMin}–${c.phMax} range.`
          : "No entered pH linked to the selected point; soil factor uses demo assumptions.",
        waterKnown
          ? `Your ${context.waterBudgetMm} mm seasonal scenario covers ${((context.waterBudgetMm! / c.waterNeedMm) * 100).toFixed(0)}% of the ${c.waterNeedMm} mm illustrative reference; no rainfall or efficiency inferred.`
          : "No water budget supplied; water factor uses demo assumptions.",
        repeated
          ? `Same crop family (${cropFamily(c.id)}) as the previous crop. Review rotation risks.`
          : "Family diversity alone does not establish pest control or nutrient sufficiency.",
        "No regional planting calendar, salinity, cultivar or long-term climate screening is connected. This score is an exploratory comparison, not a validated suitability probability.",
      ];
      return {
        ...c,
        soilScore,
        waterScore,
        diversityScore,
        score:
          (soilScore * weights.soil +
            waterScore * weights.water +
            diversityScore * weights.diversity +
            c.riskScore * weights.risk) /
          total,
        reasons,
        evidence: phKnown
          ? "Entered pH + illustrative assumptions"
          : "Illustrative assumptions; insufficient local evidence",
      };
    })
    .sort((a, b) => b.score - a.score);
}
