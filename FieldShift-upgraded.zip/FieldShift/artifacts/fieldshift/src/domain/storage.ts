import { z } from "zod";
const id = z.string().min(1).max(200),
  number = z.number().finite();
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const field = z.object({
  id,
  farmId: id,
  name: z.string().min(1).max(200),
  areaHectares: number.positive(),
  cropId: id,
  boundary: z
    .array(z.tuple([number.min(-90).max(90), number.min(-180).max(180)]))
    .min(3)
    .max(500)
    .optional(),
});
const soil = z.object({
  id,
  fieldId: id,
  date,
  ph: number.min(0).max(14),
  organicMatterPct: number.min(0).max(100),
  moisturePct: number.min(0).max(100),
  nitrogenMgKg: number.min(0),
  source: z.string(),
  notes: z.string(),
  samplingDepthCm: number.nonnegative().optional(),
  method: z.string().optional(),
  reference: z.string().optional(),
});
const irrigation = z.object({
  id,
  fieldId: id,
  date,
  depthMm: number.positive(),
  volumeM3: number.nonnegative(),
  method: z.string(),
  notes: z.string(),
});
export const savedStoreSchema = z
  .object({
    fields: z.array(field).min(1).max(1000),
    soils: z.array(soil),
    irrigation: z.array(irrigation),
    plans: z.array(
      z.object({
        id,
        fieldId: id,
        name: z.string(),
        seasons: z.array(
          z.object({ year: z.number().int().min(1900).max(2200), cropId: id }),
        ),
      }),
    ),
    settings: z.object({
      theme: z.enum(["dark", "light"]),
      language: z.enum(["en", "ar"]),
      areaUnit: z.enum(["ha", "ac"]),
      temperatureUnit: z.enum(["C", "F"]),
      waterUnit: z.enum(["mm", "m3"]),
      currency: z.enum(["SAR", "USD"]),
    }),
    selectedFarm: id,
    selectedField: id,
    selectedLocation: z.object({
      latitude: number.min(-90).max(90),
      longitude: number.min(-180).max(180),
      label: z.string().max(200),
      method: z
        .enum(["map", "globe", "search", "coordinates", "field", "reset"])
        .optional(),
      selectedAt: z.string().optional(),
      fieldId: z.string().optional(),
    }),
  })
  .superRefine((s, ctx) => {
    const ids = new Set(s.fields.map((f) => f.id));
    if (
      ids.size !== s.fields.length ||
      !ids.has(s.selectedField) ||
      [...s.soils, ...s.irrigation, ...s.plans].some((r) => !ids.has(r.fieldId))
    )
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Field relationships are invalid.",
      });
  });
export function csvCell(value: string): string {
  const safe = /^[\s]*[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return `"${safe.replaceAll('"', '""')}"`;
}
