export type WeatherScene =
  "sunny" | "cloudy" | "rain" | "storm" | "snow" | "fog";
export function weatherScene(code: number | undefined): WeatherScene {
  if (code === 0 || code === 1) return "sunny";
  if (code === 45 || code === 48) return "fog";
  if ([95, 96, 99].includes(code ?? -1)) return "storm";
  if ([71, 73, 75, 77, 85, 86].includes(code ?? -1)) return "snow";
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code ?? -1))
    return "rain";
  return "cloudy";
}
export function weatherScenePhoto(code: number | undefined): string {
  return {
    sunny: "/images/agricultural_field.jpg",
    cloudy: "/images/weather-clouds.jpg",
    rain: "/images/weather-rain.jpg",
    storm: "/images/weather-storm.jpg",
    snow: "/images/weather-cold-ice.jpg",
    fog: "/images/weather-clouds.jpg",
  }[weatherScene(code)];
}
