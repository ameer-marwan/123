export function forecastScreening(daily: {
  time: string[];
  temperature_2m_max: (number | null)[];
  temperature_2m_min: (number | null)[];
  precipitation_sum: (number | null)[];
}) {
  return daily.time.flatMap((date, i) => {
    const rows: {
      date: string;
      label: string;
      evidence: string;
      action: string;
    }[] = [];
    const high = daily.temperature_2m_max[i],
      low = daily.temperature_2m_min[i],
      rain = daily.precipitation_sum[i];
    if (high !== null && high !== undefined && high >= 35)
      rows.push({
        date,
        label: "Heat screening flag",
        evidence: `Forecast maximum ${high} °C ≥ 35 °C.`,
        action:
          "Check crop stage, local guidance and available irrigation. Crop tolerances vary.",
      });
    if (low !== null && low !== undefined && low <= 0)
      rows.push({
        date,
        label: "Frost screening flag",
        evidence: `Forecast minimum ${low} °C ≤ 0 °C.`,
        action:
          "Inspect crop-specific frost sensitivity and consult local forecasts.",
      });
    if (rain !== null && rain !== undefined && rain >= 30)
      rows.push({
        date,
        label: "Heavy-rain screening flag",
        evidence: `Forecast daily precipitation ${rain} mm ≥ 30 mm.`,
        action:
          "Check drainage and soil trafficability locally; runoff is not predicted here.",
      });
    return rows;
  });
}
