import { useEffect, useRef, useState } from "react";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import "./FieldShiftOnboarding.css";
export default function FieldShiftOnboarding({
  onComplete,
}: {
  onComplete: () => void;
}) {
  const [step, setStep] = useState<1 | 2>(1);
  const enter = useRef<HTMLButtonElement>(null);
  const [leaving, setLeaving] = useState(false);
  const exiting = useRef(false);
  const exitTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
      if (exitTimer.current !== null) clearTimeout(exitTimer.current);
    };
  }, []);
  const openWorkspace = () => {
    if (exiting.current) return;
    exiting.current = true;
    setLeaving(true);
    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    exitTimer.current = setTimeout(onComplete, reduced ? 0 : 560);
  };
  useEffect(() => {
    if (step === 2) enter.current?.focus({ preventScroll: true });
  }, [step]);
  return (
    <main
      className={`fs-onboarding fs-onboarding--${step === 1 ? "land" : "identity"}${leaving ? " fs-onboarding--leaving" : ""}`}
      aria-busy={leaving}
    >
      <img
        className="fs-intro-landscape"
        src="/images/agricultural_field.jpg"
        alt=""
        fetchPriority="high"
      />
      <div className="fs-intro-veil" />
      <div className="fs-intro-grain" />
      <div className="fs-intro-sunbeam" />
      <div className="fs-intro-orbit fs-intro-orbit-one" />
      <div className="fs-intro-orbit fs-intro-orbit-two" />
      {Array.from({ length: 12 }, (_, i) => (
        <i
          key={i}
          className="fs-intro-pollen"
          style={{
            left: `${9 + i * 7}%`,
            animationDelay: `${i * -0.8}s`,
            animationDuration: `${6 + (i % 4)}s`,
          }}
        />
      ))}
      {step === 1 ? (
        <button
          type="button"
          className="fs-discover-scene"
          data-testid="button-onboarding-continue"
          aria-label="Reveal the FieldShift logo"
          onClick={() => setStep(2)}
        >
          <span className="fs-intro-topline">
            A NEW PERSPECTIVE ON YOUR LAND
          </span>
          <span className="fs-discover-copy">
            <span className="fs-intro-kicker">ROOTED IN POSSIBILITY</span>
            <strong>
              Every field.
              <br />
              <em>A new beginning.</em>
            </strong>
            <span className="fs-intro-caption">
              Discover what your land can become.
            </span>
            <span className="fs-intro-prompt">
              Tap anywhere to discover <ArrowUpRight size={20} />
            </span>
          </span>
          <span className="fs-intro-bottom">
            <span>EARTH · WATER · POSSIBILITY</span>
            <span>01 / DISCOVER</span>
          </span>
        </button>
      ) : (
        <button
          ref={enter}
          type="button"
          className="fs-identity-scene"
          data-testid="button-enter-fieldshift"
          aria-label="Enter FieldShift"
          onClick={openWorkspace}
          disabled={leaving}
        >
          <span className="fs-intro-topline">
            WELCOME TO YOUR FIELD INTELLIGENCE WORKSPACE
          </span>
          <span className="fs-identity-content">
            <span className="fs-emblem-halo">
              <img
                src="/images/fieldshift-emblem.png"
                alt="FieldShift leaf, fields, water and sun emblem"
                className="fs-new-emblem"
                data-testid="image-fieldshift-logo"
              />
            </span>
            <span className="fs-identity-wordmark">
              field<span>shift</span>
            </span>
            <span className="fs-identity-tagline">
              A clearer view of your land.
            </span>
            <span className="fs-enter-pill">
              Enter your workspace <ArrowRight size={19} />
            </span>
            <span className="fs-identity-subtext">Tap anywhere to begin</span>
          </span>
          <span className="fs-intro-bottom">
            <span>GROW WITH UNDERSTANDING</span>
            <span>02 / BEGIN</span>
          </span>
        </button>
      )}
    </main>
  );
}
