import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import './FieldShiftOnboarding.css';

type FieldShiftOnboardingProps = {
  onComplete: () => void;
};

export function FieldShiftOnboarding({ onComplete }: FieldShiftOnboardingProps) {
  const [step, setStep] = useState<1 | 2>(1);

  if (step === 1) {
    return (
      <main className="fs-onboarding fs-onboarding--photo" data-testid="onboarding-intro">
        <button
          type="button"
          className="fs-photo-step"
          onClick={() => setStep(2)}
          aria-label="Continue to learn about FieldShift"
          data-testid="button-onboarding-continue"
        >
          <img
            className="fs-seedling-photo"
            src="/images/fieldshift-seedlings.jpg"
            alt="Young seedlings growing in individual soil cells"
            fetchPriority="high"
          />
          <span className="fs-photo-shade" aria-hidden="true" />
          <span className="fs-photo-caption">
            <span className="fs-step-label" data-testid="text-onboarding-step">A workspace for the work ahead</span>
            <span className="fs-photo-prompt">
              Tap to begin <ArrowRight size={18} aria-hidden="true" />
            </span>
          </span>
        </button>
        <span className="fs-photo-index bg-input text-[1px]" aria-hidden="true">01 <i /> 02</span>
      </main>
    );
  }

  return (
    <main className="fs-onboarding fs-onboarding--welcome" data-testid="onboarding-welcome">
      <div className="fs-welcome-photo" aria-hidden="true">
        <img
          className="fs-seedling-photo"
          src="/images/fieldshift-seedlings.jpg"
          alt=""
        />
        <span className="fs-photo-shade" />
        <span className="fs-image-note">FIELD NOTES · BEGIN WITH THE GROWING</span>
      </div>
      <section className="fs-welcome-panel" aria-labelledby="fs-welcome-title">
        <div className="fs-welcome-content">
          <span className="fs-step-label">A clearer view of your fields</span>
          <button
            type="button"
            className="fs-brand-button"
            onClick={onComplete}
            aria-label="Open FieldShift home"
            data-testid="button-fieldshift-logo-home"
          >
            <img
              className="fs-brand-logo"
              src="/images/fieldshift-full-logo.png"
              alt="FieldShift"
              data-testid="image-fieldshift-logo"
            />
          </button>
          <h1 id="fs-welcome-title" data-testid="text-onboarding-description">
            Learn your land. Plan your next shift.
          </h1>
          <p>
            FieldShift brings agricultural learning and field planning into one
            practical workspace.
          </p>
          <button
            type="button"
            className="fs-enter-button"
            onClick={onComplete}
            data-testid="button-enter-fieldshift"
          >
            Enter FieldShift <ArrowRight size={18} aria-hidden="true" />
          </button>
        </div>
        <span className="fs-welcome-index" aria-hidden="true">02 <i /> 02</span>
      </section>
    </main>
  );
}

export default FieldShiftOnboarding;
