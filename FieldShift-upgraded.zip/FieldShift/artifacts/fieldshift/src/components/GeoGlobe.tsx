import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import {
  selection,
  surfaceCoordinates,
  surfacePoint,
  type GeoSelection,
} from "../domain/location";
const places = [
  { name: "Al Kharj", lat: 24.1558, lon: 47.312 },
  { name: "Nairobi", lat: -1.2921, lon: 36.8219 },
  { name: "Iowa Corn Belt", lat: 41.878, lon: -93.0977 },
];
export default function GeoGlobe({
  location,
  onSelect,
}: {
  location: GeoSelection;
  onSelect: (loc: GeoSelection) => void;
}) {
  const host = useRef<HTMLDivElement>(null),
    api = useRef<{
      zoom: (delta: number) => void;
      select: (loc: GeoSelection) => void;
    } | null>(null);
  const current = useRef(location),
    select = useRef(onSelect);
  current.current = location;
  select.current = onSelect;
  const [error, setError] = useState(""),
    [textureError, setTextureError] = useState(false);
  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      setError(
        "WebGL is unavailable. Select coordinates or a reference place below, or use the 2D map.",
      );
      return;
    }
    const scene = new THREE.Scene(),
      camera = new THREE.PerspectiveCamera(42, 1, 0.1, 30);
    camera.position.z = 4.2;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const canvas = renderer.domElement;
    canvas.style.touchAction = "none";
    canvas.tabIndex = 0;
    canvas.setAttribute(
      "aria-label",
      "Earth globe. Drag to rotate; click to select a point. Arrow keys rotate; plus and minus zoom.",
    );
    canvas.setAttribute("role", "application");
    element.appendChild(canvas);
    const root = new THREE.Group();
    scene.add(root);
    root.rotation.y =
      -Math.PI / 2 - (current.current.longitude * Math.PI) / 180;
    root.rotation.x = (current.current.latitude * Math.PI) / 180;
    const geometry = new THREE.SphereGeometry(1.34, 64, 48),
      material = new THREE.MeshPhongMaterial({ color: 0x497769, shininess: 8 });
    const earth = new THREE.Mesh(geometry, material);
    root.add(earth);
    scene.add(new THREE.AmbientLight(0xffffff, 2));
    const light = new THREE.DirectionalLight(0xffffff, 1.8);
    light.position.set(-2, 3, 4);
    scene.add(light);
    const marker = new THREE.Mesh(
      new THREE.SphereGeometry(0.026, 14, 12),
      new THREE.MeshBasicMaterial({ color: 0xc5f36b }),
    );
    root.add(marker);
    let disposed = false,
      frame = 0;
    const render = () => {
      if (disposed || frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        if (!disposed) renderer.render(scene, camera);
      });
    };
    const mark = (loc: GeoSelection) => {
      marker.position.set(...surfacePoint(loc.latitude, loc.longitude, 1.365));
      render();
    };
    mark(current.current);
    const texture = new THREE.TextureLoader().load(
      "/textures/earth_blue_marble.jpg",
      (t) => {
        if (disposed) {
          t.dispose();
          return;
        }
        t.colorSpace = THREE.SRGBColorSpace;
        material.map = t;
        material.color.set(0xffffff);
        material.needsUpdate = true;
        render();
      },
      undefined,
      () => {
        if (!disposed) setTextureError(true);
      },
    );
    const zoom = (delta: number) => {
      camera.position.z = THREE.MathUtils.clamp(
        camera.position.z + delta,
        2.1,
        6,
      );
      render();
    };
    api.current = { zoom, select: mark };
    let down = false,
      lastX = 0,
      lastY = 0,
      distance = 0;
    const start = (e: PointerEvent) => {
      down = true;
      distance = 0;
      lastX = e.clientX;
      lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!down) return;
      const dx = e.clientX - lastX,
        dy = e.clientY - lastY;
      distance += Math.abs(dx) + Math.abs(dy);
      root.rotation.y += dx * 0.006;
      root.rotation.x = THREE.MathUtils.clamp(
        root.rotation.x + dy * 0.006,
        -Math.PI / 2,
        Math.PI / 2,
      );
      lastX = e.clientX;
      lastY = e.clientY;
      render();
    };
    const end = (e: PointerEvent) => {
      if (!down) return;
      down = false;
      if (distance > 7) return;
      const rect = canvas.getBoundingClientRect(),
        ray = new THREE.Raycaster();
      ray.setFromCamera(
        new THREE.Vector2(
          (2 * (e.clientX - rect.left)) / rect.width - 1,
          1 - (2 * (e.clientY - rect.top)) / rect.height,
        ),
        camera,
      );
      root.updateMatrixWorld(true);
      const hit = ray.intersectObject(earth)[0];
      if (hit) {
        const local = earth.worldToLocal(hit.point.clone());
        const [lat, lon] = surfaceCoordinates(local.x, local.y, local.z);
        select.current(
          selection(
            lat,
            lon,
            `Globe point ${lat.toFixed(4)}, ${lon.toFixed(4)}`,
            "globe",
          ),
        );
      }
    };
    const cancel = () => {
      down = false;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      zoom(Math.sign(e.deltaY) * 0.15);
    };
    const key = (e: KeyboardEvent) => {
      if (
        [
          "ArrowLeft",
          "ArrowRight",
          "ArrowUp",
          "ArrowDown",
          "+",
          "-",
          "=",
        ].includes(e.key)
      ) {
        e.preventDefault();
        if (["+", "-", "="].includes(e.key)) zoom(e.key === "-" ? 0.2 : -0.2);
        else {
          root.rotation.y +=
            e.key === "ArrowRight" ? 0.1 : e.key === "ArrowLeft" ? -0.1 : 0;
          root.rotation.x = THREE.MathUtils.clamp(
            root.rotation.x +
              (e.key === "ArrowDown" ? 0.1 : e.key === "ArrowUp" ? -0.1 : 0),
            -Math.PI / 2,
            Math.PI / 2,
          );
          render();
        }
      }
    };
    canvas.addEventListener("pointerdown", start);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", end);
    canvas.addEventListener("pointercancel", cancel);
    canvas.addEventListener("wheel", wheel, { passive: false });
    canvas.addEventListener("keydown", key);
    const resize = () => {
      const w = element.clientWidth,
        h = element.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      render();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    resize();
    return () => {
      disposed = true;
      api.current = null;
      cancelAnimationFrame(frame);
      observer.disconnect();
      canvas.removeEventListener("pointerdown", start);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", end);
      canvas.removeEventListener("pointercancel", cancel);
      canvas.removeEventListener("wheel", wheel);
      canvas.removeEventListener("keydown", key);
      texture.dispose();
      geometry.dispose();
      material.dispose();
      marker.geometry.dispose();
      marker.material.dispose();
      renderer.dispose();
      canvas.remove();
    };
  }, []);
  useEffect(
    () => api.current?.select(location),
    [location.latitude, location.longitude],
  );
  return (
    <section className="globe-card panel">
      <div className="globe-top">
        <div>
          <div className="eyebrow">GEOGRAPHIC EXPLORER</div>
          <h2>A point on Earth. One shared context.</h2>
        </div>
        <div className="globe-actions">
          <button
            type="button"
            className="icon-btn"
            aria-label="Zoom globe out"
            onClick={() => api.current?.zoom(0.25)}
          >
            −
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Zoom globe in"
            onClick={() => api.current?.zoom(-0.25)}
          >
            +
          </button>
        </div>
      </div>
      <div className="globe-host" ref={host} />
      {error && (
        <p role="status" className="panel-intro">
          {error}
        </p>
      )}
      {textureError && (
        <p role="status">Earth texture unavailable; shaded sphere shown.</p>
      )}
      <div className="globe-selected-location" aria-live="polite">
        <div>
          <span className="eyebrow">SELECTED POINT</span>
          <h3>{location.label}</h3>
          <small>
            {location.latitude.toFixed(5)}°, {location.longitude.toFixed(5)}°
          </small>
        </div>
      </div>
      <div className="globe-places">
        {places.map((p) => (
          <button
            type="button"
            key={p.name}
            className="globe-place"
            onClick={() => onSelect(selection(p.lat, p.lon, p.name, "globe"))}
          >
            <strong>{p.name}</strong>
            <small>
              {p.lat.toFixed(4)}°, {p.lon.toFixed(4)}°
            </small>
          </button>
        ))}
      </div>
      <p className="globe-help">
        Stationary until you drag or use arrow keys. Scroll or use +/− to zoom.
        Click the surface to select a point; changing selection does not move
        the camera. Imagery is a static Earth texture, not a current satellite
        observation. No land/ocean or field boundary classification is inferred.
        A selected marker on the far side becomes visible when you rotate the
        globe.
      </p>
    </section>
  );
}
