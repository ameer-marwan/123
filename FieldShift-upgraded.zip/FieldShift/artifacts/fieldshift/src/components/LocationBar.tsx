import { useEffect, useRef, useState, type FormEvent } from "react";
import { MapPin, Search, RotateCcw } from "lucide-react";
import {
  parseCoordinates,
  selection,
  type GeoSelection,
} from "../domain/location";
type Place = {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country?: string;
  admin1?: string;
};
export default function LocationBar({
  location,
  onSelect,
  onReset,
}: {
  location: GeoSelection;
  onSelect: (p: GeoSelection) => void;
  onReset: () => void;
}) {
  const [query, setQuery] = useState(""),
    [results, setResults] = useState<Place[]>([]),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(false);
  const request = useRef<AbortController | null>(null);
  useEffect(() => () => request.current?.abort(), []);
  const search = async (e: FormEvent) => {
    e.preventDefault();
    request.current?.abort();
    const c = new AbortController();
    request.current = c;
    setError("");
    setResults([]);
    setLoading(false);
    try {
      const coords = parseCoordinates(query);
      if (coords) {
        onSelect(
          selection(...coords, `Point ${coords.join(", ")}`, "coordinates"),
        );
        return;
      }
      if (query.trim().length < 2)
        throw new Error("Enter a place name or latitude, longitude.");
      setLoading(true);
      const r = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query.trim())}&count=6&language=en&format=json`,
        { signal: AbortSignal.any([c.signal, AbortSignal.timeout(12000)]) },
      );
      if (!r.ok)
        throw new Error(
          `Place search unavailable (HTTP ${r.status}). Enter coordinates instead.`,
        );
      const json = await r.json();
      if (json.results !== undefined && !Array.isArray(json.results))
        throw new Error("Invalid place-search response.");
      const items = (json.results ?? []).filter(
        (p: Place) =>
          typeof p.name === "string" &&
          Number.isFinite(p.latitude) &&
          Number.isFinite(p.longitude) &&
          Math.abs(p.latitude) <= 90 &&
          Math.abs(p.longitude) <= 180,
      );
      if (!c.signal.aborted) {
        setResults(items);
        if (!items.length)
          setError(
            "No matching places. Try a nearby city or enter coordinates.",
          );
      }
    } catch (e) {
      if (!c.signal.aborted)
        setError(e instanceof Error ? e.message : "Search failed.");
    } finally {
      if (!c.signal.aborted) setLoading(false);
    }
  };
  return (
    <section
      className="location-workspace panel"
      aria-label="Shared selected location"
    >
      <div className="location-current" aria-live="polite">
        <MapPin size={18} />
        <div>
          <small>
            SELECTED {location.fieldId ? "FIELD REFERENCE POINT" : "POINT"} ·
            ALL ENVIRONMENTAL VIEWS
          </small>
          <strong data-testid="shared-location-label">{location.label}</strong>
          <span>
            {location.latitude.toFixed(5)}°, {location.longitude.toFixed(5)}° ·{" "}
            {location.method ?? "saved selection"}
            {location.selectedAt
              ? ` · selected ${new Date(location.selectedAt).toLocaleString()}`
              : ""}
          </span>
        </div>
        <button
          className="icon-btn"
          type="button"
          aria-label="Reset selected location"
          onClick={onReset}
        >
          <RotateCcw size={17} />
        </button>
      </div>
      <form onSubmit={search} className="location-search">
        <label htmlFor="location-query">
          Find a place or enter latitude, longitude
        </label>
        <div>
          <input
            id="location-query"
            value={query}
            onChange={(e) => {
              request.current?.abort();
              setLoading(false);
              setResults([]);
              setQuery(e.target.value);
            }}
            placeholder="Nairobi or −1.2921, 36.8219"
            maxLength={160}
          />
          <button className="btn btn-outline" type="submit" disabled={loading}>
            <Search size={16} />
            {loading ? "Searching…" : "Find"}
          </button>
        </div>
      </form>
      {error && (
        <p className="location-message" role="alert">
          {error}
        </p>
      )}
      {results.length > 0 && (
        <ul className="location-results" aria-label="Choose a search result">
          {results.map((p, i) => (
            <li key={`${p.id}-${i}`}>
              <button
                type="button"
                onClick={() => {
                  onSelect(
                    selection(
                      p.latitude,
                      p.longitude,
                      [p.name, p.admin1, p.country].filter(Boolean).join(", "),
                      "search",
                    ),
                  );
                  setResults([]);
                  setQuery("");
                }}
              >
                <strong>{p.name}</strong>
                <span>
                  {[p.admin1, p.country].filter(Boolean).join(", ")} ·{" "}
                  {p.latitude.toFixed(4)}, {p.longitude.toFixed(4)}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="location-scope">
        Environmental views use this point. Saved field records stay attached to
        their named field; selecting a point does not move a field or define its
        boundary. Field-center model values are not spatial averages.
      </p>
    </section>
  );
}
