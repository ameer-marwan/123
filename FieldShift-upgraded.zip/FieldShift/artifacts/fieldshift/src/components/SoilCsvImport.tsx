import { useEffect, useRef, useState, type ChangeEvent } from "react";
import {
  previewSoilCsv,
  soilCsvTemplate,
  type SoilObservation,
  type SoilImportPreview,
} from "../domain/soil";
export default function SoilCsvImport({
  fieldId,
  fieldName,
  existing,
  onImport,
}: {
  fieldId: string;
  fieldName: string;
  existing: SoilObservation[];
  onImport: (rows: SoilObservation[], targetId: string) => void;
}) {
  const [preview, setPreview] = useState<SoilImportPreview | null>(null),
    [filename, setFilename] = useState(""),
    [reading, setReading] = useState(false);
  const sequence = useRef(0),
    target = useRef(fieldId);
  target.current = fieldId;
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    sequence.current++;
    setPreview(null);
    setFilename("");
    setReading(false);
    if (input.current) input.current.value = "";
  }, [fieldId]);
  useEffect(
    () => () => {
      sequence.current++;
    },
    [],
  );
  const read = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0],
      version = ++sequence.current,
      selected = fieldId;
    setPreview(null);
    setFilename(file?.name ?? "");
    if (!file) return;
    if (file.size > 1024 * 1024) {
      setPreview({
        rows: [],
        total: 0,
        duplicates: 0,
        errors: ["CSV must be no larger than 1 MiB."],
      });
      return;
    }
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setPreview({
        rows: [],
        total: 0,
        duplicates: 0,
        errors: ["Choose a .csv file using the documented template."],
      });
      return;
    }
    setReading(true);
    try {
      const text = await file.text();
      if (version === sequence.current && selected === target.current)
        setPreview(previewSoilCsv(text, selected, file.name, existing));
    } catch {
      if (version === sequence.current)
        setPreview({
          rows: [],
          total: 0,
          duplicates: 0,
          errors: ["Unable to read this file. Choose a UTF-8 CSV."],
        });
    } finally {
      if (version === sequence.current) setReading(false);
    }
  };
  const template = () => {
    const url = URL.createObjectURL(
      new Blob([soilCsvTemplate], { type: "text/csv;charset=utf-8" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = "fieldshift-soil-template.csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <section
      className="panel soil-csv-import"
      aria-labelledby="soil-import-heading"
    >
      <div className="panel-head">
        <div>
          <div className="eyebrow">YOUR LABORATORY RECORDS</div>
          <h2 id="soil-import-heading">Import soil samples</h2>
        </div>
        <button type="button" className="btn btn-outline" onClick={template}>
          Download CSV template
        </button>
      </div>
      <p className="panel-intro">
        Destination: <strong>{fieldName}</strong>. Files are read only in this
        browser and are never uploaded. Importing a file records your supplied
        measurements; it does not authenticate the laboratory or convert modeled
        data into observations.
      </p>
      <label className="soil-csv-picker">
        Choose soil CSV
        <input ref={input} type="file" accept=".csv,text/csv" onChange={read} />
      </label>
      <p className="provenance-note">
        UTF-8, comma-separated, up to 1 MiB / 500 samples. Required: sample_date
        (YYYY-MM-DD), plus at least one measured property per row. Units are
        fixed by the template; blank values remain unavailable. Organic matter
        and organic carbon are not interchangeable. Unknown method and sampling
        depth stay unknown. Spreadsheet files and PDFs must first be transcribed
        or exported to this format.
      </p>
      {reading && <p role="status">Reading and validating samples…</p>}
      {preview && (
        <div aria-live="polite">
          <p className="panel-intro">
            {filename} · {preview.total} sample rows · {preview.rows.length} new
            · {preview.duplicates} duplicate rows skipped.
          </p>
          {preview.errors.length > 0 ? (
            <div className="error-panel" role="alert">
              <div>
                <strong>
                  Nothing will be imported. Correct every invalid row, then
                  choose the file again.
                </strong>
                <ul>
                  {preview.errors.slice(0, 15).map((error, i) => (
                    <li key={i}>{error}</li>
                  ))}
                </ul>
                {preview.errors.length > 15 && (
                  <p>{preview.errors.length - 15} additional errors.</p>
                )}
              </div>
            </div>
          ) : (
            <>
              {preview.rows.length > 0 && (
                <div className="table-scroll">
                  <table>
                    <caption>
                      Preview of the first {Math.min(10, preview.rows.length)}{" "}
                      new samples for {fieldName}
                    </caption>
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>pH</th>
                        <th>OM %</th>
                        <th>Moisture %</th>
                        <th>N mg/kg</th>
                        <th>Method / reference</th>
                      </tr>
                    </thead>
                    <tbody>
                      {preview.rows.slice(0, 10).map((row) => (
                        <tr key={row.id}>
                          <td>{row.date}</td>
                          <td>{row.ph ?? "—"}</td>
                          <td>{row.organicMatterPct ?? "—"}</td>
                          <td>{row.moisturePct ?? "—"}</td>
                          <td>{row.nitrogenMgKg ?? "—"}</td>
                          <td>
                            {row.method || "Unknown method"} ·{" "}
                            {row.reference || "No reference"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {preview.rows.length > 0 ? (
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => {
                    if (fieldId !== target.current) return;
                    onImport(preview.rows, fieldId);
                    setPreview(null);
                    setFilename("");
                    if (input.current) input.current.value = "";
                  }}
                >
                  Import {preview.rows.length} samples into {fieldName}
                </button>
              ) : (
                <p role="status">No new samples to import.</p>
              )}
            </>
          )}
        </div>
      )}
    </section>
  );
}
