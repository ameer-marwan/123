import { useEnvironment } from "../hooks/use-environment";
import { forecastScreening } from "../domain/risks";
import type { GeoSelection } from "../domain/location";
export default function ForecastScreening({
  location,
}: {
  location: GeoSelection;
}) {
  const { data, error, loading, refresh } = useEnvironment(location);
  const flags = data ? forecastScreening(data.daily) : [];
  return (
    <section className="panel forecast-screening">
      <div className="panel-head">
        <div>
          <div className="eyebrow">NEAR-TERM CONTEXT</div>
          <h2>Forecast screening · {location.label}</h2>
        </div>
        <button type="button" className="btn btn-outline" onClick={refresh}>
          Refresh
        </button>
      </div>
      <p className="panel-intro">
        Experimental flags: maximum ≥35 °C, minimum ≤0 °C, or daily rain ≥30 mm.
        These are transparent generic thresholds, not crop-specific validated
        predictions or official alerts. Seven days of forecast cannot establish
        long-term climate suitability or drought.
      </p>
      {loading && <p role="status">Loading forecast context…</p>}
      {error && (
        <p role="status">
          Forecast unavailable: {error} No seasonal climate assessment is
          inferred.
        </p>
      )}
      {data && (
        <>
          <div className="screening-flags">
            {flags.length ? (
              flags.map((f, i) => (
                <article key={`${f.date}-${i}`}>
                  <strong>
                    {f.label} · {f.date}
                  </strong>
                  <p>
                    {f.evidence} {f.action}
                  </p>
                </article>
              ))
            ) : (
              <p>
                No threshold exceeded in available forecast values. Missing
                values and other risks are not screened; this does not establish
                safety.
              </p>
            )}
          </div>
          <p className="provenance-note">
            Source: Open-Meteo forecast model · {data.daily.time[0]}–
            {data.daily.time.at(-1)} · {data.timezone} · grid point{" "}
            {data.latitude}, {data.longitude} · retrieved{" "}
            {new Date(data.retrievedAt).toLocaleString()}{" "}
            {data.cached ? "(cached)" : ""}.{" "}
            <a
              href="https://open-meteo.com/en/docs"
              target="_blank"
              rel="noreferrer"
            >
              Provider documentation
            </a>
          </p>
        </>
      )}
    </section>
  );
}
