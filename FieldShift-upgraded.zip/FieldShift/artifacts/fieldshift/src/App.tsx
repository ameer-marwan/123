import { weatherScene, weatherScenePhoto } from "./domain/weather-scene";
import SoilCsvImport from "./components/SoilCsvImport";
import {
  optionalMeasurement,
  soilObservationSchema,
  soilFingerprint,
  type SoilObservation,
} from "./domain/soil";
import ForecastScreening from "./components/ForecastScreening";
import { savedStoreSchema, csvCell } from "./domain/storage";
import { rankCrops, rotationWarnings, cropFamily } from "./domain/planning";
import { lazy, Suspense } from "react";
const GeoGlobe = lazy(() => import("./components/GeoGlobe"));
import LocationBar from "./components/LocationBar";
import {
  selection,
  validCoordinates,
  fieldCenter,
  polygonAreaHa,
  validatePolygon,
  surfacePoint,
  surfaceCoordinates,
  type GeoSelection,
} from "./domain/location";
import { useEnvironment } from "./hooks/use-environment";
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { Link, Route, Switch, useLocation } from "wouter";
import L from "leaflet";

import "leaflet/dist/leaflet.css";
import FieldShiftOnboarding from "./components/FieldShiftOnboarding";
import {
  Activity as ActivityIcon,
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronRight,
  CircleHelp,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Compass,
  Download,
  Droplets,
  Ellipsis,
  FileText,
  Globe2,
  Languages,
  Layers3,
  Leaf,
  LocateFixed,
  Map as MapIcon,
  Menu,
  Moon,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  Snowflake,
  Sprout,
  Sun,
  TreePine,
  Trash2,
  Waves,
  Wind,
  X,
  MapPin,
  Info,
} from "lucide-react";

type Crop = {
  id: string;
  name: string;
  category: string;
  seasonDays: number;
  waterNeedMm: number;
  phMin: number;
  phMax: number;
  nitrogenFixing: boolean;
  waterScore: number;
  soilScore: number;
  diversityScore: number;
  riskScore: number;
  yieldTonnesHa: number;
  costSarHa: number;
  priceSarTonne: number;
  assumptionLabel: string;
};
type Field = {
  id: string;
  farmId: string;
  name: string;
  areaHectares: number;
  cropId: string;
  boundary?: [number, number][];
};
type IrrigationEvent = {
  id: string;
  fieldId: string;
  date: string;
  depthMm: number;
  volumeM3: number;
  method: string;
  notes: string;
};
type Plan = {
  id: string;
  fieldId: string;
  name: string;
  seasons: { year: number; cropId: string }[];
};
type Settings = {
  theme: "dark" | "light";
  language: "en" | "ar";
  areaUnit: "ha" | "ac";
  temperatureUnit: "C" | "F";
  waterUnit: "mm" | "m3";
  currency: "SAR" | "USD";
};

type Store = {
  fields: Field[];
  soils: SoilObservation[];
  irrigation: IrrigationEvent[];
  plans: Plan[];
  settings: Settings;
  selectedFarm: string;
  selectedField: string;
  selectedLocation: GeoSelection;
};

const cropLibrary: Crop[] = [
  {
    id: "wheat",
    name: "Durum wheat",
    category: "Cereal",
    seasonDays: 125,
    waterNeedMm: 430,
    phMin: 6.0,
    phMax: 8.2,
    nitrogenFixing: false,
    waterScore: 68,
    soilScore: 86,
    diversityScore: 72,
    riskScore: 72,
    yieldTonnesHa: 3.8,
    costSarHa: 2900,
    priceSarTonne: 1520,
    assumptionLabel: "Regional planning assumption",
  },
  {
    id: "barley",
    name: "Feed barley",
    category: "Cereal",
    seasonDays: 105,
    waterNeedMm: 340,
    phMin: 6.0,
    phMax: 8.5,
    nitrogenFixing: false,
    waterScore: 84,
    soilScore: 81,
    diversityScore: 68,
    riskScore: 83,
    yieldTonnesHa: 3.2,
    costSarHa: 2350,
    priceSarTonne: 1310,
    assumptionLabel: "Regional planning assumption",
  },
  {
    id: "alfalfa",
    name: "Alfalfa",
    category: "Legume",
    seasonDays: 180,
    waterNeedMm: 720,
    phMin: 6.2,
    phMax: 8.0,
    nitrogenFixing: true,
    waterScore: 38,
    soilScore: 78,
    diversityScore: 92,
    riskScore: 62,
    yieldTonnesHa: 8.5,
    costSarHa: 5200,
    priceSarTonne: 950,
    assumptionLabel: "Regional planning assumption",
  },
  {
    id: "chickpea",
    name: "Chickpea",
    category: "Legume",
    seasonDays: 115,
    waterNeedMm: 310,
    phMin: 6.0,
    phMax: 8.0,
    nitrogenFixing: true,
    waterScore: 91,
    soilScore: 80,
    diversityScore: 94,
    riskScore: 79,
    yieldTonnesHa: 1.6,
    costSarHa: 2700,
    priceSarTonne: 4350,
    assumptionLabel: "Regional planning assumption",
  },
  {
    id: "tomato",
    name: "Processing tomato",
    category: "Vegetable",
    seasonDays: 145,
    waterNeedMm: 610,
    phMin: 5.8,
    phMax: 7.5,
    nitrogenFixing: false,
    waterScore: 49,
    soilScore: 88,
    diversityScore: 78,
    riskScore: 67,
    yieldTonnesHa: 62,
    costSarHa: 17800,
    priceSarTonne: 680,
    assumptionLabel: "Regional planning assumption",
  },
  {
    id: "sorghum",
    name: "Grain sorghum",
    category: "Cereal",
    seasonDays: 115,
    waterNeedMm: 410,
    phMin: 5.5,
    phMax: 8.5,
    nitrogenFixing: false,
    waterScore: 78,
    soilScore: 74,
    diversityScore: 82,
    riskScore: 86,
    yieldTonnesHa: 3.6,
    costSarHa: 3100,
    priceSarTonne: 1740,
    assumptionLabel: "Regional planning assumption",
  },
];
const farms = [
  {
    id: "farm-1",
    name: "Al Kharj Demo Farm",
    location: "Al Kharj, Riyadh Province, Saudi Arabia",
    latitude: 24.155,
    longitude: 47.312,
    fieldIds: ["f1", "f2", "f3"],
  },
];
const demoFields: Field[] = [
  {
    id: "f1",
    farmId: "farm-1",
    name: "North Pivot",
    areaHectares: 18.4,
    cropId: "wheat",
    boundary: [
      [24.164, 47.301],
      [24.169, 47.316],
      [24.158, 47.325],
      [24.153, 47.309],
    ],
  },
  {
    id: "f2",
    farmId: "farm-1",
    name: "East Block",
    areaHectares: 12.7,
    cropId: "barley",
    boundary: [
      [24.146, 47.324],
      [24.151, 47.34],
      [24.139, 47.347],
      [24.134, 47.33],
    ],
  },
  {
    id: "f3",
    farmId: "farm-1",
    name: "South Trial",
    areaHectares: 8.2,
    cropId: "chickpea",
    boundary: [
      [24.128, 47.307],
      [24.135, 47.322],
      [24.124, 47.33],
      [24.118, 47.314],
    ],
  },
];
const initialStore: Store = {
  fields: demoFields,
  soils: [
    {
      id: "s1",
      fieldId: "f1",
      date: "2025-02-14",
      ph: 7.4,
      organicMatterPct: 1.8,
      moisturePct: 24,
      nitrogenMgKg: 31,
      source: "Demo assumption",
      notes: "Seeded sample; not a measured test.",
    },
    {
      id: "s2",
      fieldId: "f2",
      date: "2025-01-22",
      ph: 7.8,
      organicMatterPct: 1.4,
      moisturePct: 19,
      nitrogenMgKg: 24,
      source: "Demo assumption",
      notes: "Seeded sample; not a measured test.",
    },
  ],
  irrigation: [
    {
      id: "i1",
      fieldId: "f1",
      date: "2025-03-04",
      depthMm: 22,
      volumeM3: 4048,
      method: "Center pivot",
      notes: "Demo record",
    },
    {
      id: "i2",
      fieldId: "f1",
      date: "2025-03-11",
      depthMm: 18,
      volumeM3: 3312,
      method: "Center pivot",
      notes: "Demo record",
    },
    {
      id: "i3",
      fieldId: "f2",
      date: "2025-03-07",
      depthMm: 26,
      volumeM3: 3302,
      method: "Drip",
      notes: "Demo record",
    },
  ],
  plans: [
    {
      id: "p1",
      fieldId: "f1",
      name: "North Pivot rotation",
      seasons: [
        { year: 2025, cropId: "wheat" },
        { year: 2026, cropId: "chickpea" },
        { year: 2027, cropId: "barley" },
      ],
    },
  ],
  settings: {
    theme: "dark",
    language: "en",
    areaUnit: "ha",
    temperatureUnit: "C",
    waterUnit: "mm",
    currency: "SAR",
  },
  selectedFarm: "farm-1",
  selectedField: "f1",
  selectedLocation: {
    latitude: 24.155,
    longitude: 47.312,
    label: "Al Kharj, Riyadh Province, Saudi Arabia",
  },
};
const storeKey = "fieldshift-demo-v1";
function readStore(): Store {
  try {
    const saved = localStorage.getItem(storeKey);
    if (saved) {
      const result = savedStoreSchema.safeParse({
        ...JSON.parse(saved),
        selectedLocation:
          JSON.parse(saved).selectedLocation ?? initialStore.selectedLocation,
      });
      if (!result.success) {
        sessionStorage.setItem(
          "fieldshift-storage-warning",
          "Saved browser records could not be read safely. The original storage has been preserved; export or recover it before saving new records.",
        );
        return initialStore;
      }
      const parsed = result.data;
      return {
        ...initialStore,
        ...parsed,
        selectedLocation:
          parsed.selectedLocation ?? initialStore.selectedLocation,
      } as Store;
    }
  } catch {
    try {
      sessionStorage.setItem(
        "fieldshift-storage-warning",
        "Saved browser records are unreadable. Original storage is preserved; recover it before saving new records, or explicitly reset demo data in Settings.",
      );
    } catch {}
  }
  return initialStore;
}
function uid() {
  return (
    globalThis.crypto?.randomUUID?.() ??
    `id-${Date.now()}-${Math.random().toString(16).slice(2)}`
  );
}
const navItems = [
  { path: "/", label: "Overview", icon: Layers3 },
  { path: "/map", label: "Field map", icon: MapIcon },
  { path: "/weather", label: "Weather", icon: CloudSun },
  { path: "/soil", label: "Soil", icon: Sprout },
  { path: "/crops", label: "Crop planner", icon: Leaf },
  { path: "/water", label: "Water", icon: Droplets },
  { path: "/analytics", label: "Analytics", icon: BarChart3 },
  { path: "/reports", label: "Reports", icon: FileText },
  { path: "/settings", label: "Settings", icon: Settings2 },
  { path: "/about", label: "About", icon: CircleHelp },
];
const arabic: { [key: string]: string } = {
  Overview: "نظرة عامة",
  "Field map": "خريطة الحقول",
  Weather: "الطقس",
  Soil: "التربة",
  "Crop planner": "مخطط المحاصيل",
  Water: "المياه",
  Analytics: "التحليلات",
  Reports: "التقارير",
  Settings: "الإعدادات",
  About: "عن FieldShift",
};
function App() {
  const [store, setStore] = useState<Store>(readStore);
  const [path, setPath] = useLocation();
  const [showIntro, setShowIntro] = useState(() => path === "/");
  const [drawer, setDrawer] = useState(false);
  const [notice, setNotice] = useState("");
  const storageWarning = sessionStorage.getItem("fieldshift-storage-warning");
  const currentFarm =
    farms.find((f) => f.id === store.selectedFarm) ?? farms[0];
  const selectedField =
    store.fields.find((f) => f.id === store.selectedField) ?? store.fields[0];
  useEffect(() => {
    try {
      if (!sessionStorage.getItem("fieldshift-storage-warning"))
        localStorage.setItem(storeKey, JSON.stringify(store));
    } catch {
      setNotice(
        "Browser storage unavailable or full. Changes are only kept for this session; export records before closing.",
      );
    }
    document.documentElement.classList.toggle(
      "dark",
      store.settings.theme === "dark",
    );
    document.documentElement.dir =
      store.settings.language === "ar" ? "rtl" : "ltr";
  }, [store]);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(""), 2800);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [notice]);
  const update = (fn: (s: Store) => Store) =>
    setStore((s) => {
      const next = fn(s);
      if (
        next.selectedField !== s.selectedField &&
        next.selectedLocation === s.selectedLocation
      ) {
        const f = next.fields.find((f) => f.id === next.selectedField);
        const center = fieldCenter(f?.boundary);
        if (f && center)
          next.selectedLocation = selection(
            ...center,
            `${f.name} · field reference point`,
            "field",
            f.id,
          );
      } else if (next.selectedLocation !== s.selectedLocation) {
        const loc = next.selectedLocation;
        if (!validCoordinates(loc.latitude, loc.longitude)) return s;
        next.selectedLocation = selection(
          loc.latitude,
          loc.longitude,
          loc.label,
          loc.method ?? "map",
          loc.fieldId,
        );
      }
      return next;
    });
  const fieldName = (id: string) =>
    store.fields.find((f) => f.id === id)?.name ?? "Removed field";
  const cropName = (id: string) =>
    cropLibrary.find((c) => c.id === id)?.name ?? "Unassigned";
  const title = navItems.find((n) => n.path === path)?.label ?? "Overview";
  const t = (label: string) =>
    store.settings.language === "ar" ? (arabic[label] ?? label) : label;
  const pageProps = {
    store,
    update,
    currentFarm,
    selectedField,
    fieldName,
    cropName,
    notify: setNotice,
    selectedLocation: store.selectedLocation ?? initialStore.selectedLocation,
  };
  const finishOnboarding = () => {
    try {
      localStorage.setItem("fieldshift-onboarding-complete", "true");
      localStorage.setItem("fieldshift-cinematic-v2", "true");
    } catch {}
    setShowIntro(false);
    requestAnimationFrame(() =>
      document.getElementById("main-content")?.focus({ preventScroll: true }),
    );
  };
  useEffect(() => {
    const replay = () => setShowIntro(true);
    window.addEventListener("fieldshift-replay-intro", replay);
    return () => window.removeEventListener("fieldshift-replay-intro", replay);
  }, []);
  if (showIntro) return <FieldShiftOnboarding onComplete={finishOnboarding} />;
  return (
    <div className="app-frame fs-workspace-enter">
      <aside
        className={`sidebar ${drawer ? "sidebar-open" : ""}`}
        aria-label="Main navigation"
      >
        <div className="brand">
          <Link
            href="/"
            className="brand-home-link"
            aria-label="Go to FieldShift home"
            data-testid="link-fieldshift-home"
          >
            <img
              className="brand-mark"
              src="/images/fieldshift-emblem.png"
              alt=""
              data-testid="image-fieldshift-brand"
            />
            <span>
              <strong>FIELD SHIFT</strong>
              <small>FIELD OPERATIONS</small>
            </span>
          </Link>
          <button
            className="icon-btn mobile-close"
            aria-label="Close navigation"
            onClick={() => setDrawer(false)}
          >
            <X size={18} />
          </button>
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav className="nav-list">
          {navItems.map(({ path: href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              data-testid={`link-nav-${href === "/" ? "overview" : href.slice(1)}`}
              className={`nav-link ${path === href ? "is-active" : ""}`}
              onClick={() => setDrawer(false)}
            >
              <Icon size={18} />
              <span>{t(label)}</span>
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sync-state">
            <span className="sync-dot" />
            <div>
              <strong>Local demo workspace</strong>
              <small>No account or server sync</small>
            </div>
          </div>
          <Link href="/settings" className="profile-link">
            <div className="profile-avatar">FS</div>
            <div>
              <strong>Field operator</strong>
              <small>Browser-only data</small>
            </div>
            <Ellipsis size={17} />
          </Link>
        </div>
      </aside>
      {drawer && (
        <button
          aria-label="Close menu"
          className="drawer-scrim"
          onClick={() => setDrawer(false)}
        />
      )}
      <main className="main-area">
        <header className="topbar">
          <button
            className="icon-btn menu-toggle"
            aria-label="Open navigation"
            onClick={() => setDrawer(true)}
          >
            <Menu size={20} />
          </button>
          <div className="crumb">
            <strong>{t(title)}</strong>
          </div>
          <div className="top-actions">
            <span className="local-badge">
              <span />
              DEMO DATA
            </span>
            <button
              className="icon-btn theme-toggle"
              aria-label="Toggle color theme"
              data-testid="button-theme-toggle"
              onClick={() =>
                update((s) => ({
                  ...s,
                  settings: {
                    ...s.settings,
                    theme: s.settings.theme === "dark" ? "light" : "dark",
                  },
                }))
              }
            >
              {store.settings.theme === "dark" ? (
                <Sun size={17} />
              ) : (
                <Moon size={17} />
              )}
            </button>
            <Link href="/settings" className="top-avatar" aria-label="Settings">
              FS
            </Link>
          </div>
        </header>
        <a className="skip-link" href="#main-content">
          Skip to content
        </a>
        <div className="page-shell" id="main-content" tabIndex={-1}>
          {storageWarning && (
            <p className="error-panel" role="alert">
              {storageWarning}
            </p>
          )}
          <LocationBar
            location={store.selectedLocation}
            onSelect={(loc) => update((s) => ({ ...s, selectedLocation: loc }))}
            onReset={() =>
              update((s) => ({
                ...s,
                selectedLocation: selection(
                  initialStore.selectedLocation.latitude,
                  initialStore.selectedLocation.longitude,
                  initialStore.selectedLocation.label,
                  "reset",
                ),
              }))
            }
          />
          {path === "/map" && selectedField.boundary && (
            <div className="map-boundary-actions">
              <span>
                Selected outline · planning use only, not a legal boundary
              </span>
              <Button
                variant="danger"
                onClick={() => {
                  if (
                    window.confirm(
                      `Delete the saved boundary for ${selectedField.name}?`,
                    )
                  ) {
                    update((s) => ({
                      ...s,
                      fields: s.fields.map((f) =>
                        f.id === selectedField.id
                          ? { ...f, boundary: undefined }
                          : f,
                      ),
                    }));
                    setNotice("Saved boundary deleted.");
                  }
                }}
              >
                <Trash2 size={15} />
                Delete boundary
              </Button>
            </div>
          )}
          <div className="fs-route-content" key={path}>
            <Switch>
              <Route path="/">
                <Overview {...pageProps} />
              </Route>
              <Route path="/map">
                <MapPage {...pageProps} />
              </Route>
              <Route path="/weather">
                <WeatherPage {...pageProps} />
              </Route>
              <Route path="/soil">
                <SoilPage {...pageProps} />
              </Route>
              <Route path="/crops">
                <CropsPage {...pageProps} />
              </Route>
              <Route path="/water">
                <WaterPage {...pageProps} />
              </Route>
              <Route path="/analytics">
                <AnalyticsPage {...pageProps} />
              </Route>
              <Route path="/reports">
                <ReportsPage {...pageProps} />
              </Route>
              <Route path="/settings">
                <SettingsPage {...pageProps} />
              </Route>
              <Route path="/about">
                <AboutPage {...pageProps} />
              </Route>
              <Route>
                <NotFound setPath={setPath} />
              </Route>
            </Switch>
          </div>
        </div>
        <footer className="app-footer">
          <span>
            FIELD SHIFT <i>·</i> DECISION SUPPORT
          </span>
          <span>
            Local demo ·{" "}
            {new Date().toLocaleDateString(
              store.settings.language === "ar" ? "ar" : "en",
              { month: "short", day: "numeric", year: "numeric" },
            )}
          </span>
        </footer>
      </main>
      {notice && (
        <div className="toast-note" role="status">
          <Check size={16} />
          {notice}
        </div>
      )}
    </div>
  );
}
type PageProps = {
  store: Store;
  update: (fn: (s: Store) => Store) => void;
  currentFarm: (typeof farms)[number];
  selectedField: Field;
  fieldName: (id: string) => string;
  cropName: (id: string) => string;
  notify: (message: string) => void;
  selectedLocation: GeoSelection;
};
function PageHeader({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  const images: Record<
    string,
    {
      id: string;
      src: string;
      alt: string;
      label: string;
      title: string;
      copy: string;
    }
  > = {
    "Crop planner": {
      id: "crops",
      src: "/images/agricultural_field.jpg",
      alt: "Cultivated agricultural field at sunset",
      label: "CROPS / FIELD PLANNING",
      title: "Plan with the landscape in view",
      copy: "Crop scores are regional planning assumptions, not yield guarantees.",
    },
    "Irrigation & water": {
      id: "water",
      src: "/images/lake_water.jpg",
      alt: "Illustrative inland water landscape",
      label: "WATER / IRRIGATION",
      title: "Water connects every field",
      copy: "Inland-water imagery is illustrative, not evidence of available water at the selected point.",
    },
    Analytics: {
      id: "analytics",
      src: "/images/forest_soil.jpg",
      alt: "Green forest canopy and undergrowth",
      label: "FIELD INTELLIGENCE",
      title: "Explore the records behind each view",
      copy: "Charts use saved observations or clearly labeled local demo series.",
    },
    Reports: {
      id: "reports",
      src: "/images/agricultural_field.jpg",
      alt: "Agricultural field landscape",
      label: "FIELD DOCUMENTS",
      title: "Bring field records together",
      copy: "Reports reflect this browser’s local data and sample assumptions.",
    },
  };
  const image = images[title];
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h1>{title}</h1>
          <p>{description}</p>
        </div>
        {action && <div className="heading-action">{action}</div>}
      </div>
      {image && <TopicPhoto {...image} />}
    </>
  );
}
function Button({
  children,
  onClick,
  variant = "primary",
  testId,
  type,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "outline" | "quiet" | "danger";
  testId?: string;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type ?? "button"}
      data-testid={testId}
      className={`btn btn-${variant}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
function SelectField({
  label,
  value,
  onChange,
  options,
  testId,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  testId: string;
}) {
  return (
    <label className="field-control">
      <span>{label}</span>
      <select
        value={value}
        data-testid={testId}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
function Metric({
  label,
  value,
  unit,
  delta,
  icon: Icon,
  accent = "lime",
}: {
  label: string;
  value: string;
  unit?: string;
  delta?: string;
  icon: typeof ActivityIcon;
  accent?: string;
}) {
  return (
    <article className="metric-card">
      <div className={`metric-icon ${accent}`}>
        <Icon size={18} />
      </div>
      <div className="metric-label">{label}</div>
      <div className="metric-value">
        {value}
        <small>{unit}</small>
      </div>
      {delta && <div className="metric-note">{delta}</div>}
    </article>
  );
}
function WeatherConditionIcon({
  code,
  temperature,
  size,
}: {
  code: number;
  temperature: number;
  size: number;
}) {
  if ([71, 73, 75, 77, 85, 86, 56, 57, 66, 67].includes(code))
    return <CloudSnow size={size} aria-hidden="true" />;

  if ([95, 96, 99].includes(code))
    return <CloudLightning size={size} aria-hidden="true" />;
  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(code))
    return <CloudRain size={size} aria-hidden="true" />;
  if ([0, 1].includes(code)) return <Sun size={size} aria-hidden="true" />;
  return <CloudSun size={size} aria-hidden="true" />;
}
function areaDisplay(ha: number, unit: "ha" | "ac") {
  return (unit === "ac" ? ha * 2.4710538147 : ha).toFixed(1);
}
function moneyDisplay(sar: number, currency: "SAR" | "USD") {
  return `${(currency === "USD" ? sar / 3.75 : sar).toLocaleString(undefined, { maximumFractionDigits: 0 })} ${currency}`;
}
function displayNumber(value: number | null | undefined, digits = 1) {
  return typeof value === "number" && Number.isFinite(value)
    ? value.toFixed(digits)
    : "—";
}
function formatCoordinates(latitude: number, longitude: number) {
  return `${Math.abs(latitude).toFixed(2)}° ${latitude >= 0 ? "N" : "S"} · ${Math.abs(longitude).toFixed(2)}° ${longitude >= 0 ? "E" : "W"}`;
}
function temperatureCelsius(value: number, unit: string) {
  return unit.toLowerCase().includes("f") ? ((value - 32) * 5) / 9 : value;
}
function TopicPhoto({
  id,
  src,
  alt,
  label,
  title,
  copy,
}: {
  id: string;
  src: string;
  alt: string;
  label: string;
  title: string;
  copy: string;
}) {
  return (
    <section
      className="topic-photo-band panel"
      data-testid={`image-band-${id}`}
    >
      <img className="topic-photo-image" src={src} alt={alt} loading="lazy" />
      <div className="topic-photo-shade" />
      <div className="topic-photo-content">
        <span>{label}</span>
        <h2>{title}</h2>
        <p>{copy}</p>
      </div>
    </section>
  );
}
function mapPopupContent(title: string, details: string[]) {
  const root = document.createElement("div");
  root.className = "field-map-popup";
  const heading = document.createElement("strong");
  heading.textContent = title;
  root.appendChild(heading);
  details.forEach((detail) => {
    const line = document.createElement("p");
    line.textContent = detail;
    root.appendChild(line);
  });
  return root;
}
function mapTextContent(text: string) {
  const node = document.createElement("span");
  node.textContent = text;
  return node;
}
function EmptyState({
  title,
  copy,
  action,
}: {
  title: string;
  copy: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <div className="empty-mark">
        <Leaf size={22} />
      </div>
      <h3>{title}</h3>
      <p>{copy}</p>
      {action}
    </div>
  );
}
function Overview(p: PageProps) {
  const total = p.store.fields.reduce((n, f) => n + f.areaHectares, 0);
  const latest = p.store.soils
    .filter((s) => s.fieldId === p.selectedField.id)
    .sort((a, b) => b.date.localeCompare(a.date))[0];
  const lastWater = p.store.irrigation
    .filter((e) => e.fieldId === p.selectedField.id)
    .reduce((n, e) => n + e.depthMm, 0);
  const activities = [
    ...p.store.irrigation.map((i) => ({
      date: i.date,
      label: `${i.method} irrigation logged`,
      type: "Water",
    })),
    ...p.store.soils.map((s) => ({
      date: s.date,
      label: `Soil observation · pH ${displayNumber(s.ph)}`,
      type: "Soil",
    })),
  ]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 4);
  return (
    <>
      <PageHeader
        eyebrow="FIELD OPERATIONS / 01"
        title="Good morning, operator."
        description="A clear read on what is happening across your fields today."
        action={
          <SelectField
            label="ACTIVE FIELD"
            value={p.selectedField.id}
            onChange={(v) => p.update((s) => ({ ...s, selectedField: v }))}
            options={p.store.fields.map((f) => ({
              value: f.id,
              label: f.name,
            }))}
            testId="select-active-field"
          />
        }
      />
      <div
        className="overview-banner"
        style={{
          backgroundImage:
            'linear-gradient(90deg,rgba(10,24,17,.94),rgba(10,24,17,.76) 54%,rgba(10,24,17,.24)),url("/images/agricultural_field.jpg")',
        }}
      >
        <div className="banner-orbit">
          <div className="orbit-ring" />
          <div className="orbit-core">
            <Compass size={28} />
          </div>
          <span className="orbit-pip" />
        </div>
        <div className="banner-copy">
          <span className="banner-kicker">FIELD NOTE / TODAY</span>
          <h2>Decisions, grounded in your land.</h2>
          <p>
            Field conditions and planning assumptions in one operational view.
            Confirm sample data before acting.
          </p>
        </div>
        <Link href="/map" className="banner-link">
          Open field map <ArrowRight size={16} />
        </Link>
      </div>
      <div className="metric-grid">
        <Metric
          label="Managed area"
          value={areaDisplay(total, p.store.settings.areaUnit)}
          unit={p.store.settings.areaUnit}
          delta={`${p.store.fields.length} mapped fields`}
          icon={MapIcon}
        />
        <Metric
          label="Soil readings"
          value={String(p.store.soils.length)}
          delta="Demo samples + entries"
          icon={Sprout}
          accent="green"
        />
        <Metric
          label="Water applied"
          value={lastWater.toFixed(0)}
          unit="mm"
          delta={`${p.store.irrigation.filter((e) => e.fieldId === p.selectedField.id).length} records · selected field`}
          icon={Droplets}
          accent="blue"
        />
        <Metric
          label="Current crop"
          value={p.cropName(p.selectedField.cropId)}
          delta="Planning assumption"
          icon={Leaf}
          accent="gold"
        />
      </div>
      <div className="content-grid">
        <section className="panel field-summary">
          <div className="panel-head">
            <div>
              <div className="eyebrow">FIELD STATUS</div>
              <h2>{p.selectedField.name}</h2>
            </div>
            <Link href="/soil" className="text-link">
              View soil <ArrowRight size={14} />
            </Link>
          </div>
          <div className="field-summary-main">
            <div className="field-thumb">
              <FieldSketch />
            </div>
            <div className="field-facts">
              <div>
                <span>Area</span>
                <strong>
                  {areaDisplay(
                    p.selectedField.areaHectares,
                    p.store.settings.areaUnit,
                  )}{" "}
                  {p.store.settings.areaUnit}
                </strong>
              </div>
              <div>
                <span>Crop</span>
                <strong>{p.cropName(p.selectedField.cropId)}</strong>
              </div>
              <div>
                <span>Soil pH</span>
                <strong>
                  {latest ? displayNumber(latest.ph) : "—"}{" "}
                  <small>
                    {latest?.source === "Entered" ? "Entered" : "Demo"}
                  </small>
                </strong>
              </div>
            </div>
          </div>
          <div className="data-callout">
            <AlertTriangle size={15} />
            <span>
              Seeded soil values are illustrative demo assumptions—not field
              measurements.
            </span>
          </div>
        </section>
        <section className="panel activity-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">FIELD JOURNAL</div>
              <h2>Recent activity</h2>
            </div>
            <ActivityIcon size={18} className="muted-icon" />
          </div>
          {activities.length ? (
            activities.map((a, i) => (
              <div className="activity-row" key={`${a.date}-${i}`}>
                <div
                  className={`activity-bullet ${a.type === "Soil" ? "bullet-soil" : ""}`}
                />
                <div>
                  <strong>{a.label}</strong>
                  <small>
                    {a.type} · {a.date}
                  </small>
                </div>
                <ChevronRight size={15} />
              </div>
            ))
          ) : (
            <EmptyState
              title="A quiet field"
              copy="New field activity will appear here."
            />
          )}
          <Link href="/reports" className="activity-footer">
            Build a field report <ArrowRight size={14} />
          </Link>
        </section>
      </div>
      <section className="panel seasonal-strip">
        <div>
          <div className="eyebrow">SEASONAL OUTLOOK</div>
          <h2>Plan with context, not guesswork.</h2>
          <p>
            Live weather is fetched from Open-Meteo. Crop economics and rotation
            values are clearly labeled regional assumptions.
          </p>
        </div>
        <div className="outlook-actions">
          <Link href="/weather" className="btn btn-outline">
            <CloudSun size={16} /> Check weather
          </Link>
          <Link href="/crops" className="btn btn-primary">
            <Sprout size={16} /> Review crop plan
          </Link>
        </div>
      </section>
    </>
  );
}
function FieldSketch() {
  return (
    <svg viewBox="0 0 250 130" role="img" aria-label="Abstract field layout">
      <path
        d="M15 22 119 8l111 30-4 64-105 18L13 86Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeDasharray="5 5"
      />
      <path
        d="M31 28 117 18l91 25-3 49-89 15-87-24Z"
        fill="rgba(197,243,107,.13)"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="M38 40 113 29m-70 22 145 17m-146 2 135 17"
        fill="none"
        stroke="currentColor"
        strokeOpacity=".38"
      />
      <circle cx="119" cy="67" r="5" fill="currentColor" />
      <path d="M119 67 180 43" stroke="currentColor" strokeDasharray="3 4" />
    </svg>
  );
}

function MapPage(p: PageProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapObj = useRef<L.Map | null>(null);
  const layers = useRef<L.LayerGroup | null>(null);
  const [editing, setEditing] = useState(false);
  const [points, setPoints] = useState<[number, number][]>([]);
  const [tab, setTab] = useState<"map" | "globe">(() =>
    new URLSearchParams(window.location.search).get("view") === "globe"
      ? "globe"
      : "map",
  );
  const [fieldName, setFieldName] = useState("New field");
  const area = polygonAreaHa(points).toFixed(3);
  const [tileError, setTileError] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const referenceId = new URLSearchParams(window.location.search).get(
    "reference",
  );
  const referencePlaces = [
    { id: "alkharj", name: "Al Kharj", lat: 24.1558, lon: 47.312 },
    { id: "riyadh", name: "Riyadh", lat: 24.7136, lon: 46.6753 },
    { id: "alahsa", name: "Al-Ahsa Oasis", lat: 25.3835, lon: 49.587 },
  ];
  const selectedSoil = p.store.soils
    .filter((item) => item.fieldId === p.selectedField.id)
    .sort((a, b) => b.date.localeCompare(a.date))[0];
  const selectedWater = p.store.irrigation.filter(
    (item) => item.fieldId === p.selectedField.id,
  );
  const selectedWaterTotal = selectedWater.reduce(
    (total, item) => total + item.depthMm,
    0,
  );
  useEffect(() => {
    if (!mapObj.current) return;
    const map = mapObj.current;
    const addPoint = (e: L.LeafletMouseEvent) => {
      if (editing) setPoints((v) => [...v, [e.latlng.lat, e.latlng.lng]]);
      else
        p.update((s) => ({
          ...s,
          selectedLocation: {
            latitude: e.latlng.lat,
            longitude: e.latlng.lng,
            label: `Map selection (${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)})`,
          },
        }));
    };
    map.off("click");
    map.on("click", addPoint);
    return () => {
      map.off("click", addPoint);
    };
  }, [editing, tab]);
  useEffect(() => {
    if (!mapRef.current || tab !== "map" || mapObj.current) return;
    const map = L.map(mapRef.current, { zoomControl: false }).setView(
      [p.selectedLocation.latitude, p.selectedLocation.longitude],
      10,
    );
    const tileLayer = L.tileLayer(
      "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
      {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      },
    ).addTo(map);
    tileLayer.on("tileerror", () => setTileError(true));
    L.control.scale({ imperial: true, metric: true }).addTo(map);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    const group = L.layerGroup().addTo(map);
    layers.current = group;
    mapObj.current = map;
    map.on("click", (e: L.LeafletMouseEvent) => {
      if (editing) setPoints((v) => [...v, [e.latlng.lat, e.latlng.lng]]);
      else
        p.update((s) => ({
          ...s,
          selectedLocation: {
            latitude: e.latlng.lat,
            longitude: e.latlng.lng,
            label: `Map selection (${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)})`,
          },
        }));
    });
    return () => {
      map.remove();
      mapObj.current = null;
      layers.current = null;
    };
  }, [tab]);
  useEffect(() => {
    const map = mapObj.current;
    if (!map || tab !== "map") return;
    const place = referencePlaces.find((item) => item.id === referenceId);
    if (!place) return;
    p.update((s) => ({
      ...s,
      selectedLocation: selection(place.lat, place.lon, place.name, "map"),
    }));
    map.setView([place.lat, place.lon], 8);
    const marker = L.circleMarker([place.lat, place.lon], {
      radius: 9,
      color: "#fff7e7",
      weight: 3,
      fillColor: "#d99b4b",
      fillOpacity: 1,
    }).addTo(map);
    marker
      .bindTooltip(`${place.name} · Reference place · not a registered farm`, {
        permanent: true,
        direction: "top",
      })
      .bindPopup(
        mapPopupContent(place.name, [
          `${place.lat.toFixed(4)}°, ${place.lon.toFixed(4)}°`,
          "Geographic reference only · not a registered farm",
        ]),
      )
      .openPopup();
    return () => {
      map.removeLayer(marker);
    };
  }, [referenceId, tab]);
  useEffect(() => {
    if (!mapObj.current || !layers.current) return;
    const map = mapObj.current;
    const group = layers.current;
    group.clearLayers();
    p.store.fields.forEach((f) => {
      const crop = p.cropName(f.cropId);
      const fieldDetails = [
        `${crop} · ${f.areaHectares.toFixed(1)} ha`,
        f.boundary?.length
          ? `Saved outline · ${f.boundary.length} points · planning only`
          : "Demo location based on farm center",
        "Tap a field marker to select it and show the full record",
      ];
      if (f.boundary?.length) {
        const poly = L.polygon(f.boundary, {
          color: f.id === p.selectedField.id ? "#c5f36b" : "#4fae76",
          fillColor: "#4fae76",
          fillOpacity: f.id === p.selectedField.id ? 0.21 : 0.12,
          weight: f.id === p.selectedField.id ? 3 : 2,
          bubblingMouseEvents: false,
        }).addTo(group);
        poly
          .bindTooltip(
            mapTextContent(`${f.name} · ${f.areaHectares.toFixed(1)} ha`),
          )
          .bindPopup(mapPopupContent(f.name, fieldDetails));
        poly.on("click", () => {
          const center = f.boundary?.length
            ? [
                f.boundary.reduce((sum, pt) => sum + pt[0], 0) /
                  f.boundary.length,
                f.boundary.reduce((sum, pt) => sum + pt[1], 0) /
                  f.boundary.length,
              ]
            : [p.currentFarm.latitude, p.currentFarm.longitude];
          p.update((s) => ({
            ...s,
            selectedField: f.id,
            selectedLocation: {
              latitude: center[0],
              longitude: center[1],
              label: `${f.name} · field reference point`,
              method: "field",
              fieldId: f.id,
            },
          }));
        });
      }
    });
    p.store.fields.forEach((f, i) => {
      const coords = f.boundary?.[0] ?? [
        p.currentFarm.latitude + i * 0.01,
        p.currentFarm.longitude + i * 0.01,
      ];
      const marker = L.circleMarker(coords, {
        radius: 8,
        color: "#08130f",
        weight: 2,
        fillColor: "#c5f36b",
        fillOpacity: 1,
        bubblingMouseEvents: false,
      }).addTo(group);
      marker
        .bindTooltip(mapTextContent(f.name))
        .bindPopup(
          mapPopupContent(f.name, [
            p.cropName(f.cropId),
            `${f.areaHectares.toFixed(1)} ha`,
            f.boundary?.length
              ? `Saved outline · ${f.boundary.length} points · planning only`
              : "Demo location based on farm center",
          ]),
        );
      marker.on("click", () => {
        const center = f.boundary?.length
          ? [
              f.boundary.reduce((sum, pt) => sum + pt[0], 0) /
                f.boundary.length,
              f.boundary.reduce((sum, pt) => sum + pt[1], 0) /
                f.boundary.length,
            ]
          : [p.currentFarm.latitude, p.currentFarm.longitude];
        p.update((s) => ({
          ...s,
          selectedField: f.id,
          selectedLocation: {
            latitude: center[0],
            longitude: center[1],
            label: `${f.name} · field reference point`,
            method: "field",
            fieldId: f.id,
          },
        }));
      });
    });
    if (points.length > 0) {
      points.forEach((point, i) => {
        const marker = L.circleMarker(point, {
          radius: 7,
          color: "#f3f7f1",
          fillColor: "#c5f36b",
          fillOpacity: 1,
          bubblingMouseEvents: false,
        }).addTo(group);
        marker
          .bindTooltip(mapTextContent(`Point ${i + 1}`))
          .bindPopup(
            mapPopupContent(`Boundary point ${i + 1}`, [
              `${point[0].toFixed(5)}°, ${point[1].toFixed(5)}°`,
              "Planning outline only · not a legal survey point",
            ]),
          );
      });
      if (points.length > 1)
        L.polyline(points, {
          color: "#c5f36b",
          weight: 3,
          dashArray: "5 6",
        }).addTo(group);
    }
  }, [p.store.fields, p.selectedField.id, p.currentFarm, points, tab]);
  useEffect(() => {
    const map = mapObj.current;
    if (!map || tab !== "map") return;
    const loc = p.selectedLocation;
    const pin = L.circleMarker([loc.latitude, loc.longitude], {
      radius: 7,
      color: "#fff",
      fillColor: "#e6ac55",
      fillOpacity: 1,
      weight: 3,
    })
      .addTo(map)
      .bindTooltip(mapTextContent(`${loc.label} · selected point`));
    if (loc.method !== "map")
      map.setView([loc.latitude, loc.longitude], Math.max(6, map.getZoom()), {
        animate: false,
      });
    return () => {
      map.removeLayer(pin);
    };
  }, [
    p.selectedLocation.latitude,
    p.selectedLocation.longitude,
    p.selectedLocation.label,
    tab,
  ]);
  const saveBoundary = () => {
    const problem = validatePolygon(points);
    if (problem) {
      p.notify(problem);
      return;
    }
    const id = editingFieldId ?? uid();
    const newField: Field = {
      id,
      farmId: p.currentFarm.id,
      name: fieldName.trim().slice(0, 200) || "Untitled field",
      areaHectares: polygonAreaHa(points),
      cropId: p.store.fields.find((f) => f.id === id)?.cropId ?? "wheat",
      boundary: points,
    };
    p.update((s) => ({
      ...s,
      fields: editingFieldId
        ? s.fields.map((f) => (f.id === id ? newField : f))
        : [...s.fields, newField],
      selectedField: id,
      selectedLocation: selection(
        ...fieldCenter(points)!,
        `${newField.name} · field reference point`,
        "field",
        id,
      ),
    }));
    setPoints([]);
    setEditingFieldId(null);
    setEditing(false);
    setShowForm(false);
    p.notify(
      "Field boundary saved locally. It is user-confirmed, not legal survey data.",
    );
  };
  return (
    <>
      <PageHeader
        eyebrow="SPATIAL OPERATIONS / 02"
        title="Field map"
        description="Touch a field to inspect its records, or draw a planning outline."
        action={
          <div className="segmented">
            <button
              className={tab === "map" ? "selected" : ""}
              onClick={() => setTab("map")}
            >
              <MapIcon size={15} />
              2D map
            </button>
            <button
              className={tab === "globe" ? "selected" : ""}
              onClick={() => setTab("globe")}
            >
              <Globe2 size={15} />
              3D globe
            </button>
          </div>
        }
      />
      {tab === "map" ? (
        <div className="map-layout">
          <div className="map-canvas-wrap">
            {tileError && (
              <div className="map-tile-error" role="status">
                Some map tiles could not load. Coordinates, boundaries and point
                selection remain available. Retry by panning or refreshing when
                connected.
              </div>
            )}
            <div
              ref={mapRef}
              className="leaflet-map"
              aria-label="Interactive OpenStreetMap showing farm fields"
            />
            <div className="map-controls">
              <button
                className={editing ? "map-control active" : "map-control"}
                onClick={() => {
                  setEditingFieldId(null);
                  setEditing(!editing);
                  setPoints([]);
                  setShowForm(true);
                }}
              >
                <Plus size={16} />
                {editing ? "Stop drawing" : "Draw boundary"}
              </button>
              {p.selectedField.boundary && (
                <button
                  type="button"
                  className="map-control"
                  onClick={() => {
                    setEditingFieldId(p.selectedField.id);
                    setFieldName(p.selectedField.name);
                    setPoints(p.selectedField.boundary!.map((p) => [...p]));
                    setEditing(true);
                    setShowForm(true);
                  }}
                >
                  Edit outline
                </button>
              )}
              <button
                className="map-control"
                aria-label="Recenter map"
                data-testid="button-recenter-map"
                onClick={() =>
                  mapObj.current?.setView(
                    [p.selectedLocation.latitude, p.selectedLocation.longitude],
                    13,
                  )
                }
              >
                <LocateFixed size={16} />
                Recenter map
              </button>
            </div>
            {editing && (
              <div className="drawing-hint">
                <span className="sync-dot" />
                Tap map to add boundary points <b>{points.length}/3 min</b>
                <button
                  type="button"
                  onClick={() => setPoints((v) => v.slice(0, -1))}
                >
                  Undo point
                </button>
                <button type="button" onClick={() => setPoints([])}>
                  Clear
                </button>
              </div>
            )}
          </div>
          <aside className="map-side panel">
            <div className="panel-head">
              <div>
                <div className="eyebrow">{p.store.fields.length} FIELDS</div>
                <h2>Fields</h2>
              </div>
              <button
                className="icon-btn"
                aria-label="Add field"
                onClick={() => setShowForm(true)}
              >
                <Plus size={18} />
              </button>
            </div>
            <p className="side-note">
              Touch a field shape or marker to select it. Values are
              illustrative planning records, not verified farm measurements.
            </p>
            <div
              className="selected-field-detail"
              data-testid="details-selected-field"
              aria-live="polite"
            >
              <div className="eyebrow">SELECTED AREA · FIELD DETAILS</div>
              <strong>{p.selectedField.name}</strong>
              <span>
                {p.cropName(p.selectedField.cropId)} ·{" "}
                {areaDisplay(
                  p.selectedField.areaHectares,
                  p.store.settings.areaUnit,
                )}{" "}
                {p.store.settings.areaUnit}
              </span>
              <small>
                {p.selectedField.boundary?.length
                  ? `Saved outline · ${p.selectedField.boundary.length} points · planning only`
                  : "No saved boundary for this field"}
              </small>
              <small>
                Soil:{" "}
                {selectedSoil
                  ? `pH ${displayNumber(selectedSoil.ph)} · OM ${displayNumber(selectedSoil.organicMatterPct)}% · moisture ${displayNumber(selectedSoil.moisturePct)}% · nitrogen ${displayNumber(selectedSoil.nitrogenMgKg)} mg/kg · ${selectedSoil.date} · ${selectedSoil.source}`
                  : "No soil record for this field"}
              </small>
              <small>
                Irrigation: {selectedWater.length} records ·{" "}
                {selectedWaterTotal.toFixed(1)} mm total
              </small>
            </div>
            {p.store.fields.map((f) => (
              <button
                className={`field-list-row ${f.id === p.selectedField.id ? "field-selected" : ""}`}
                key={f.id}
                onClick={() => {
                  const center = fieldCenter(f.boundary);
                  p.update((s) => ({
                    ...s,
                    selectedField: f.id,
                    ...(center
                      ? {
                          selectedLocation: selection(
                            ...center,
                            `${f.name} · field reference point`,
                            "field",
                            f.id,
                          ),
                        }
                      : {}),
                  }));
                }}
              >
                <span className="field-square" />
                <span>
                  <strong>{f.name}</strong>
                  <small>{p.cropName(f.cropId)}</small>
                </span>
                <b>
                  {areaDisplay(f.areaHectares, p.store.settings.areaUnit)}
                  <small> {p.store.settings.areaUnit}</small>
                </b>
              </button>
            ))}
            {showForm && (
              <div className="inline-form">
                <label>
                  Field name
                  <input
                    value={fieldName}
                    onChange={(e) => setFieldName(e.target.value)}
                  />
                </label>
                <label>
                  Computed area (ha)
                  <input
                    type="number"
                    min="0.1"
                    step=".1"
                    value={area}
                    readOnly
                    aria-describedby="area-method"
                  />
                </label>
                <p>
                  Use Draw boundary and tap at least three map points before
                  saving.
                </p>
                <div className="form-actions">
                  <Button variant="quiet" onClick={() => setShowForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={saveBoundary}>
                    {editingFieldId ? "Update field" : "Save field"}
                  </Button>
                </div>
              </div>
            )}
            <div className="map-legend">
              <span />
              <p>
                Field outline · planning only{" "}
                <small>OpenStreetMap © contributors</small>
              </p>
            </div>
          </aside>
        </div>
      ) : (
        <GlobeView {...p} />
      )}
    </>
  );
}
function GlobeView(p: PageProps) {
  return (
    <Suspense fallback={<p role="status">Loading Earth explorer…</p>}>
      <GeoGlobe
        location={p.selectedLocation}
        onSelect={(loc) => p.update((s) => ({ ...s, selectedLocation: loc }))}
      />
    </Suspense>
  );
}

function AboutPage({ store }: PageProps) {
  const ar = store.settings.language === "ar";
  const places = [
    {
      id: "alkharj",
      name: ar ? "الخرج" : "Al Kharj",
      lat: "24.1558",
      lon: "47.3120",
      note: ar ? "مرجع محلي" : "Local reference",
    },
    {
      id: "riyadh",
      name: ar ? "الرياض" : "Riyadh",
      lat: "24.7136",
      lon: "46.6753",
      note: ar ? "مرجع إقليمي" : "Regional reference",
    },
    {
      id: "alahsa",
      name: ar ? "واحة الأحساء" : "Al-Ahsa Oasis",
      lat: "25.3835",
      lon: "49.5870",
      note: ar ? "مرجع زراعي" : "Agricultural reference",
    },
  ];
  return (
    <>
      <PageHeader
        eyebrow={ar ? "عن مساحة التعلّم" : "ABOUT THE WORKSPACE"}
        title={ar ? "FieldShift" : "FieldShift"}
        description={
          ar
            ? "مساحة للتخطيط الزراعي والتعلّم، تستند إلى سياق الحقول حول الخرج."
            : "An agricultural planning and learning workspace grounded in the fields around Al Kharj."
        }
      />
      <section className="about-hero panel" data-testid="section-about-intro">
        <div className="about-hero-copy">
          <span className="about-kicker">
            <Info size={14} />
            {ar ? "مشروع تعليمي تجريبي" : "LEARNING / DEMONSTRATION PROJECT"}
          </span>
          <h2>
            {ar
              ? "التخطيط الزراعي يبدأ بفهم المكان."
              : "Agricultural planning starts by understanding place."}
          </h2>
          <p>
            {ar
              ? "يجمع FieldShift أدوات تجريبية لدراسة الطقس والتربة والمياه وتخطيط المحاصيل. البيانات المعروضة توضيحية ومحلية في هذا المتصفح، وليست سجلات مزرعة موثقة."
              : "FieldShift brings together demonstration tools for exploring weather, soil, water, and crop planning. The displayed records are illustrative and browser-local, not verified farm records."}
          </p>
          <p>
            {ar
              ? "تعرّف هذه الصفحة بسياق التعلّم المرتبط بمدارس دنيا الأجيال العالمية. ولا تعني أن المدرسة تملك مزرعة أو تديرها، ولا تدّعي وجود شراكة مؤسسية رسمية."
              : "This page explains the learning context alongside Dunia Al-Ajial International School. It does not claim that the school owns or operates a farm, or that an official institutional partnership exists."}
          </p>
          <div className="about-location">
            <MapPin size={16} />
            <span>
              {ar ? "الموقع" : "LOCATION"}
              <strong>Al Kharj, Riyadh Province, Saudi Arabia</strong>
            </span>
          </div>
        </div>
        <div className="about-hero-image">
          <img
            src="/images/agricultural_field.jpg"
            alt={ar ? "حقل زراعي عند الغروب" : "Agricultural field at sunset"}
            data-testid="img-about-field"
          />
          <span>
            {ar ? "سياق زراعي للتعلّم" : "An agricultural learning context"}
          </span>
        </div>
      </section>
      <section
        className="about-school panel"
        data-testid="section-about-school"
      >
        <div className="school-seal">
          <img
            src="/images/dunia-al-ajial-school.png"
            alt="Dunia Al-Ajial International School seal"
            data-testid="img-school-seal"
          />
        </div>
        <div className="school-copy">
          <div className="eyebrow">
            {ar ? "السياق المدرسي" : "SCHOOL CONTEXT"}
          </div>
          <h2>
            مدارس دنيا الأجيال العالمية
            <br />
            <span>Dunia Al-Ajial International School</span>
          </h2>
          <div className="school-badge">
            {ar ? "بنين وبنات" : "Boys – Girls"}
          </div>
          <p>
            {ar
              ? "اسم المدرسة وعبارة «بنين وبنات» معروضان كما يظهران على الختم المرفق. يظل FieldShift مشروع تعلّم وعرض زراعي، ولا يقدّم ادعاءات إضافية عن المدرسة أو ارتباط رسمي بها."
              : "The school name and “Boys – Girls” wording are shown as they appear on the supplied seal. FieldShift remains an agricultural learning and demo project; no additional institutional facts or formal affiliation are asserted."}
          </p>
        </div>
      </section>
      <section className="about-places">
        <div className="about-places-heading">
          <div>
            <div className="eyebrow">
              {ar ? "استكشف المواقع المرجعية" : "EXPLORE REFERENCE PLACES"}
            </div>
            <h2>
              {ar
                ? "افتح موقعاً على خريطة OpenStreetMap"
                : "Open a place on the OpenStreetMap view"}
            </h2>
          </div>
          <div className="about-places-links">
            <Link
              href="/map?view=globe"
              className="text-link"
              data-testid="link-about-earth"
            >
              {ar ? "عرض الأرض ثلاثية الأبعاد" : "View 3D Earth"}
              <ArrowUpRight size={15} />
            </Link>
            <Link
              href="/map"
              className="text-link"
              data-testid="link-about-map"
            >
              {ar ? "عرض الخريطة" : "Open field map"}
              <ArrowUpRight size={15} />
            </Link>
          </div>
        </div>
        <p className="about-places-note">
          {ar
            ? "هذه علامات مرجعية للمدن والمواقع، وليست مزارع مسجلة."
            : "These are geographic reference markers, not registered farms."}
        </p>
        <div className="about-place-list">
          {places.map((place) => (
            <Link
              key={place.id}
              href={`/map?reference=${place.id}`}
              className="about-place-row"
              data-testid={`link-reference-${place.id}`}
            >
              <span className="about-place-pin">
                <MapPin size={16} />
              </span>
              <span className="about-place-name">
                <strong>{place.name}</strong>
                <small>{place.note}</small>
              </span>
              <span className="about-coordinates">
                {place.lat}
                <br />
                {place.lon}
              </span>
              <ArrowUpRight size={16} />
            </Link>
          ))}
        </div>
      </section>
      <section className="about-footnote">
        <span className="about-footnote-mark">FS</span>
        <p>
          {ar
            ? "بيانات FieldShift التجريبية محفوظة في هذا المتصفح فقط. استخدم إعدادات اللغة للتبديل بين العربية والإنجليزية."
            : "FieldShift demo data is stored in this browser only. Use Settings to switch between English and Arabic."}
        </p>
        <Link
          href="/settings"
          className="btn btn-outline"
          data-testid="link-about-settings"
        >
          <Languages size={15} />
          {ar ? "إعدادات اللغة" : "Language settings"}
        </Link>
      </section>
    </>
  );
}

function WeatherPage(p: PageProps) {
  const coords = p.selectedLocation;
  const {
    data: weather,
    loading,
    error,
    refresh,
  } = useEnvironment(coords, p.store.settings.temperatureUnit);
  const lastUpdated = weather ? new Date(weather.retrievedAt) : null;
  const load = refresh;
  const wmo = (code: number) => {
    const en: Record<number, string> = {
      0: "Clear sky",
      1: "Mainly clear",
      2: "Partly cloudy",
      3: "Overcast",
      45: "Fog",
      48: "Rime fog",
      51: "Light drizzle",
      53: "Moderate drizzle",
      55: "Dense drizzle",
      56: "Freezing drizzle",
      57: "Heavy freezing drizzle",
      61: "Light rain",
      63: "Moderate rain",
      65: "Heavy rain",
      66: "Freezing rain",
      67: "Heavy freezing rain",
      71: "Light snowfall",
      73: "Moderate snowfall",
      75: "Heavy snowfall",
      77: "Snow grains",
      80: "Light rain showers",
      81: "Moderate rain showers",
      82: "Heavy rain showers",
      85: "Light snow showers",
      86: "Heavy snow showers",
      95: "Thunderstorm",
      96: "Thunderstorm with slight hail",
      99: "Thunderstorm with heavy hail",
    };
    const ar: Record<number, string> = {
      0: "سماء صافية",
      1: "صحو غالباً",
      2: "غائم جزئياً",
      3: "غائم",
      45: "ضباب",
      48: "ضباب متجمد",
      51: "رذاذ خفيف",
      53: "رذاذ متوسط",
      55: "رذاذ كثيف",
      56: "رذاذ متجمد",
      57: "رذاذ متجمد كثيف",
      61: "مطر خفيف",
      63: "مطر متوسط",
      65: "مطر غزير",
      66: "مطر متجمد",
      67: "مطر متجمد غزير",
      71: "تساقط ثلوج خفيف",
      73: "تساقط ثلوج متوسط",
      75: "تساقط ثلوج كثيف",
      77: "حبيبات ثلجية",
      80: "زخات مطر خفيفة",
      81: "زخات مطر متوسطة",
      82: "زخات مطر غزيرة",
      85: "زخات ثلج خفيفة",
      86: "زخات ثلج غزيرة",
      95: "عاصفة رعدية",
      96: "عاصفة رعدية مع بَرَد خفيف",
      99: "عاصفة رعدية مع بَرَد كثيف",
    };
    return (
      (p.store.settings.language === "ar" ? ar : en)[code] ??
      (p.store.settings.language === "ar"
        ? "حالة الطقس غير متاحة"
        : "Conditions unavailable")
    );
  };
  const locale = p.store.settings.language === "ar" ? "ar-SA" : "en-SA";
  const currentTempC = weather
    ? temperatureCelsius(
        weather.current.temperature_2m,
        weather.current_units.temperature_2m ?? "°C",
      )
    : 0;
  const updatedTime =
    lastUpdated?.toLocaleTimeString(locale, {
      hour: "2-digit",
      minute: "2-digit",
    }) ?? "—";
  return (
    <>
      <PageHeader
        eyebrow="LIVE CONDITIONS / 03"
        title="Weather"
        description="Current model conditions and seven-day forecast from Open-Meteo for the selected coordinates."
        action={
          <div className="weather-page-actions">
            <Button
              variant="outline"
              onClick={() => void load()}
              data-testid="button-weather-refresh"
            >
              <RotateCcw size={14} />
              Refresh
            </Button>
            <span className="live-badge">
              <span />
              LIVE SOURCE
            </span>
          </div>
        }
      />
      <div className="weather-location panel">
        <div className="location-label">
          <span className="eyebrow">LOCATION FROM MAP / GLOBE</span>
          <strong>{coords.label}</strong>
          <small>
            {formatCoordinates(coords.latitude, coords.longitude)} · Change this
            location in Field map or 3D globe.
          </small>
          <Link href="/map" className="text-link">
            Open map to choose another area <ArrowRight size={14} />
          </Link>
        </div>
      </div>
      {error && (
        <div className="error-panel" role="alert">
          <AlertTriangle size={18} />
          <div>
            <strong>Weather unavailable</strong>
            <p>{error}</p>
            <small>
              No fictional values are substituted. Use Retry when the provider
              is available.
            </small>
          </div>
          <Button variant="outline" onClick={() => void load()}>
            Retry
          </Button>
        </div>
      )}
      {loading && !weather && (
        <div className="weather-skeleton">
          <div />
          <div />
          <div />
        </div>
      )}
      {weather && (
        <>
          <div
            className={`weather-hero panel weather-scene-${weatherScene(weather.current.weather_code)}`}
            data-testid="weather-condition-scene"
            style={{
              backgroundImage: `linear-gradient(90deg,rgba(6,19,20,.74),rgba(6,19,20,.31) 54%,rgba(6,19,20,.06)),url("${weatherScenePhoto(weather.current.weather_code)}")`,
            }}
          >
            <div>
              <div className="eyebrow">
                {p.store.settings.language === "ar"
                  ? "الظروف الحالية"
                  : "CURRENT MODEL CONDITIONS"}{" "}
                · {weather.timezone.replaceAll("_", " ")}
              </div>
              <div className="current-temp">
                {Math.round(weather.current.temperature_2m)}
                <small>{weather.current_units.temperature_2m}</small>
              </div>
              <h2>{wmo(weather.current.weather_code)}</h2>
              <p>
                {p.store.settings.language === "ar"
                  ? "وقت النموذج"
                  : "Model valid at"}{" "}
                {weather.current.time.replace("T", " ")}
              </p>
            </div>
            <div className="weather-sun">
              <WeatherConditionIcon
                code={weather.current.weather_code}
                temperature={currentTempC}
                size={64}
              />
              <span>
                {formatCoordinates(coords.latitude, coords.longitude)}
              </span>
            </div>
            <div className="weather-quick">
              <div>
                <Droplets size={16} />
                <span>
                  {p.store.settings.language === "ar" ? "الرطوبة" : "Humidity"}
                </span>
                <strong>
                  {weather.current.relative_humidity_2m}
                  {weather.current_units.relative_humidity_2m}
                </strong>
              </div>
              <div>
                <Waves size={16} />
                <span>
                  {p.store.settings.language === "ar"
                    ? "الهطول"
                    : "Precipitation"}
                </span>
                <strong>
                  {weather.current.precipitation}{" "}
                  {weather.current_units.precipitation}
                </strong>
              </div>
              <div>
                <Wind size={16} />
                <span>
                  {p.store.settings.language === "ar" ? "الرياح" : "Wind"}
                </span>
                <strong>
                  {weather.current.wind_speed_10m}{" "}
                  {weather.current_units.wind_speed_10m}
                </strong>
              </div>
            </div>
          </div>
          <div className="forecast-heading">
            <div>
              <div className="eyebrow">
                {p.store.settings.language === "ar"
                  ? "التوقعات / خمسة أيام"
                  : "OUTLOOK / SEVEN DAYS"}
              </div>
              <h2>
                {p.store.settings.language === "ar"
                  ? "التوقعات القريبة"
                  : "Near-term forecast"}
              </h2>
            </div>
            <span className="muted-note">
              {p.store.settings.language === "ar"
                ? "الوحدات كما يوفّرها المصدر"
                : "Values in provider units"}
            </span>
          </div>
          <div className="forecast-grid">
            {weather.daily.time.map((day, i) => (
              <article
                className={`forecast-card forecast-scene-${weatherScene(weather.daily.weather_code[i] ?? undefined)}`}
                key={day}
                style={{
                  backgroundImage: `linear-gradient(180deg,#071b2140,#071b21dc),url("${weatherScenePhoto(weather.daily.weather_code[i] ?? undefined)}")`,
                }}
              >
                <small>
                  {new Date(`${day}T12:00:00`).toLocaleDateString(locale, {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                  })}
                </small>
                <WeatherConditionIcon
                  code={weather.daily.weather_code[i] ?? -1}
                  temperature={temperatureCelsius(
                    weather.daily.temperature_2m_max[i] ?? NaN,
                    weather.daily_units.temperature_2m_max ?? "°C",
                  )}
                  size={22}
                />
                <strong>{wmo(weather.daily.weather_code[i] ?? -1)}</strong>
                <div className="forecast-temp">
                  <b>
                    {displayNumber(
                      weather.daily.temperature_2m_max[i] ?? NaN,
                      0,
                    )}
                    {weather.daily_units.temperature_2m_max}
                  </b>{" "}
                  / {displayNumber(weather.daily.temperature_2m_min[i], 0)}
                  {weather.daily_units.temperature_2m_min}
                </div>
                <span>
                  <Droplets size={13} />{" "}
                  {displayNumber(
                    weather.daily.precipitation_probability_max[i],
                    0,
                  )}
                  {weather.daily_units.precipitation_probability_max} ·{" "}
                  {displayNumber(weather.daily.precipitation_sum[i])}{" "}
                  {weather.daily_units.precipitation_sum}
                </span>
              </article>
            ))}
          </div>
          <div className="provenance-note">
            <CircleHelp size={15} />
            <span>
              {p.store.settings.language === "ar"
                ? "المصدر: Open-Meteo · إحداثيات"
                : "Source: Open-Meteo · coordinates"}{" "}
              {coords.latitude.toFixed(4)}, {coords.longitude.toFixed(4)} ·{" "}
              {p.store.settings.language === "ar"
                ? "وقت المصدر"
                : "provider time"}{" "}
              {weather.current.time} ({weather.timezone}) ·{" "}
              {p.store.settings.language === "ar"
                ? "آخر تحديث على هذا الجهاز"
                : "retrieved on this device"}{" "}
              {updatedTime} ·{" "}
              {weather.cached
                ? "Cached response (15-minute freshness window)"
                : "New provider response"}
              .{" "}
              {p.store.settings.language === "ar"
                ? "التوقعات ليست قياسات من محطة داخل الحقل."
                : "Current and forecast values are gridded model output, not field-station measurements. Grid resolution varies by provider model and region; point values do not characterize every part of a field."}
            </span>
          </div>
        </>
      )}
    </>
  );
}

function LiveLandConditions({
  location,
  mode,
}: {
  location: GeoSelection;
  mode: "soil" | "water";
}) {
  const { data, error, loading, refresh } = useEnvironment(location);
  const updated = data ? new Date(data.retrievedAt) : null;
  return (
    <section
      className={`panel live-land-panel ${mode === "soil" ? "live-soil" : "live-water"}`}
    >
      <div className="panel-head">
        <div>
          <div className="eyebrow">LOCATION-SPECIFIC ENVIRONMENT</div>
          <h2>
            {mode === "soil"
              ? "Modeled soil conditions"
              : "Rainfall & atmospheric water demand"}
          </h2>
        </div>
        <span className="live-badge">
          <span />
          OPEN-METEO
        </span>
      </div>
      <p className="panel-intro">
        <strong>{location.label}</strong> ·{" "}
        {formatCoordinates(location.latitude, location.longitude)}. These are
        gridded model estimates, not field sensor readings or laboratory soil
        tests.
      </p>
      {error && (
        <div className="error-panel" role="status">
          <AlertTriangle size={17} />
          <div>
            <strong>Live environmental data unavailable</strong>
            <p>{error}</p>
          </div>
        </div>
      )}
      {loading && (
        <p role="status" className="panel-intro">
          Loading model data for this point…
        </p>
      )}
      {error && (
        <Button variant="outline" onClick={refresh}>
          Retry environmental data
        </Button>
      )}
      {data && (
        <>
          <div className="metric-grid live-land-metrics">
            {mode === "soil" ? (
              <>
                <Metric
                  label="Soil moisture"
                  value={
                    Number.isFinite(data.soilMoisture)
                      ? Number(data.soilMoisture).toFixed(3)
                      : "—"
                  }
                  unit="m³/m³"
                  delta="Modelled top 0–7 cm layer"
                  icon={Droplets}
                  accent="blue"
                />
                <Metric
                  label="Soil temperature"
                  value={
                    Number.isFinite(data.soilTemperature)
                      ? Number(data.soilTemperature).toFixed(1)
                      : "—"
                  }
                  unit="°C"
                  delta="Modelled surface layer"
                  icon={Sun}
                />
                <Metric
                  label="Current precipitation"
                  value={
                    Number.isFinite(data.current?.precipitation)
                      ? String(data.current.precipitation)
                      : "—"
                  }
                  unit="mm"
                  delta="Current model interval"
                  icon={CloudRain}
                  accent="blue"
                />
              </>
            ) : (
              <>
                <Metric
                  label="Current precipitation"
                  value={
                    Number.isFinite(data.current?.precipitation)
                      ? String(data.current.precipitation)
                      : "—"
                  }
                  unit="mm"
                  delta="Current model interval"
                  icon={CloudRain}
                  accent="blue"
                />
                <Metric
                  label="Today rainfall"
                  value={
                    Number.isFinite(data.daily?.precipitation_sum?.[0])
                      ? Number(data.daily.precipitation_sum[0]).toFixed(1)
                      : "—"
                  }
                  unit="mm"
                  delta="Forecast total"
                  icon={Waves}
                  accent="blue"
                />
                <Metric
                  label="Reference ET₀"
                  value={
                    Number.isFinite(data.daily?.et0_fao_evapotranspiration?.[0])
                      ? Number(
                          data.daily.et0_fao_evapotranspiration[0],
                        ).toFixed(1)
                      : "—"
                  }
                  unit="mm"
                  delta="Forecast reference evapotranspiration"
                  icon={Sun}
                  accent="gold"
                />
              </>
            )}
          </div>
          <div className="provenance-note">
            <Info size={15} />
            <span>
              Source: Open-Meteo forecast API · model output for selected
              coordinates · provider time{" "}
              {mode === "soil"
                ? (data.soilTime ?? "unavailable")
                : data.current.time}{" "}
              · retrieved on this device {updated?.toLocaleTimeString() ?? "—"}.
              {data.cached ? "Cached response (15-minute window). " : ""}Grid
              resolution varies by model and region. Soil values are hourly
              estimates; these do not replace soil tests, local gauges or
              irrigation-system measurements.
            </span>
          </div>
        </>
      )}
    </section>
  );
}
function SoilPage(p: PageProps) {
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    ph: "",
    organicMatterPct: "",
    moisturePct: "",
    nitrogenMgKg: "",
    notes: "",
    samplingDepthCm: "",
    method: "",
    reference: "",
  });
  const [editId, setEditId] = useState("");
  const [filter, setFilter] = useState(p.selectedField.id);
  const rows = p.store.soils
    .filter((s) => filter === "all" || s.fieldId === filter)
    .sort((a, b) => b.date.localeCompare(a.date));
  const reset = () => {
    setEditId("");
    setForm({
      date: new Date().toISOString().slice(0, 10),
      ph: "",
      organicMatterPct: "",
      moisturePct: "",
      nitrogenMgKg: "",
      notes: "",
      samplingDepthCm: "",
      method: "",
      reference: "",
    });
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    let candidate;
    try {
      const depth = optionalMeasurement(form.samplingDepthCm);
      candidate = {
        id: editId || uid(),
        fieldId: filter === "all" ? p.selectedField.id : filter,
        date: form.date,
        ph: optionalMeasurement(form.ph),
        organicMatterPct: optionalMeasurement(form.organicMatterPct),
        moisturePct: optionalMeasurement(form.moisturePct),
        nitrogenMgKg: optionalMeasurement(form.nitrogenMgKg),
        source: "Entered",
        inputMethod: "manual" as const,
        notes: form.notes,
        method: form.method.trim(),
        reference: form.reference.trim(),
        ...(depth === null ? {} : { samplingDepthCm: depth }),
      };
    } catch (error) {
      p.notify(error instanceof Error ? error.message : "Invalid measurement.");
      return;
    }
    const parsed = soilObservationSchema.safeParse(candidate);
    if (!parsed.success) {
      p.notify(parsed.error.issues.map((i) => i.message).join(" "));
      return;
    }
    const item = parsed.data;
    p.update((s) => ({
      ...s,
      soils: editId
        ? s.soils.map((x) => (x.id === editId ? item : x))
        : [item, ...s.soils],
    }));
    p.notify(
      editId
        ? "Soil observation updated."
        : "Soil observation saved as entered.",
    );
    reset();
  };
  return (
    <>
      <PageHeader
        eyebrow="FIELD RECORDS / 04"
        title="Soil observations"
        description="Capture lab results and field observations. Demo values stay separate from your entered tests."
        action={
          <SelectField
            label="FIELD"
            value={filter}
            onChange={(v) => {
              reset();
              setFilter(v);
              if (v !== "all") p.update((s) => ({ ...s, selectedField: v }));
            }}
            options={[
              { value: "all", label: "All fields" },
              ...p.store.fields.map((f) => ({ value: f.id, label: f.name })),
            ]}
            testId="select-soil-field"
          />
        }
      />
      <TopicPhoto
        id="soil"
        src="/images/forest_soil.jpg"
        alt="Forest floor with trees and undergrowth"
        label="SOIL / FIELD ECOLOGY"
        title="Healthy ground supports every crop"
        copy="Forest imagery is thematic; soil readings remain user-entered or clearly labeled demo observations."
      />
      <LiveLandConditions location={p.selectedLocation} mode="soil" />
      <SoilCsvImport
        fieldId={filter === "all" ? p.selectedField.id : filter}
        fieldName={p.fieldName(filter === "all" ? p.selectedField.id : filter)}
        existing={p.store.soils}
        onImport={(rows, targetId) => {
          if (!p.store.fields.some((f) => f.id === targetId)) {
            p.notify(
              "The destination field is no longer available. Choose the CSV again.",
            );
            return;
          }
          p.update((s) => {
            const known = new Set(s.soils.map(soilFingerprint));
            const additions = rows.filter((row) => {
              const fingerprint = soilFingerprint(row);
              if (row.fieldId !== targetId || known.has(fingerprint))
                return false;
              known.add(fingerprint);
              return true;
            });
            return { ...s, soils: [...additions, ...s.soils] };
          });
          p.notify(
            "Validated CSV samples saved as user-entered records in the selected field.",
          );
        }}
      />
      <div className="soil-layout">
        <section className="panel entry-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">
                {editId ? "EDIT RECORD" : "NEW RECORD"}
              </div>
              <h2>{editId ? "Update observation" : "Enter soil test"}</h2>
            </div>
            <Sprout size={19} className="muted-icon" />
          </div>
          <div className="entry-disclaimer">
            Enter only measured values; leave unknown properties blank. At least
            one measurement is required. Check units against the lab report
            before saving.
          </div>
          <form onSubmit={submit} className="soil-form">
            <label>
              Date
              <input
                required
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </label>
            <label>
              Soil pH
              <input
                type="number"
                step=".1"
                min="0"
                max="14"
                value={form.ph}
                onChange={(e) => setForm({ ...form, ph: e.target.value })}
              />
            </label>
            <label>
              Organic matter <small>%</small>
              <input
                type="number"
                step=".1"
                min="0"
                value={form.organicMatterPct}
                onChange={(e) =>
                  setForm({ ...form, organicMatterPct: e.target.value })
                }
              />
            </label>
            <label>
              Moisture <small>%</small>
              <input
                type="number"
                step="1"
                min="0"
                max="100"
                value={form.moisturePct}
                onChange={(e) =>
                  setForm({ ...form, moisturePct: e.target.value })
                }
              />
            </label>
            <label>
              Nitrogen <small>mg/kg</small>
              <input
                type="number"
                step="1"
                min="0"
                value={form.nitrogenMgKg}
                onChange={(e) =>
                  setForm({ ...form, nitrogenMgKg: e.target.value })
                }
              />
            </label>
            <label>
              Sampling depth (cm)
              <input
                type="number"
                min="0"
                max="300"
                step=".1"
                value={form.samplingDepthCm}
                onChange={(e) =>
                  setForm({ ...form, samplingDepthCm: e.target.value })
                }
              />
            </label>
            <label>
              Sampling / lab method
              <input
                value={form.method}
                maxLength={200}
                onChange={(e) => setForm({ ...form, method: e.target.value })}
                placeholder="Unknown if not supplied"
              />
            </label>
            <label className="wide-label">
              Lab report / provenance reference
              <input
                value={form.reference}
                maxLength={300}
                onChange={(e) =>
                  setForm({ ...form, reference: e.target.value })
                }
              />
            </label>
            <label className="wide-label">
              Notes
              <textarea
                rows={3}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Method, depth, lab reference…"
              />
            </label>
            <div className="form-actions wide-label">
              <Button type="submit" onClick={() => {}}>
                Save observation
              </Button>
              {editId && (
                <Button variant="quiet" onClick={reset}>
                  Cancel
                </Button>
              )}
            </div>
          </form>
        </section>
        <section className="panel history-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">OBSERVATION LOG</div>
              <h2>{rows.length} records</h2>
            </div>
            <span className="pill">Browser saved</span>
          </div>
          {rows.length === 0 ? (
            <EmptyState
              title="No observations yet"
              copy="Add an entered soil test to start the record."
            />
          ) : (
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Date / field</th>
                    <th>pH</th>
                    <th>OM %</th>
                    <th>Moisture</th>
                    <th>N mg/kg</th>
                    <th>Source</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.id}>
                      <td>
                        <strong>{row.date}</strong>
                        <small>{p.fieldName(row.fieldId)}</small>
                        <small>
                          Depth: {row.samplingDepthCm ?? "unknown"} cm ·{" "}
                          {row.method || "method unknown"} ·{" "}
                          {row.reference || "no lab reference"}
                          {row.importFile ? ` · CSV: ${row.importFile}` : ""}
                        </small>
                      </td>
                      <td>{displayNumber(row.ph)}</td>
                      <td>{displayNumber(row.organicMatterPct)}</td>
                      <td>{displayNumber(row.moisturePct)}%</td>
                      <td>{displayNumber(row.nitrogenMgKg)}</td>
                      <td>
                        <span
                          className={
                            row.source === "Entered"
                              ? "pill pill-entry"
                              : "pill"
                          }
                        >
                          {row.source === "Entered"
                            ? row.inputMethod === "csv"
                              ? "Entered (CSV)"
                              : "Entered"
                            : "Demo assumption"}
                        </span>
                      </td>
                      <td>
                        <button
                          className="icon-btn small"
                          aria-label={`Edit observation ${row.date}`}
                          onClick={() => {
                            setEditId(row.id);
                            setFilter(row.fieldId);
                            setForm({
                              date: row.date,
                              ph: String(row.ph ?? ""),
                              organicMatterPct: String(
                                row.organicMatterPct ?? "",
                              ),
                              moisturePct: String(row.moisturePct ?? ""),
                              nitrogenMgKg: String(row.nitrogenMgKg ?? ""),
                              notes: row.notes,
                              samplingDepthCm: String(
                                row.samplingDepthCm ?? "",
                              ),
                              method: row.method ?? "",
                              reference: row.reference ?? "",
                            });
                          }}
                        >
                          Edit
                        </button>
                        <button
                          className="icon-btn small danger-text"
                          aria-label={`Delete soil observation ${row.date}`}
                          onClick={() => {
                            if (
                              window.confirm("Delete this soil observation?")
                            ) {
                              p.update((s) => ({
                                ...s,
                                soils: s.soils.filter((x) => x.id !== row.id),
                              }));
                              p.notify("Soil observation deleted.");
                            }
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </>
  );
}
function CropsPage(p: PageProps) {
  const [weights, setWeights] = useState({
    soil: 35,
    water: 30,
    diversity: 20,
    risk: 15,
  });
  const planField = p.selectedField.id;
  const setPlanField = (v: string) =>
    p.update((s) => ({ ...s, selectedField: v }));
  const [year, setYear] = useState(new Date().getFullYear());
  const [cropId, setCropId] = useState("chickpea");
  const [waterBudget, setWaterBudget] = useState("");
  const enteredSoil =
    p.selectedLocation.fieldId === planField
      ? p.store.soils
          .filter(
            (s) =>
              s.fieldId === planField &&
              s.source === "Entered" &&
              s.ph !== null,
          )
          .sort((a, b) => b.date.localeCompare(a.date))[0]
      : undefined;
  const previous =
    p.store.plans
      .filter((pl) => pl.fieldId === planField)
      .flatMap((pl) => pl.seasons)
      .filter((v) => v.year < year)
      .sort((a, b) => b.year - a.year)[0]?.cropId ?? p.selectedField.cropId;
  const budgetError =
    waterBudget.trim() !== "" &&
    (!Number.isFinite(Number(waterBudget)) ||
      Number(waterBudget) < 0 ||
      Number(waterBudget) > 10000);
  const ranking = useMemo(
    () =>
      budgetError
        ? []
        : rankCrops(cropLibrary, weights, {
            ph: enteredSoil?.ph ?? null,
            waterBudgetMm:
              waterBudget.trim() === "" ? null : Number(waterBudget),
            previousCropId: previous,
          }),
    [weights, enteredSoil?.ph, waterBudget, previous, budgetError],
  );
  const plans = p.store.plans.filter((a) => a.fieldId === planField);
  const addSeason = () => {
    const existing = p.store.plans.find((a) => a.fieldId === planField);
    if (existing) {
      if (existing.seasons.some((s) => s.year === year)) {
        p.notify(`${year} already has a planned crop.`);
        return;
      }
      p.update((s) => ({
        ...s,
        plans: s.plans.map((pl) =>
          pl.id === existing.id
            ? {
                ...pl,
                seasons: [...pl.seasons, { year, cropId }].sort(
                  (a, b) => a.year - b.year,
                ),
              }
            : pl,
        ),
      }));
    } else
      p.update((s) => ({
        ...s,
        plans: [
          ...s.plans,
          {
            id: uid(),
            fieldId: planField,
            name: `${p.fieldName(planField)} rotation`,
            seasons: [{ year, cropId }],
          },
        ],
      }));
    const warnings = rotationWarnings([
      ...(existing?.seasons ?? []),
      { year, cropId },
    ]);
    p.notify(
      warnings.length
        ? warnings.join(" ")
        : `Season ${year} added to rotation.`,
    );
  };
  const removeSeason = (id: string, yr: number) => {
    if (window.confirm(`Remove the ${yr} season from this rotation?`))
      p.update((s) => ({
        ...s,
        plans: s.plans.flatMap((pl) =>
          pl.id !== id
            ? [pl]
            : pl.seasons.length <= 1
              ? []
              : [{ ...pl, seasons: pl.seasons.filter((x) => x.year !== yr) }],
        ),
      }));
  };
  const getFactor = (crop: Crop) => [
    {
      name: "Soil fit",
      value: crop.soilScore,
      weight: weights.soil,
      color: "lime",
    },
    {
      name: "Water fit",
      value: crop.waterScore,
      weight: weights.water,
      color: "blue",
    },
    {
      name: "Rotation diversity",
      value: crop.diversityScore,
      weight: weights.diversity,
      color: "green",
    },
    {
      name: "Risk resilience",
      value: crop.riskScore,
      weight: weights.risk,
      color: "gold",
    },
  ];
  return (
    <>
      <PageHeader
        eyebrow="DECISION SUPPORT / 05"
        title="Crop planner"
        description="Compare crop suitability with transparent, adjustable priorities. Scores are planning estimates—not yield guarantees."
        action={
          <SelectField
            label="FIELD"
            value={planField}
            onChange={(v) => {
              setPlanField(v);
              p.update((s) => ({ ...s, selectedField: v }));
            }}
            options={p.store.fields.map((f) => ({
              value: f.id,
              label: f.name,
            }))}
            testId="select-plan-field"
          />
        }
      />
      <div className="data-callout">
        <Info size={17} />
        <span>
          Planning context: {p.selectedLocation.label}. Field records:{" "}
          {p.fieldName(planField)}.{" "}
          {enteredSoil
            ? `Entered pH from ${enteredSoil.date}.`
            : "No entered soil test linked to this selected point."}{" "}
          AI, satellite analysis and locally calibrated suitability models are
          not connected.
        </span>
      </div>
      <ForecastScreening location={p.selectedLocation} />
      <div className="crop-layout">
        <section className="panel ranking-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">WEIGHTED SUITABILITY</div>
              <h2>Recommended order</h2>
            </div>
            <span className="estimate-tag">ESTIMATE</span>
          </div>
          <p className="panel-intro">
            Adjust what matters for this season. Each slider directly changes
            the ranking below.
          </p>
          <label className="planning-water-input">
            Optional seasonal water-budget scenario (mm)
            <input
              type="number"
              min="0"
              max="10000"
              step="1"
              value={waterBudget}
              onChange={(e) => setWaterBudget(e.target.value)}
              placeholder="Unknown — leave blank"
            />
          </label>
          <p className="panel-intro">
            Blank means unknown. Zero means no water in your scenario.
            References and risk factors below are illustrative, not regionally
            validated.
          </p>
          <div className="weight-grid">
            {Object.entries(weights).map(([k, v]) => (
              <label className="weight-control" key={k}>
                <span>
                  {k === "soil"
                    ? "Soil fit"
                    : k === "water"
                      ? "Water fit"
                      : k === "diversity"
                        ? "Rotation diversity"
                        : "Risk resilience"}{" "}
                  <b>{v}%</b>
                </span>
                <input
                  aria-label={`${k} priority weight`}
                  type="range"
                  min="0"
                  max="100"
                  value={v}
                  onChange={(e) =>
                    setWeights({ ...weights, [k]: Number(e.target.value) })
                  }
                />
              </label>
            ))}
          </div>
          {ranking.length === 0 && (
            <p role="status">
              {budgetError
                ? "Enter a water-budget scenario between 0 and 10,000 mm."
                : "Set at least one priority above zero to compare crops."}
            </p>
          )}
          {ranking.slice(0, 6).map((crop, i) => (
            <article
              className={`rank-row ${i === 0 ? "rank-top" : ""}`}
              key={crop.id}
            >
              <span className="rank-num">{String(i + 1).padStart(2, "0")}</span>
              <div className="rank-title">
                <strong>{crop.name}</strong>
                <small>
                  {crop.category} · {crop.seasonDays} days · {crop.waterNeedMm}{" "}
                  mm seasonal need
                </small>
              </div>
              <div className="rank-score">
                <b>{crop.score.toFixed(0)}</b>
                <small>weighted / 100</small>
              </div>
              <details className="factor-details">
                <summary aria-label={`Show factor breakdown for ${crop.name}`}>
                  Factors
                </summary>
                <div className="factor-pop">
                  {getFactor(crop).map((f) => (
                    <div key={f.name}>
                      <span>{f.name}</span>
                      <b>{f.value}</b>
                      <small>× {f.weight}%</small>
                    </div>
                  ))}
                  <p>
                    Score = sum(factor score × priority weight) ÷ total weight.
                    Sliders are relative weights and are normalized by their
                    total.
                  </p>
                  <strong>{crop.evidence}</strong>
                  <ul>
                    {crop.reasons.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                </div>
              </details>
            </article>
          ))}
        </section>
        <aside className="panel crop-assumptions">
          <div className="eyebrow">CROP LIBRARY</div>
          <h2>Rotation, year by year</h2>
          <p>
            Season lengths, costs, yields, water needs and fit factors are
            illustrative, uncalibrated assumptions. Verify locally. Currency
            conversion uses a fixed 3.75 SAR/USD scenario, not live exchange
            rates.
          </p>
          <div className="planner-inputs">
            <SelectField
              label="PLANNED YEAR"
              value={String(year)}
              onChange={(v) => setYear(Number(v))}
              options={Array.from(
                { length: 10 },
                (_, i) => new Date().getFullYear() - 1 + i,
              ).map((y) => ({
                value: String(y),
                label: String(y),
              }))}
              testId="select-plan-year"
            />
            <SelectField
              label="CROP"
              value={cropId}
              onChange={setCropId}
              options={cropLibrary.map((c) => ({ value: c.id, label: c.name }))}
              testId="select-plan-crop"
            />
            <Button onClick={addSeason}>
              <Plus size={16} />
              Add season
            </Button>
          </div>
          <div className="rotation-screening" role="status">
            {rotationWarnings(plans.flatMap((pl) => pl.seasons)).map((w) => (
              <p key={w}>{w}</p>
            ))}
          </div>
          <div className="rotation-list">
            {plans.flatMap((pl) =>
              pl.seasons.map((season) => (
                <div className="rotation-item" key={`${pl.id}-${season.year}`}>
                  <div className="rotation-year">{season.year}</div>
                  <div>
                    <strong>{p.cropName(season.cropId)}</strong>
                    <small>
                      {
                        cropLibrary.find((c) => c.id === season.cropId)
                          ?.category
                      }{" "}
                      · planned
                    </small>
                  </div>
                  <button
                    className="icon-btn small"
                    aria-label={`Delete rotation crop ${season.year}`}
                    onClick={() => removeSeason(pl.id, season.year)}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )),
            )}
            {plans.length === 0 && (
              <div className="subtle-empty">
                No rotation plan for this field yet.
              </div>
            )}
          </div>
          <div className="crop-catalog">
            <div className="eyebrow">LIBRARY / {cropLibrary.length} CROPS</div>
            {cropLibrary.map((c) => (
              <details key={c.id} className="crop-detail">
                <summary>
                  <span>{c.name}</span>
                  <small>
                    {c.category} · {cropFamily(c.id)}
                  </small>
                </summary>
                <div className="crop-detail-copy">
                  <span>
                    {c.phMin}–{c.phMax} pH
                  </span>
                  <span>
                    {c.nitrogenFixing ? "Nitrogen-fixing" : "Non-fixing"}
                  </span>
                  <span>
                    Yield {c.yieldTonnesHa} t/ha ·{" "}
                    {moneyDisplay(c.costSarHa, p.store.settings.currency)}/ha
                  </span>
                  <em>{c.assumptionLabel}</em>
                </div>
              </details>
            ))}
          </div>
        </aside>
      </div>
    </>
  );
}
function WaterPage(p: PageProps) {
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    depthMm: "20",
    method: "Center pivot",
    notes: "",
  });
  const [mode, setMode] = useState<"mm" | "m3">(p.store.settings.waterUnit);
  const fieldId = p.selectedField.id;
  const setFieldId = (v: string) =>
    p.update((s) => ({ ...s, selectedField: v }));
  const field = p.store.fields.find((f) => f.id === fieldId) ?? p.selectedField;
  const events = p.store.irrigation
    .filter((e) => e.fieldId === fieldId)
    .sort((a, b) => b.date.localeCompare(a.date));
  const applied = events.reduce((a, e) => a + e.depthMm, 0);
  const crop = cropLibrary.find((c) => c.id === field.cropId);
  const estimatedNet = Math.max(0, (crop?.waterNeedMm ?? 0) - applied);
  const rain = null;
  const balanceKnown = events.length > 0;
  const add = (e: FormEvent) => {
    e.preventDefault();
    const depth = Number(form.depthMm);
    if (
      !Number.isFinite(depth) ||
      depth <= 0 ||
      depth > 1000 ||
      form.date > new Date().toISOString().slice(0, 10)
    ) {
      p.notify(
        "Enter a valid past/current date and applied depth between 0 and 1000 mm.",
      );
      return;
    }
    const event: IrrigationEvent = {
      id: uid(),
      fieldId,
      date: form.date,
      depthMm: depth,
      volumeM3: Number((depth * field.areaHectares * 10).toFixed(1)),
      method: form.method,
      notes: form.notes,
    };
    p.update((s) => ({ ...s, irrigation: [event, ...s.irrigation] }));
    p.notify("Irrigation record saved locally.");
    setForm({ ...form, depthMm: "", notes: "" });
  };
  const conversion = (mm: number) =>
    mode === "mm"
      ? `${mm.toFixed(1)} mm`
      : `${(mm * field.areaHectares * 10).toLocaleString(undefined, { maximumFractionDigits: 0 })} m³`;
  return (
    <>
      <PageHeader
        eyebrow="WATER OPERATIONS / 06"
        title="Irrigation & water"
        description="Log irrigation and inspect a simplified, transparent seasonal balance."
        action={
          <SelectField
            label="FIELD"
            value={fieldId}
            onChange={(v) => {
              setFieldId(v);
              p.update((s) => ({ ...s, selectedField: v }));
            }}
            options={p.store.fields.map((f) => ({
              value: f.id,
              label: f.name,
            }))}
            testId="select-water-field"
          />
        }
      />
      <LiveLandConditions location={p.selectedLocation} mode="water" />
      <div className="metric-grid water-metrics">
        <Metric
          label="Logged irrigation"
          value={conversion(applied)}
          delta={`${events.length} saved records`}
          icon={Droplets}
          accent="blue"
        />
        <Metric
          label="Crop reference"
          value={`${crop?.waterNeedMm ?? "—"}`}
          unit="mm"
          delta={crop?.assumptionLabel ?? "No crop assigned"}
          icon={Leaf}
        />
        <Metric
          label="Reference minus logged depth"
          value={conversion(estimatedNet)}
          delta="Reference − logged irrigation"
          icon={Waves}
          accent="gold"
        />
        <Metric
          label="Field area"
          value={areaDisplay(field.areaHectares, p.store.settings.areaUnit)}
          unit={p.store.settings.areaUnit}
          delta="User-entered / demo boundary"
          icon={MapIcon}
          accent="green"
        />
      </div>
      <div className="water-layout">
        <section className="panel water-balance">
          <div className="panel-head">
            <div>
              <div className="eyebrow">SIMPLIFIED WATER BALANCE</div>
              <h2>Seasonal reference</h2>
            </div>
            <SelectField
              label="DISPLAY UNITS"
              value={mode}
              onChange={(v) => setMode(v as "mm" | "m3")}
              options={[
                { value: "mm", label: "Millimeters" },
                { value: "m3", label: "Cubic meters" },
              ]}
              testId="select-water-units"
            />
          </div>
          <div className="balance-visual">
            <div className="balance-bar">
              <span
                style={{
                  width: `${Math.min(100, (applied / Math.max(crop?.waterNeedMm ?? 1, 1)) * 100)}%`,
                }}
              />
            </div>
            <div className="balance-legend">
              <span>
                <i className="key-applied" />
                Irrigation {conversion(applied)}
              </span>
              <span>
                <i className="key-need" />
                Crop reference {conversion(crop?.waterNeedMm ?? 0)}
              </span>
            </div>
          </div>
          <div className="formula-box">
            <strong>Estimate formula</strong>
            <p>
              Scenario difference = max(0, illustrative crop reference − all
              logged irrigation). Records can span multiple years; this is not a
              seasonal water balance. Unknown rainfall is not treated as zero.
            </p>
            <code>
              {crop?.waterNeedMm ?? "missing crop"} − {applied} = {estimatedNet}{" "}
              mm · rainfall unknown
            </code>
            <small>
              Missing: measured rainfall, effective precipitation, soil storage,
              irrigation efficiency, crop stage and evapotranspiration. This is
              not an irrigation prescription.
            </small>
          </div>
        </section>
        <section className="panel irrigation-form">
          <div className="eyebrow">NEW IRRIGATION EVENT</div>
          <h2>Log application</h2>
          <form onSubmit={add} className="form-stack">
            <label>
              Date
              <input
                type="date"
                required
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </label>
            <label>
              Applied depth <small>mm</small>
              <input
                type="number"
                min="0.1"
                step=".1"
                required
                value={form.depthMm}
                onChange={(e) => setForm({ ...form, depthMm: e.target.value })}
              />
            </label>
            <label>
              Method
              <select
                value={form.method}
                onChange={(e) => setForm({ ...form, method: e.target.value })}
              >
                <option>Center pivot</option>
                <option>Drip</option>
                <option>Sprinkler</option>
                <option>Flood</option>
                <option>Other</option>
              </select>
            </label>
            <label>
              Notes
              <input
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Optional"
              />
            </label>
            <div className="volume-preview">
              Volume estimate{" "}
              <strong>
                {(
                  Number(form.depthMm || 0) *
                  field.areaHectares *
                  10
                ).toLocaleString(undefined, { maximumFractionDigits: 0 })}{" "}
                m³
              </strong>
              <small>depth mm × area ha × 10</small>
            </div>
            <Button type="submit">Save irrigation</Button>
          </form>
        </section>
      </div>
      <section className="panel water-history">
        <div className="panel-head">
          <div>
            <div className="eyebrow">RECORDS</div>
            <h2>Irrigation history</h2>
          </div>
        </div>
        {events.length === 0 ? (
          <EmptyState
            title="No irrigation events"
            copy="Log a new application to build a field record."
          />
        ) : (
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Depth</th>
                  <th>Volume</th>
                  <th>Method</th>
                  <th>Notes</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.id}>
                    <td>{e.date}</td>
                    <td>{e.depthMm} mm</td>
                    <td>{e.volumeM3.toLocaleString()} m³</td>
                    <td>{e.method}</td>
                    <td>{e.notes || "—"}</td>
                    <td>
                      <button
                        className="icon-btn small danger-text"
                        aria-label={`Delete irrigation ${e.date}`}
                        onClick={() => {
                          if (
                            window.confirm("Delete this irrigation record?")
                          ) {
                            p.update((s) => ({
                              ...s,
                              irrigation: s.irrigation.filter(
                                (i) => i.id !== e.id,
                              ),
                            }));
                            p.notify("Irrigation record deleted.");
                          }
                        }}
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
function Bars({ values, labels }: { values: number[]; labels: string[] }) {
  const max = Math.max(1, ...values);
  return (
    <div
      className="chart-bars"
      role="img"
      aria-label="Bar chart of recorded field values"
    >
      {values.map((v, i) => (
        <div className="chart-col" key={`${labels[i]}-${i}`}>
          <div className="bar-track">
            <div style={{ height: `${Math.max(3, (v / max) * 100)}%` }} />
          </div>
          <b>{v}</b>
          <small>{labels[i]}</small>
        </div>
      ))}
    </div>
  );
}
function AnalyticsPage(p: PageProps) {
  const [metric, setMetric] = useState<"water" | "soil">("water");
  const records =
    metric === "water"
      ? p.store.irrigation
          .filter((e) => e.fieldId === p.selectedField.id)
          .map((e) => ({
            date: e.date,
            value: e.depthMm,
            source: "Irrigation record",
          }))
      : p.store.soils
          .filter((e) => e.fieldId === p.selectedField.id && e.ph !== null)
          .map((s) => ({
            date: s.date,
            value: s.ph!,
            source: s.source,
          }));
  const sorted = records.sort((a, b) => a.date.localeCompare(b.date));
  const labels = sorted.map((v) =>
    new Date(`${v.date}T12:00:00`).toLocaleDateString("en", {
      month: "short",
      day: "numeric",
    }),
  );
  const values = sorted.map((v) => v.value);
  const sample = [24, 22, 27, 19, 23, 26, 21, 25];
  const sampleLabels = ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"];
  return (
    <>
      <PageHeader
        eyebrow="FIELD INTELLIGENCE / 08"
        title="Analytics"
        description="Charts are built from saved observations, recorded irrigation, or fixed labeled demo history."
        action={
          <SelectField
            label="FIELD"
            value={p.selectedField.id}
            onChange={(v) => p.update((s) => ({ ...s, selectedField: v }))}
            options={p.store.fields.map((f) => ({
              value: f.id,
              label: f.name,
            }))}
            testId="select-analytics-field"
          />
        }
      />
      <div className="analytics-grid">
        <section className="panel chart-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">RETRIEVED RECORDS</div>
              <h2>
                {metric === "water"
                  ? "Irrigation applied"
                  : "Soil pH observations"}
              </h2>
            </div>
            <select
              value={metric}
              onChange={(e) => setMetric(e.target.value as "water" | "soil")}
              aria-label="Choose chart metric"
            >
              <option value="water">Irrigation depth</option>
              <option value="soil">Soil pH</option>
            </select>
          </div>
          <p className="panel-intro">
            Selected field · {p.selectedField.name} · {records.length} local
            records
          </p>
          {values.length ? (
            <>
              <Bars values={values} labels={labels} />
              <div className="chart-caption">
                Source data: saved{" "}
                {metric === "water" ? "irrigation events" : "soil observations"}
                . {metric === "water" ? "Depth in mm per event." : "pH scale."}
              </div>
            </>
          ) : (
            <EmptyState
              title="No records to chart"
              copy={`Add ${metric === "water" ? "irrigation" : "soil"} records to see a field trend.`}
            />
          )}
        </section>
        <section className="panel chart-panel">
          <div className="panel-head">
            <div>
              <div className="eyebrow">FIXED DEMO SERIES</div>
              <h2>Illustrative soil moisture</h2>
            </div>
            <span className="pill">Demo history</span>
          </div>
          <p className="panel-intro">
            Deterministic sample series included for layout exploration. Not
            sensor readings or live observations.
          </p>
          <Bars values={sample} labels={sampleLabels} />
          <div className="chart-caption">
            Illustrative relative index · 8 fixed sample points · no forecast
            inference.
          </div>
        </section>
      </div>
      <section className="panel analytics-table">
        <div className="panel-head">
          <div>
            <div className="eyebrow">DATA TRACEABILITY</div>
            <h2>Values behind the view</h2>
          </div>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Observation</th>
                <th>Value</th>
                <th>Source</th>
                <th>Field</th>
              </tr>
            </thead>
            <tbody>
              {[
                ...p.store.irrigation
                  .filter((e) => e.fieldId === p.selectedField.id)
                  .map((e) => ({
                    date: e.date,
                    value: `${e.depthMm} mm`,
                    source: "Entered/demo record",
                    field: e.fieldId,
                  })),
                ...p.store.soils
                  .filter((e) => e.fieldId === p.selectedField.id)
                  .map((s) => ({
                    date: s.date,
                    value: `pH ${displayNumber(s.ph)}`,
                    source: s.source,
                    field: s.fieldId,
                  })),
              ]
                .sort((a, b) => b.date.localeCompare(a.date))
                .map((x, i) => (
                  <tr key={`${x.date}-${i}`}>
                    <td>{x.date}</td>
                    <td>{x.value}</td>
                    <td>{x.source}</td>
                    <td>{p.fieldName(x.field)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
function ReportsPage(p: PageProps) {
  const fieldId = p.selectedField.id;
  const setFieldId = (v: string) =>
    p.update((s) => ({ ...s, selectedField: v }));
  const [include, setInclude] = useState({
    soil: true,
    water: true,
    rotation: true,
  });
  const field = p.store.fields.find((f) => f.id === fieldId) ?? p.selectedField;
  const soil = p.store.soils.filter((s) => s.fieldId === fieldId);
  const irrigation = p.store.irrigation.filter((e) => e.fieldId === fieldId);
  const plan = p.store.plans.find((a) => a.fieldId === fieldId);
  const sections = [
    include.soil && {
      title: "Soil observations",
      rows: soil.map(
        (s) =>
          `${s.date} · pH ${displayNumber(s.ph)} · organic matter ${displayNumber(s.organicMatterPct)}% · moisture ${displayNumber(s.moisturePct)}% · nitrogen ${displayNumber(s.nitrogenMgKg)} mg/kg · depth ${s.samplingDepthCm ?? "unknown"} cm · method ${s.method || "unknown"} · reference ${s.reference || "not supplied"} · ${s.source}${s.inputMethod === "csv" ? ` (CSV: ${s.importFile ?? "imported file"})` : ""}`,
      ),
    },
    include.water && {
      title: "Irrigation records",
      rows: irrigation.map(
        (e) => `${e.date} · ${e.depthMm} mm · ${e.volumeM3} m³ · ${e.method}`,
      ),
    },
    include.rotation && {
      title: "Crop rotation",
      rows: (plan?.seasons ?? []).map(
        (s) => `${s.year} · ${p.cropName(s.cropId)}`,
      ),
    },
  ].filter(Boolean) as { title: string; rows: string[] }[];
  const exportCsv = () => {
    const csv = [
      ["FieldShift report", field.name],
      ["Area hectares", String(field.areaHectares)],
      [
        "Selected point",
        `${p.selectedLocation.label} (${p.selectedLocation.latitude}, ${p.selectedLocation.longitude})`,
      ],
      [
        "Scope",
        "Point selection is separate from saved field records; no environmental grid averages are included.",
      ],
      ["Generated at", new Date().toISOString()],
      [
        "Methodology",
        "Browser-local entered and demo records; illustrative crop references; no live environmental values included.",
      ],
      ...sections.flatMap((s) => [[""], [s.title], ...s.rows.map((r) => [r])]),
    ]
      .map((row) => row.map(csvCell).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fieldshift-${field.name.toLowerCase().replaceAll(" ", "-")}-report.csv`;
    a.click();
    URL.revokeObjectURL(url);
    p.notify("CSV report exported.");
  };
  return (
    <>
      <PageHeader
        eyebrow="FIELD DOCUMENTS / 09"
        title="Reports"
        description="Compose a live report from this browser's current farm records."
        action={
          <Button onClick={() => window.print()}>
            <FileText size={16} />
            Print report
          </Button>
        }
      />
      <div className="report-controls panel">
        <SelectField
          label="REPORT FIELD"
          value={fieldId}
          onChange={(v) => {
            setFieldId(v);
            p.update((s) => ({ ...s, selectedField: v }));
          }}
          options={p.store.fields.map((f) => ({ value: f.id, label: f.name }))}
          testId="select-report-field"
        />
        <div className="report-checks">
          {Object.entries(include).map(([key, value]) => (
            <label key={key}>
              <input
                type="checkbox"
                checked={value}
                onChange={(e) =>
                  setInclude({ ...include, [key]: e.target.checked })
                }
              />
              {key === "soil"
                ? "Soil records"
                : key === "water"
                  ? "Water records"
                  : "Rotation plan"}
            </label>
          ))}
        </div>
        <Button variant="outline" onClick={exportCsv}>
          <Download size={15} />
          Export CSV
        </Button>
      </div>
      <article className="report-paper">
        <div className="report-topline">
          <span>FIELD SHIFT / OPERATIONS BRIEF</span>
          <span>
            {new Date().toLocaleDateString("en", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </span>
        </div>
        <div className="report-title">
          <img
            className="brand-mark"
            src="/images/fieldshift-emblem.png"
            alt="FieldShift logo"
          />
          <div>
            <div className="eyebrow">FIELD REPORT</div>
            <h1>{field.name}</h1>
          </div>
        </div>
        <div className="report-facts">
          <div>
            <small>AREA</small>
            <strong>
              {areaDisplay(field.areaHectares, p.store.settings.areaUnit)}{" "}
              {p.store.settings.areaUnit}
            </strong>
          </div>
          <div>
            <small>CURRENT CROP</small>
            <strong>{p.cropName(field.cropId)}</strong>
          </div>
          <div>
            <small>FIELD REFERENCE</small>
            <strong>{field.id}</strong>
          </div>
          <div>
            <small>REPORT STATUS</small>
            <strong>Local record snapshot</strong>
          </div>
        </div>
        {sections.map((s) => (
          <section className="report-section" key={s.title}>
            <div className="eyebrow">{s.title}</div>
            {s.rows.length ? (
              s.rows.map((r, i) => <p key={i}>{r}</p>)
            ) : (
              <p className="muted-note">
                No records available for this section.
              </p>
            )}
          </section>
        ))}
        <div className="report-disclaimer">
          <p>
            Selected point: {p.selectedLocation.label} ·{" "}
            {p.selectedLocation.latitude.toFixed(5)},{" "}
            {p.selectedLocation.longitude.toFixed(5)}. This is separate from the
            saved field geometry. Environmental model values are not included in
            this record report.
          </p>
          Demo records are explicitly labeled. Crop model inputs are planning
          assumptions. Calculated values are estimates. Browser-local only; no
          account or server sync is connected.
        </div>
      </article>
    </>
  );
}
function SettingsPage(p: PageProps) {
  const setSetting = (k: keyof Settings, v: Settings[keyof Settings]) =>
    p.update((s) => ({ ...s, settings: { ...s.settings, [k]: v } }));
  const reset = () => {
    if (
      window.confirm(
        "Reset all browser-local FieldShift data to the original deterministic demo? This removes entered records, plans and boundaries.",
      )
    ) {
      localStorage.removeItem(storeKey);
      sessionStorage.removeItem("fieldshift-storage-warning");
      p.update(() => ({
        ...initialStore,
        fields: demoFields.map((f) => ({
          ...f,
          boundary: f.boundary?.map((x) => [...x] as [number, number]),
        })),
        soils: [...initialStore.soils],
        irrigation: [...initialStore.irrigation],
        plans: initialStore.plans.map((x) => ({
          ...x,
          seasons: [...x.seasons],
        })),
      }));
      p.notify("Demo data restored.");
    }
  };
  return (
    <>
      <PageHeader
        eyebrow="WORKSPACE / 10"
        title="Settings"
        description="Preferences and browser-local demo data controls."
      />
      <div className="settings-layout">
        <section className="panel settings-panel">
          <div className="eyebrow">DISPLAY & UNITS</div>
          <h2>Operator preferences</h2>
          <div className="settings-row">
            <div>
              <strong>Appearance</strong>
              <small>Dark forest or readable light theme</small>
            </div>
            <div className="setting-segment">
              <button
                className={p.store.settings.theme === "dark" ? "selected" : ""}
                onClick={() => setSetting("theme", "dark")}
              >
                <Moon size={15} />
                Dark
              </button>
              <button
                className={p.store.settings.theme === "light" ? "selected" : ""}
                onClick={() => setSetting("theme", "light")}
              >
                <Sun size={15} />
                Light
              </button>
            </div>
          </div>
          <div className="settings-row">
            <div>
              <strong>Interface language</strong>
              <small>Arabic uses right-to-left layout</small>
            </div>
            <div className="setting-segment">
              <button
                className={p.store.settings.language === "en" ? "selected" : ""}
                onClick={() => setSetting("language", "en")}
              >
                English
              </button>
              <button
                className={p.store.settings.language === "ar" ? "selected" : ""}
                onClick={() => setSetting("language", "ar")}
              >
                <Languages size={15} />
                العربية
              </button>
            </div>
          </div>
          <div className="settings-row">
            <div>
              <strong>Area units</strong>
              <small>Used for farm and field areas</small>
            </div>
            <select
              value={p.store.settings.areaUnit}
              onChange={(e) =>
                setSetting("areaUnit", e.target.value as Settings["areaUnit"])
              }
            >
              <option value="ha">Hectares (ha)</option>
              <option value="ac">Acres (ac)</option>
            </select>
          </div>
          <div className="settings-row">
            <div>
              <strong>Temperature units</strong>
              <small>Display preference for weather</small>
            </div>
            <select
              value={p.store.settings.temperatureUnit}
              onChange={(e) =>
                setSetting(
                  "temperatureUnit",
                  e.target.value as Settings["temperatureUnit"],
                )
              }
            >
              <option value="C">Celsius (°C)</option>
              <option value="F">Fahrenheit (°F)</option>
            </select>
          </div>
          <div className="settings-row">
            <div>
              <strong>Water units</strong>
              <small>Display preference for volumes</small>
            </div>
            <select
              value={p.store.settings.waterUnit}
              onChange={(e) =>
                setSetting("waterUnit", e.target.value as Settings["waterUnit"])
              }
            >
              <option value="mm">Millimeters (mm)</option>
              <option value="m3">Cubic meters (m³)</option>
            </select>
          </div>
          <div className="settings-row">
            <div>
              <strong>Currency</strong>
              <small>Crop planning reference</small>
            </div>
            <select
              value={p.store.settings.currency}
              onChange={(e) =>
                setSetting("currency", e.target.value as Settings["currency"])
              }
            >
              <option value="SAR">Saudi Riyal (SAR)</option>
              <option value="USD">US Dollar (USD)</option>
            </select>
          </div>
        </section>
        <aside className="panel data-settings">
          <div className="eyebrow">DATA & PRIVACY</div>
          <h2>Stored in this browser</h2>
          <button
            type="button"
            className="btn btn-outline"
            onClick={() =>
              window.dispatchEvent(new Event("fieldshift-replay-intro"))
            }
          >
            Replay FieldShift intro
          </button>
          <div className="privacy-mark">
            <Layers3 size={20} />
          </div>
          <p>
            Your farms, field notes, soil observations and irrigation records
            are stored in this browser's localStorage for this demo.
          </p>
          <p>
            <strong>No account or server sync is connected.</strong> Clearing
            browser storage removes your entered data.
          </p>
          <div className="storage-count">
            <span>Fields</span>
            <b>{p.store.fields.length}</b>
            <span>Entered soil tests</span>
            <b>{p.store.soils.filter((s) => s.source === "Entered").length}</b>
            <span>Irrigation records</span>
            <b>{p.store.irrigation.length}</b>
          </div>
          <Button variant="danger" onClick={reset}>
            <RotateCcw size={15} />
            Reset demo data
          </Button>
        </aside>
      </div>
    </>
  );
}
function NotFound({ setPath }: { setPath: (path: string) => void }) {
  return (
    <div className="not-found panel">
      <div className="eyebrow">404 / FIELD NOT FOUND</div>
      <h1>This coordinate is off the map.</h1>
      <p>The page you requested is not part of this workspace.</p>
      <Button onClick={() => setPath("/")}>
        Back to overview <ArrowRight size={15} />
      </Button>
    </div>
  );
}

export default App;
